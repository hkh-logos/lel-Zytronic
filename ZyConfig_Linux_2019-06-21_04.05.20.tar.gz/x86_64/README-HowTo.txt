Zytronic Displays Limited
=========================

Date :                  Fri 21 Jun 10:39:40 BST 2019

Application Version:    04.05.20


The standard Linux kernel natively provides drivers for Zytronic
touch devices - the 'hid-multitouch' kernel module delivers
touch events to users via an 'event' file in the system directory:

        /etc/input

The applications supplied by Zytronic are used to configure
and calibrate Zytronic devices for a system.

Users are free to modify this example code to their own requirements.

The following usages will ask for a system (root) password so that
'sudo' may invoke the underlying program with full rights.
Alternatively, the programs may be used from a root account.

Note: The environment variable $XDG_RUNTIME_DIR specifies a user-specific
directory in which the ZyConfig program can store small temporary files.
This variable is set on login for standard users but is not set for the root
user. Because of this, running sudo ./ZyConfig directly will result in the
following warning message being displayed in the terminal.

	QStandardPaths: XDG_RUNTIME_DIR not set, defaulting to '/tmp/runtime-root'

This warning message does not cause any problems but some users may choose
to avoid the line being shown in the terminal. Below are two methods to prevent
the message being shown:

    1) use the "run*" scripts provided (as described below)
	or
    2) ensure that the XDG_RUNTIME_DIR environment variable is set for the
	root user before running the ZyConfig tool as root


Shell script usage examples:
============================

To get a list of commands available on the command line,
use the command:

    $ ./ZyConfig help

This will provide a list of the commands available with some guidance
on their usage.

A full hardware user manual is available on our website.
                [ https://zytronic.co.uk/ ]
                [ https://zytronic.co.uk/support/downloads/ ]

With a single touch controller, the following commands are typical:

    $ ./runZyCalibrate
    $ ./runZyConfig test   -or-   ./runTouchTest
    $ ./runZyConfig save [goldenSettings.zys]
    $ ./runZyConfig load <goldenSettings.zys>
    $ ./runZyConfig version     # report ZyConfig version info
    $ ./runZyConfig device      # report touch device version details

To reset all controller settings to original factory values:
    $ ./runZyConfig restore-defaults  (this can take up to 10 seconds)

To update the firmware on the connected controller:
    $ ./runZyConfig firmware <device-firmware-file.zyf>

In general, the ZyConfig binary is run without a command line,
so that the (X11/Qt) GUI is presented.


Multi-controller / multi-display support:
-----------------------------------------

When more than one touch device is connected, the device to be
configured needs to be selected.

First, a list of connected devices can be generated:

    $ ./ZyConfig list
    2 Zytronic device(s) found:
      4. VID:14C8 PID:0014 Addr=03_04 ZXY150 APP
      5. VID:14C8 PID:0005 Addr=03_01 ZXY100 APP

Or, for a longer report on the device(s) above, run the same
command as root:

    $ sudo ./ZyConfig list
    4. VID:14C8 PID:0014 Addr=03_04 ZXY150 APP ZXY150-U-OFF-64-A 43003C000A51373032353739  /dev/input/event14
    5. VID:14C8 PID:0005 Addr=03_01 ZXY500 APP ZXY100-U-OFF-32-B 430050000A51373032353739  /dev/input/event13

Then, a specific device is selected using the argument 'deviceKey=<string>' see
examples below:

    $ ./runZyConfig deviceKey=ZXY150 device
    Firmware    15.03.63
    Hardware    ZXY150-U-OFF-64-A
    Bootloader  15.00.13

    $ ./runZyConfig deviceKey=32-B device
    Firmware    501.36
    Hardware    ZXY100-U-OFF-32-B
    Bootloader  1.48

The deviceKey argument can be used to match against any part of the output of
$sudo ./ZyConfig list, giving the ability to connect by device type, PID,
serial number, etc..

To start the GUI and connect to a specific device provide
the device address but no command:

    $ ./runZyConfig deviceKey=PID:0005

The display assignment is completed as part of the touch device
calibration, and a copy of the mapping is stored in the file
'/etc/zytronic/zyconfig.conf'

After calibration, the "list" report is extended to include
this information:

    $ sudo ./ZyConfig list
    4. VID:14C8 PID:0014 Addr=03_04 ZXY150 APP ZXY150-U-OFF-64-A 43003C000A51373032353739  /dev/input/event14  HDMI-2 1920x1080+0+0
    5. VID:14C8 PID:0005 Addr=03_01 ZXY500 APP ZXY100-U-OFF-32-B 430050000A51373032353739  /dev/input/event13  HDMI-1 1920x1080+0+1080

Zytronic provide the script ./multi-display/setup.sh which is run as root after
the touch device calibration to setup a udev/systemd service script that can
re-bind each touch device to the correct display, in the case that a touch
device / display is disconnected/re-connected.

It has been observed on some systems that the re-binding does not occur at user
login.  To fix this, add the script 'multi-display/zytronic_multi-display.sh'
to the list of startup applications.

A list of the available displays can be provided by the Linux command
'xrandr', or:

    $ ./ZyConfig display
    Screen0  1920x2160
      HDMI-1  1920x1080+0+0         Primary
      HDMI-2  1920x1080+0+1080

This allows the calibration service to be directed onto a specific screen from
the command line:

    $ sudo ./ZyConfig calibrate HDMI-1

Calibration
-----------

In most cases, the calibration can be completed simply by running:
    $ sudo ./runZyConfig calibrate

In some cases the calibration targets may be difficult/not possible to touch.
The location of the calibration targets can be moved to a more convenient
location using the command line:

    $ sudo ./ZyConfig calibrate margins=<top>,<bottom>,<left>,<right>

Where:
    The top/bottom margins are described as a percentage of the screen height.
    The left/right margins are described as a percentage of the screen width.

For accurate calibration, it is advised that the calibration targets are located
close to the corners of the sensor.


Low  Level Services
-------------------
The following usages are normally only used with some direction from
technical support staff at Zytronic, or with reference to the
appropriate protocol document.

$ ./runZyConfig status <status value index 0..N>
$ ./runZyConfig set <configuration parameter index 0..N> <value 0-65535>
$ ./runZyConfig get <configuration parameter index 0..N>

These low-level services are more difficult to use, but provide access to
every available internal value and setting. If several setting changes are
needed, a ZYS file can be constructed and given an appropriate name.
This ZYS file can then be 'loaded' to the controller.

-- END --
