#!/bin/bash

RT_PATH=/tmp/runtime-root
if [ ! -e $RT_PATH ]; then

    which sudo > /dev/null
    sudoMISSING=$?

    echo XDG_RUNTIME_DIR: creating $RT_PATH
    if [ $sudoMISSING -eq 1 ]; then

        if [ `id -u` -ne 0 ]; then
            echo Re-run as root
            exit 1;
        else
            mkdir -p -m700 $RT_PATH
        fi

    else
        sudo mkdir -p -m700 $RT_PATH
    fi
fi

