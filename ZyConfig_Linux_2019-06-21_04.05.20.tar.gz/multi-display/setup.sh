#!/bin/bash

echo running multi-display setup script...

#Find location of udev - /usr/lib/udev (Redhat/CentOS) or /lib/udev (Debian/Ubuntu)
udevDir=/usr/lib/udev

if [ ! -d "$udevDir" ]; then
    udevDir=/lib/udev
fi
if [ ! -d "$udevDir" ]; then
    echo ERROR - Cannot find udev
    exit
fi

#echo $udevDir

# cd to where this script is
cd "$( dirname "$0" )"

# Remove old file versions if they exist and copy the required files to correct locations
if [ -e "$udevDir/rules.d/zytronic_multi-display.rules" ]; then
    rm $udevDir/rules.d/zytronic_multi-display.rules
fi
cp ./zytronic_multi-display.rules $udevDir/rules.d/zytronic_multi-display.rules

if [ -e "/etc/systemd/system/zytronic_multi-display.service" ]; then
    rm /etc/systemd/system/zytronic_multi-display.service
fi
cp ./zytronic_multi-display.service /etc/systemd/system/zytronic_multi-display.service

if [ -e "/etc/zytronic/zytronic_multi-display.sh" ]; then
    rm /etc/zytronic/zytronic_multi-display.sh
fi
cp ./zytronic_multi-display.sh /etc/zytronic/zytronic_multi-display.sh

if [ -e "/etc/systemd/system/zytronic_multi-display_boot.service" ]; then
    rm /etc/systemd/system/zytronic_multi-display_boot.service
fi
cp ./zytronic_multi-display_boot.service /etc/systemd/system/zytronic_multi-display_boot.service

if [ -e "/etc/zytronic/zyConfigCli" ]; then
     rm /etc/zytronic/zyConfigCli
elif [ -e "/etc/zytronic/ZyConfigCLI" ]; then
    rm /etc/zytronic/ZyConfigCLI
fi
cp ../x86_64/ZyConfigCLI /etc/zytronic

systemctl disable zytronic_multi-display_boot.service
systemctl enable zytronic_multi-display_boot.service

# go back to where we were
cd -

/etc/zytronic/zytronic_multi-display.sh
