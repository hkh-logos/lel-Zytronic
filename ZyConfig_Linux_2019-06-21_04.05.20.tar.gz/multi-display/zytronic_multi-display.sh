#!/bin/bash
export DISPLAY=:0
export XAUTHORITY=/run/user/1000/gdm/Xauthority

logFile=/etc/zytronic/zytronic_multi-display.log
echo "" > $logFile
echo "START  `date`" >> $logFile
echo "arg1=$1" >> $logFile

if [ "$1" = "nosleep" ];then
    echo "nosleep" >> $logFile
else
    echo "sleep, START" >> $logFile
    sleep 3
    echo "sleep, END" >> $logFile
fi

for item in $(xinput list | grep "ZXY500 Controller" | grep pointer | grep -o -E "id=[0-9]+")
do
    echo "1 item='$item'" >> $logFile

    # remove everything but the 4th and 5th character (assumed input "id=" + xinput id)
    id=$(echo $item | cut -c 4,5)
    echo "2 id='$id'" >> $logFile

    # use the xinput id to get the event stream
    eventNumber=$(xinput list-props $id | grep -o -E "/dev/input/event[0-9]+" | grep -o -E "event[0-9]+" )
    echo "3 eventNumber='$eventNumber'" >> $logFile

    # use the event stream number to get the USB serial number
    usbSerialNumber=$(ls -l /dev/input/by-id/*Zytronic*if00* | grep $eventNumber | grep -o -E "[0-9A-F]{24}")
    echo "4 usbSerialNumber='$usbSerialNumber'" >> $logFile

    # read zyconfig.conf line by line looking for the display asigned to this serial number
    displayName=""
    filename="/etc/zytronic/zyconfig.conf"

    while read -r line
    do
        echo "5 line='$line'" >> $logFile
        displayName=$(echo $line | grep $usbSerialNumber)
        if [[ -n $displayName ]]; then
            echo "6 displayName='$displayName'" >> $logFile
            break
        fi
    done < $filename

    echo "7 displayName='$displayName'" >> $logFile

    displayName=$(echo $displayName | grep -o -E "[ ].*$" )

    echo "8 displayName'='$displayName'" >> $logFile

    echo "9 run 'xinput --map-to-output $id $displayName' ..." >> $logFile

    # map the controller xinput id to the correct display
    xinput --map-to-output $id $displayName

    echo "10 done" >> $logFile
done

echo  "END  `date`" >> $logFile
