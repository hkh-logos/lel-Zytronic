#!/bin/bash
echo

mkTarget="all"
if [ "$1" == "clean" ]; then
    mkTarget="clean"
fi

make -wC src -f Makefile $mkTarget
echo
