splint -boolcompare -mustfreefresh -statictrans -compdef \
    -I../include/ -I/usr/local/include/libusb-1.0/  -I/usr/include/libusb-1.0/ \
    -I/usr/include/x86_64-linux-gnu/  \
    -warnposix -unrecog -retvalbool -mustdefine -exportlocal -usedef  -observertrans \
    +charint +trytorecover *.c \
    > splintReport.txt
# +matchanyintegral -weak 

#less ./splintReport.txt
head -n 100 ./splintReport.txt
echo 
echo ----------------------------------------------------------------
echo
echo there are `wc -l splintReport.txt` lines
echo

rm ./splintReport.txt

echo ----------------------------------------------------------------
echo
echo  lines, words, bytes
wc *.c
# echo  -------------------
# wc ../include/*.h
echo ----------------------------------------------------------------
echo 
