/****************************************************************************
 **
 ** Copyright (C) 2010 Nokia Corporation and/or its subsidiary(-ies).
 ** All rights reserved.
 ** Contact: Nokia Corporation (qt-info@nokia.com)
 **
 ** This file is part of the examples of the Qt Toolkit.
 **
 ** $QT_BEGIN_LICENSE:LGPL$
 ** Commercial Usage
 ** Licensees holding valid Qt Commercial licenses may use this file in
 ** accordance with the Qt Commercial License Agreement provided with the
 ** Software or, alternatively, in accordance with the terms contained in
 ** a written agreement between you and Nokia.
 **
 ** GNU Lesser General Public License Usage
 ** Alternatively, this file may be used under the terms of the GNU Lesser
 ** General Public License version 2.1 as published by the Free Software
 ** Foundation and appearing in the file LICENSE.LGPL included in the
 ** packaging of this file.  Please review the following information to
 ** ensure the GNU Lesser General Public License version 2.1 requirements
 ** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
 **
 ** In addition, as a special exception, Nokia gives you certain additional
 ** rights.  These rights are described in the Nokia Qt LGPL Exception
 ** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
 **
 ** GNU General Public License Usage
 ** Alternatively, this file may be used under the terms of the GNU
 ** General Public License version 3.0 as published by the Free Software
 ** Foundation and appearing in the file LICENSE.GPL included in the
 ** packaging of this file.  Please review the following information to
 ** ensure the GNU General Public License version 3.0 requirements will be
 ** met: http://www.gnu.org/copyleft/gpl.html.
 **
 ** If you have questions regarding the use of this file, please contact
 ** Nokia at qt-info@nokia.com.
 ** $QT_END_LICENSE$
 **
 ****************************************************************************/

#include <QEvent>
#include <QPaintEvent>
#include <QTimer>
#include <QTouchEvent>
#include <QPainter>

#include "drawArea.h"

#define CLEAR_TIME_S    3
#define CLEAR_TIME_MS   (CLEAR_TIME_S * 1000)

#define LINE_THICKNESS  5

DrawArea::DrawArea(QWidget *parent) : QWidget(parent)
{
    setAttribute(Qt::WA_AcceptTouchEvents);
    setAttribute(Qt::WA_StaticContents);

    backgroundColour.setNamedColor("dodgerBlue");

    drawColours
        << QColor("aquamarine") // very similar to lightGreen
        << QColor("blue")
        << QColor("burlyWood")
        << QColor("brown")
        << QColor("cyan")
        << QColor("chartreuse")
        << QColor("chocolate")
        << QColor("coral")
        << QColor("crimson")
        << QColor("lightGreen") // very similar to aquamarine
        << QColor("magenta")
        << QColor("red")
        << QColor("yellow");

    // initial background draw
    background = new QImage(width(), height(), QImage::Format_RGB32);
    background->fill(backgroundColour);
    {
        // parentheses to contain the life of QPainter
        QPainter painter(background);
        painter.drawImage(QPoint(0, 0), *background);
        update();
    }
    drawInstructionText();

    capturePrimary = true;

    clearTimer = new QTimer(this);
    clearTimer->setInterval(CLEAR_TIME_MS);
    clearTimer->setSingleShot(false);
    QObject::connect(clearTimer, SIGNAL(timeout()),
    this, SLOT(clear()));
}

void DrawArea::drawInstructionText()
{
    QPainter painter(background);
    QRect textRect(10, 5, 0, 0);

    QString exitInstructionString = tr("Press 'ESC' or touch & hold to exit");
    // get size of string
    textRect = painter.boundingRect(textRect, Qt::AlignLeft, exitInstructionString);

    // print string
    painter.setPen(Qt::black);
    painter.drawText(textRect, Qt::AlignLeft, exitInstructionString);
    update(textRect);
}

void DrawArea::clear()
{
    // only clear the screen if there are no live touches
    if(numLiveTouches == 0)
    {
        clearTimer->stop();

        background->fill(backgroundColour);
        update();

        drawInstructionText();
    }
    else if(numLiveTouches == 1)
    {
        // picked up by the MainWindow for touch & hold to exit
        emit touchHold();
    }
    else
    {
        // the clearTimer is reset when we see touch events

        // if all touches are stationary there will be no touch events until one
        // of the touches moves, lifts off, or another touch is placed on the
        // sensor
    }
}

void DrawArea::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    const QRect rect = event->rect();
    painter.drawImage(rect.topLeft(), *background, rect);
}

void DrawArea::resizeEvent(QResizeEvent *event)
{
    QSize newSize(width(), height());
    // don't waste time if the size hasn't changed
    if(background->width() < width() || background->height() < height())
    {
        // create a new larger image
        QImage newImage(newSize, QImage::Format_RGB32);
        newImage.fill(backgroundColour);
        // draw the old image on the new one
        QPainter painter(&newImage);
        painter.drawImage(QPoint(0, 0), *background);
        *background = newImage;
    }
    update();

    QWidget::resizeEvent(event);
}

QColor DrawArea::getColour(int id)
{
    if (id == primaryTouch)
    {
        return QColor("white");
    }
    else
    {
        return drawColours.at(id % drawColours.count());
    }
}

void DrawArea::drawTouchPoints(QEvent *event)
{
    QList<QTouchEvent::TouchPoint> newTouchPoints;
    newTouchPoints = static_cast<QTouchEvent *>(event)->touchPoints();
    numLiveTouches = 0;

    foreach (const QTouchEvent::TouchPoint &touchPoint, newTouchPoints)
    {
        // count the number of touches
        if(touchPoint.state() != Qt::TouchPointReleased)
        {
            numLiveTouches++;
        }

        // don't do anything else if this touch point hasn't moved
        if (touchPoint.state() != Qt::TouchPointStationary)
        {
            QPointF oldPoint = touchPoint.lastPos();
            QPointF newPoint = touchPoint.pos();

            qreal diameter = LINE_THICKNESS;
            qreal radius = diameter/2;

            // we could modify the diameter based on pressure
            // diameter = diameter * touchPoint.pressure();

            QPainter painter(background);
            QRectF rect;

            // most of the time we will be drawing lines so check against this
            // option first.
            if(touchPoint.state() == Qt::TouchPointMoved)
            {
                // draw a line when the touch point moves
                painter.setPen(QPen(getColour(touchPoint.id()),
                                    diameter,
                                    Qt::SolidLine,
                                    Qt::RoundCap,
                                    Qt::RoundJoin) );

                // draw a line between the new point and the last recorded
                // point from this event
                QLineF newLineSegment(oldPoint, newPoint);
                painter.drawLine(newLineSegment);

                // define a rect which encloses the new line segment
                rect.setTopLeft(oldPoint);
                rect.setBottomRight(newPoint);
                rect = rect.normalized().adjusted(-radius, -radius, radius, radius);
            }
            else if(touchPoint.state() == Qt::TouchPointPressed)
            {
                if(capturePrimary)
                {
                    primaryTouch = touchPoint.id();
                    capturePrimary = false;
                }
                //draw a dot for the first point.
                painter.setPen(Qt::NoPen);
                painter.setBrush(getColour(touchPoint.id()));

                // define a rect at the new touch point location, the
                // size of the dot we want to draw.
                rect.setTopLeft(newPoint);
                rect.setSize(QSize(diameter, diameter));

                // adjust the rectangle so the touch point location will
                // be in the centre of the dot
                rect = rect.adjusted(-radius, -radius, -radius, -radius);

                // draw a circle to fill the rect
                painter.drawEllipse(rect);
            }

            // update a slightly larger rect to make sure we don't
            // miss the edges
            int updatePad = 2;
            rect = rect.adjusted(-updatePad, -updatePad, updatePad, updatePad);

            update( rect.toRect() );
        }
    }

    if(numLiveTouches == 0)
    {
        capturePrimary = true;
    }
}

void DrawArea::updateText()
{
    QPainter painter(background);
    QRect textRect(10, 25, 0, 0);

    // prepare the string
    QString numTouchesString = "Number of active touches: ";

    //append "100" to get the maximum size of the the previously printed string
    numTouchesString.append("100");
    textRect = painter.boundingRect(textRect, Qt::AlignLeft, numTouchesString);

    // clear the previous text
    painter.setPen(backgroundColour);
    painter.setBrush(backgroundColour);
    painter.drawRect(textRect);
    update(textRect);

    // remove the previously appended "100"
    numTouchesString.chop(3);
    // append the actual number of the live touches
    numTouchesString.append(QString::number(numLiveTouches));

    // print the number of live touches string
    painter.setPen(Qt::black);
    painter.drawText(textRect, Qt::AlignLeft, numTouchesString);
    update(textRect);
}

bool DrawArea::event(QEvent *event)
{
    switch (event->type())
    {
        // we're only intrested in touch events
        case QEvent::TouchBegin:
        case QEvent::TouchUpdate:
        case QEvent::TouchEnd:
            drawTouchPoints(event);
            // display the number of live touches in the top left corner
            updateText();
            // reset/restart the timer
            clearTimer->start();
            break;

        default:
            return QWidget::event(event);
    }
    return true;
}
