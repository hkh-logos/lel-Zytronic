/*
 *      Main Window for the configuration application.
 *      Also handles some CLI usage; see cliCmdHelp()
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <QApplication>
#include <QtWidgets>
#include <QDesktopWidget>
#include <QInputDialog>

#include <iostream>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <ctype.h>

#include <services.h>
#include <usb.h>
#include <debug.h>
#include <sysdata.h>
#include <configfile.h>
#include <MonitorSelect.h>
#include <Monitor.h>

#include "version.h"

#include "zyconfmain.h"

#define DEV_LIST_SZ             (1000)

// utility functions

bool            fwIsCompatible          (int16_t PID);
QString         getVersionText          (void );
void            cleanup                 (void);
void            sigHandler              (int sig);

// Globals

const int   DebugApp = 0;
const int   LibDebugLvl = 3;        // only used if DebugApp > 0

int         g_lock_fd = -1;
int         g_exit_value = 0;
char        g_ZXY100_drv_ver[20] = "";
char        g_ZXY_MT_drv_ver[20] = "";

int16_t    g_devPID = UNKNWN_PRODUCT_ID;
char        g_selectedAddrStr[10] = "";

Zxy100Data  g_zxy100Data;

bool        g_alwaysOnTop = false;
bool        g_inhibitLEDPoll = false;
QString     g_appVersions = "";

ZyConfMain  * g_mainWindow = NULL;

#define LCK_FILE "/var/lock/zyconfig.lck"


void sigHandler( int sig)
{
    if (DebugApp) psignal(sig, "ZyConfig signal handler");

    if (g_mainWindow != NULL)
    {
        g_mainWindow->closeEvent(new QCloseEvent());
    }

    // it's a widely accepted convention that programs return 0 for success, else an error code.
    exit ( (g_exit_value == SUCCESS) ? EXIT_SUCCESS : EXIT_FAILURE );
}

void cleanup(void)
{
    if (DebugApp)  fprintf (stderr, "cleanupStart\n");
    zul_EndServices();
    if (DebugApp)  fprintf (stderr, "LibServicesDone\n");

    if (g_lock_fd != -1)
    {
        close(g_lock_fd);
    }

    unlink(LCK_FILE);
    g_lock_fd = -1;
    if (DebugApp) fprintf (stderr, "cleanupEnd\n");
}

// function to return a string of the form XX.YY.ZZ|aa.bb.cc
// representing the version numbers from the version.h files
QString getVersionText( void )
{
    char verStr[40+1];

    zul_getVersion( verStr, 40);       // one version to cover apps/lib/zyconfig

    return (QString)verStr;
}

int init_handlers(void)
{
    int retVal = SUCCESS;

    if (atexit(cleanup) != 0)
    {
        fprintf(stderr, "cannot set exit function\n");
        exit(-1);
    }

    if (SIG_ERR == signal( SIGHUP, sigHandler))
    {
        fprintf (stderr, "Error loading signal handler SIGHUP\n");
        retVal = FAILURE;
    }

    if (SIG_ERR == signal( SIGINT, sigHandler))
    {
        fprintf (stderr, "Error loading signal handler SIGINT\n");
        retVal = FAILURE;
    }

    if (SIG_ERR == signal( SIGQUIT, sigHandler))
    {
        fprintf (stderr, "Error loading signal handler SIGQUIT\n");
        retVal = FAILURE;
    }

    if (SIG_ERR == signal( SIGTERM, sigHandler))
    {
        fprintf (stderr, "Error loading signal handler SIGTERM\n");
        retVal = FAILURE;
    }

    if (SIG_ERR == signal( SIGTSTP, sigHandler))
    {
        fprintf (stderr, "Error loading signal handler SIGTSTP\n");
        retVal = FAILURE;
    }

    return retVal;
}

void closeAppLock(void)
{
    char pidBuf[20];

    g_lock_fd = open(LCK_FILE, O_CREAT|O_RDWR|O_EXCL,S_IRWXU);
    if (g_lock_fd == -1)
    {
        fprintf(stdout, LCK_FILE " exists - exiting\n");
        _exit(-EISCONN); // indicate that there is a running instance
    }

    // write the PID into the lock file
    sprintf( pidBuf, "%10d\n", getpid() );
    if (-1 == write(g_lock_fd, pidBuf, strlen(pidBuf) + 1 ))
    {
        fprintf(stderr, "Error writing PID to lock file\n");
        exit( -EIO );
    }
    fsync(g_lock_fd);
    sync();
}

bool fwIsCompatible(int16_t PID)
{
    char        versionStr[60];
    QString *   verQStr;
    double      verDev;
    bool        ok;
    bool        fwCompatible = false;

    if (DebugApp) printf("PID %04x\n", g_devPID);

    switch (PID)
    {
        case ZXY100_PRODUCT_ID:
            zul_Firmware(versionStr,60);

            verQStr = new QString(versionStr);
            verDev = verQStr->toDouble(&ok);
            fwCompatible = (verDev >= ZXY100_MIN_FW_FLOAT);

            if (!fwCompatible)
            {
                fprintf(stderr,
                        "ZXY100 firmware %.2f is older then the minimum allowed firmware (%.2f)\n",
                        verDev, ZXY100_MIN_FW_FLOAT);
                fprintf(stderr,
                        "The ZXY100 firmware MUST be updated before using this tool.\n" );
            }
            break;

        case ZXY150_PRODUCT_ID:
        case ZXY200_PRODUCT_ID:
        case ZXY300_PRODUCT_ID:
        case ZXY500_PRODUCT_ID:
        case ZXY500_PRODUCT_ID_ALT1:
            // assume these have OPTIONS status value
            fwCompatible = true;
            break;

        case ZXY100_BOOTLDR_ID:
        case ZXY110_BOOTLDR_ID:
        case ZXY150_BOOTLDR_ID:
        case ZXY200_BOOTLDR_ID:
        case ZXY300_BOOTLDR_ID:
        case ZXY500_BOOTLDR_ID:

            g_inhibitLEDPoll = true;

            #ifdef __APPLE__
            // program not compatible with bootloader
            fwCompatible = false;
            fprintf(stderr, "Error. This ZyConfig can't program a bootloader device.\n" );
            #else
            // program compatible with all recent firmwares
            fwCompatible = true;

            #endif
            break;

        case ZXY110_PRODUCT_ID:

            g_inhibitLEDPoll = true;

            // several changes required to get all services presented to operate correctly
            // - signal level view, LED status

            fwCompatible = true;

            break;
    }
    return fwCompatible;
}


// === Command Line Functions =================================================

void cliCmdAppVersion(char *clv)
{
    char verStr[10+1];
    zul_getVersion(verStr, 10);
    verStr[9] = '\0';

    printf("Application Version: %s\n", verStr );
    printf("Library Version: %s\n", clv );
    printf("%s\n", zul_usbLibStr());
    printf("Qt Version: %s\n", qVersion());
}

void cliCmdHelp(void)
{
    // CLI arguments
    puts("Usage:  ./ZyConfig help");
    puts("        ./ZyConfig version");
    puts("       [sudo] ./ZyConfig list");
    puts("        sudo  ./ZyConfig <command>");
    puts("        sudo  ./ZyConfig deviceKey=<string> <command>\n");

    puts("  help                        show this help text");
    puts("  version                     show application version\n");

    puts("  list                        show the indexed list of Zytronic controllers");
    puts("                              connected, run as super-user (sudo) for");
    puts("                              a more detailed list");
    puts("  deviceKey=<string>          searches the output of 'list' and connects");
    puts("                              to the first controller which contains");
    puts("                              the <string> provided\n");

    puts("Available Commands:");
    puts("  device                      get controller version strings\n");

    puts("  force_equalization          force sensor equalization");
    puts("  reset                       force a controller reset");
    puts("  restore_defaults            return controller to factory settings\n");

    puts("  firmware <filename.ZYF>     firmware update using the supplied ZYF file\n");

    puts("  get <index>                 get a configuration parameter");
    puts("  set <index> <value>         set a configuration parameter");
    puts("  status <index>              get a status value\n");

    puts("  load <filename.ZYS>         load the supplied ZYS file");
    puts("  save [filename.ZYS]         save a ZYS file (filename optional)\n");

    puts("  calibrate                   complete a 4 point graphical calibration");
    puts("                              calibration data is stored on controller");


    if (DebugApp == 0) return;

    puts("The following commands provide DEBUG services");

    puts("\tRAWVIEW [<ms timeout option>]");                    // this works, but is not advertised.
    puts("\tABOUT - print the text from the About Page");       // this is to be implemented to assist autotest
    puts("\tSUGGESTIONS - print the Suggested Settings text");  // this is to be implemented to assist autotest
    puts("\tDISPLAY - print the display(s) resolutions");       // this is to be implemented to assist autotest
    puts("\tBINDING - report device Unique ID and /dev/input event file name.\n");
}

void cliCmdSuggestions(void)
{
    SenseAndThreshFrame *stf = new SenseAndThreshFrame(NULL);
    QString txt = stf->getText(UNKNWN_PRODUCT_ID );
    fprintf(stdout, "%s\n", ZytContentFrame::toCString(&txt));
    txt = stf->getText(ZXY100_PRODUCT_ID);
    fprintf(stdout, "%s\n", ZytContentFrame::toCString(&txt));
    txt = stf->getText(ZXY110_PRODUCT_ID);
    fprintf(stdout, "%s\n", ZytContentFrame::toCString(&txt));
    delete stf;

    Z2SenseFrame *z2sf = new Z2SenseFrame(NULL);
    txt = z2sf->getText(ZXY150_PRODUCT_ID);
    fprintf(stdout, "%s\n", ZytContentFrame::toCString(&txt));
    txt = z2sf->getText(ZXY200_PRODUCT_ID);
    fprintf(stdout, "%s\n", ZytContentFrame::toCString(&txt));
    txt = z2sf->getText(ZXY300_PRODUCT_ID);
    fprintf(stdout, "%s\n", ZytContentFrame::toCString(&txt));
    txt = z2sf->getText(ZXY500_PRODUCT_ID);
    fprintf(stdout, "%s\n", ZytContentFrame::toCString(&txt));
    delete z2sf;
}

void cliCmdAbout(void)
{
    QString vers = getVersionText();
    AboutContent *ac = new AboutContent( NULL, &vers );
    printf("%s\n", ZytContentFrame::toCString(ac->getTextContent()));
    delete ac;
}

void cliCmdDisplay(void)
{
    char primaryMonName[12];

    int numScrns = getNumberOfScreens();
    if (numScrns < 1)
    {
        return;
    }
    strncpy( primaryMonName, getPrimaryMonitor(0), 12 );
    primaryMonName[11] = '\0';

    Size2d sizeS0 = getScreenSize(0);
    printf("Screen0  %dx%d\n", sizeS0.x, sizeS0.y );

    int numMonitors = getNumberOfMonitors(0);

    for ( int index=0; index<numMonitors; index++ )
    {
        char mName [14];
        char suffix[14] = "";

        strncpy (mName , getMonitorName(0, index), 12 );
        mName[11] = '\0';
        Location mLocation = getMonitorLocation( 0, index );
        Size2d msize = getMonitorSize( 0, index  );
        XMonitorOrientation mOrientation = getMonitorOrientation( 0, index );
        Monitor m = Monitor ( "", mLocation, msize, mOrientation );
        if ( 0 == strcmp ( primaryMonName, mName ) )
        {
            strcpy ( suffix, " Primary" );
        }
        printf("  %-6s %-20s %s\n", mName, m.getParams(), suffix);
    }
}

void cliCmdRawView(QStringList *args)
{
    bool            cvtOk = false;
    long            msTimeout;
    ZXY_sensorSize  size;

    if( args->size() > 2 )
    {
        QString msTOstr = args->at(2);
        msTimeout = msTOstr.toLong(&cvtOk, 10);
        if (cvtOk)
        {
            if ((msTimeout > 100000) || (msTimeout < 700))
            {
                cvtOk = false;
            }
        }
    }

    zul_getSensorSize(&size);
    switch (g_devPID)
    {
        case ZXY150_PRODUCT_ID:
        case ZXY200_PRODUCT_ID:
        case ZXY300_PRODUCT_ID:
        case ZXY500_PRODUCT_ID:
        case ZXY500_PRODUCT_ID_ALT1:
            {
                Z2RawImageWindow    localRawWin;

                localRawWin.setAdvancedMode( Z2RawImageWindow::FlagGridOn | Z2RawImageWindow::FlagColorMap2 );
                localRawWin.setDimensions(size.xWires, size.yWires);

                if (g_alwaysOnTop)
                {
                    localRawWin.setWindowFlags(Qt::WindowStaysOnTopHint);
                }

                if (cvtOk)
                {
                    localRawWin.setMsToRun(msTimeout);
                }
                zul_useKernelIFace(true);
                localRawWin.exec();
                zul_useKernelIFace(false);

            }
            break;

        case ZXY100_PRODUCT_ID:
        case ZXY110_PRODUCT_ID:
            {
                Z1_RawImageWindow testContent;
                testContent.setDimensions(g_devPID, size.xWires, size.yWires);
                testContent.setAdvancedMode( Z2RawImageWindow::FlagGridOn );
                if (g_alwaysOnTop)
                {
                    testContent.setWindowFlags(Qt::WindowStaysOnTopHint);
                }

                if (cvtOk)
                {
                    testContent.setMsToRun(msTimeout);
                }
                zul_useKernelIFace(true);
                testContent.exec();
                zul_useKernelIFace(false);
            }
            break;

        default:
            break;
    }
}

void cliCmdCalibrate(QStringList *args)
{
    // trigger the calibrate GUI process

    bool validMonitor  = false;
    bool screenModeSet = false;

    CalibrationDialog   caliDialog;
    MonitorSelect       monitorSelector;

    if( args->size() > 2 )
    {
        if ( args->contains("HELP", Qt::CaseInsensitive) )
        {
            //fprintf(stderr, "Available Calibration Modes:\n\t%s\n",
            //        CalibrationDialog::screenModeStr.toLatin1().data());
            fprintf(stderr, "\nCalibration command line options:\n");
            fprintf(stderr, "\tMARGINS=<top>,<bottom>,<left>,<right>");
            fprintf(stderr, "\t Set calibration target margins by percentage inset\n");
            fprintf(stderr, "\tNO_INFO\t\t\t\t\t Remove on-screen info-box\n");
            fprintf(stderr, "\tNO_TIMEOUT\t\t\t\t Disable time-out function\n\n");
            // FYI:  DUALTOP (etc) should preceded NO_INFO / NO_TIMEOUT  -- DEPRECATED
            return;
        }
        else
        {
            if ( CalibrationDialog::dualScreenOptions.contains(args->at(2).toUpper() ) )
            {
                // Oct, 2018: these services are no longer required! see setMonitor()
                validMonitor = ( 0 == caliDialog.setScreenMode( args->at(2).toUpper() ) );
                screenModeSet = true;
            }
            else
            {
                QRegExp monitorArg;
                monitorSelector.getMonitorListAsRegExp(&monitorArg);

                int monitorStrIndex = args->indexOf( monitorArg );
                if (monitorStrIndex != -1)
                {
                    if ( monitorSelector.selectByName( args->at(monitorStrIndex).toUpper() ) )
                    {
                        Monitor selected;
                        monitorSelector.getSelectedMonitor(&selected);
                        caliDialog.setMonitor(&selected);
                        screenModeSet = true;
                        validMonitor = true;
                    }
                }
            }

            QRegExp marginStrFormat( "MARGINS=(\\d{1,2})\\,(\\d{1,2})\\,(\\d{1,2})\\,(\\d{1,2})", Qt::CaseInsensitive );
            if ( args->indexOf( marginStrFormat ) != -1 )
            {
                int topMargin    = marginStrFormat.cap(1).toInt(nullptr,10);
                int bottomMargin = marginStrFormat.cap(2).toInt(nullptr,10);
                int leftMargin   = marginStrFormat.cap(3).toInt(nullptr,10);
                int rightMargin  = marginStrFormat.cap(4).toInt(nullptr,10);

                caliDialog.setCustomMargins(topMargin, bottomMargin, leftMargin, rightMargin);
            }

            if (args->contains("NO_TIMEOUT", Qt::CaseInsensitive) )
                caliDialog.setTimeOut(0);
            if (args->contains("NO_INFO", Qt::CaseInsensitive) )
                caliDialog.enableInfo(false);
        }
    }

    if (screenModeSet)
    {
        if (validMonitor)
        {
            zul_useKernelIFace(true);
            caliDialog.exec();
            zul_useKernelIFace(false);
        }
        else
        {
            std::cout << "System display arrangement is not suitable for "
                << args->at(2).toLatin1().data() << " calibration" << std::endl;
            cliCmdDisplay();
        }
    }
    else
    {
        QString mName = caliDialog.getMonitorForDevice();
        if (mName != NULL)
        {
            monitorSelector.setPreferred(mName);
        }
        if (QDialog::Accepted == monitorSelector.exec())
        {
            Monitor selected;
            monitorSelector.getSelectedMonitor(&selected);
            caliDialog.setMonitor(&selected);

            zul_useKernelIFace(true);
            caliDialog.exec();
            zul_useKernelIFace(false);
        }
    }
}

static const int PATH_LEN = (255);
int cliCmdFirmwareUpdate(QString fileName)
{
    char        zyfFilename[PATH_LEN+1];
    int16_t     bootDevicePID;
    int         deviceIndex;
    int         retVal;
    QString     filenameArg;

    // Update the firmware on the connected device
    zul_setCommsEndurance(COM_ENDUR_HIGH);

    if (fileName == NULL)
    {
        QFileDialog openFWDialog(NULL, "Select Firmware File to Upload");
        zul_getDevicePID(&bootDevicePID);

        QString prefix = QString( zul_getZYFFilter() );
        openFWDialog.setNameFilter("ZYF Zytronic Firmware files" + prefix);
        if (openFWDialog.exec())
        {
            filenameArg = openFWDialog.selectedFiles().at(0);
        }
    }
    else
    {
        filenameArg = fileName;
    }

    strncpy(zyfFilename, filenameArg.toUtf8().constData(), PATH_LEN);
    zyfFilename[PATH_LEN] = '\0';
    if (DebugApp) fprintf(stderr, "Upload file : %s\n", zyfFilename );

    // now zyfFilename holds the desired ZYF path/file
    bootDevicePID = zul_getBLPIDByDevS(zyfFilename);
    if (DebugApp) fprintf(stderr, "Target BL PID : %04x\n", bootDevicePID);

    if (SUCCESS == zul_loadAndValidateZyf(zyfFilename))
    {
        int16_t pid;
        zul_getDevicePID(&pid);
        char const * devStr;

        if (!zul_isBLDevicePID(pid))
        {
            devStr = zul_getDevStrByPID(pid);
            if (!zul_checkZYFmatchesHW(devStr, zyfFilename))
            {
                fprintf(stderr, "ZYF File is not matched to connected device %s\n", devStr);
                exit(EXIT_FAILURE);
            }

            // all OK
            printf("Restart to BL ... \n");
            zul_StartBootLoader();
            zul_closeDevice();
            zy_msleep(BL_RESET_DELAY_MS);
        }
        else
        {
            fprintf(stderr, "Device is already in bootloader mode\n\n");
            bootDevicePID = pid;

            devStr = zul_getDevStrByPID(pid);
            if (!zul_checkZYFmatchesHW(devStr, zyfFilename))
            {
                fprintf(stderr, "ZYF File is not matched to connected device %s\n", devStr);
                exit(EXIT_FAILURE);
            }

            zul_closeDevice();
            zy_msleep(BL_RESET_DELAY_MS);
        }

        // search for the bootloader PID as the device list updates
        if (DebugApp) fprintf(stderr, " Device PID %d\n\n", bootDevicePID);

        char tempBuffer[DEV_LIST_SZ+1];
        int findDevLoopCount=20;
        int numDevs = zul_getDeviceList(tempBuffer, DEV_LIST_SZ);

        while (findDevLoopCount-- > 0)
        {
            numDevs = zul_getDeviceList(tempBuffer, DEV_LIST_SZ);

            deviceIndex = zul_selectPIDFromList(bootDevicePID, tempBuffer);
            if (deviceIndex >= 0) break;

            fprintf(stderr, "Waiting for BL device %c\n", zul_spinner());
            zul_CursorUp(1);
            zy_msleep(BL_RESET_DELAY_MS/4);
        }

        if (DebugApp) fprintf(stderr, " Device index %d of %d\n", deviceIndex, numDevs);

        // open the bootloader device

        if (DebugApp)
        {
            fprintf(stderr, "%s\nAttempting to open device index %d ... \n", tempBuffer, deviceIndex);
        }
        retVal = zul_openDevice(deviceIndex);

        if (retVal != 0)
        {
            fprintf(stderr, "Error [%d] opening device index %d.\n", retVal, deviceIndex );
            exit (EXIT_FAILURE);
        }
        else
        {
            printf("                              \r");
        }

        // Update the firmware on the connected device
        zul_setCommsEndurance(COM_ENDUR_HIGH);

        if (DebugApp)
        {
            fprintf(stderr, "Sending the ProgData header message ... \n");
        }
        if (FAILURE == zul_testProgDataBlock())
        {
            fprintf(stderr, "\nDevice rejected this ZYF file.\n");
            fprintf(stderr, "Disconnect and reconnect the device, try again.\n");
            zul_BL_RebootToApp();
            exit(1);
        }

        // if parameter=1,  track progress on console
        int result = zul_transferFirmware(true);
        if (result == FAILURE)
        {
            fprintf(stderr, "\nTransfer Failed: %s\n", zul_getZyfXferResultStr());
        }
        else
        {
            fprintf(stderr, "Firmware Updated\n");
        }

        zul_BL_RebootToApp();
        return 0;
    }
    else
    {
        fprintf(stderr, "Invalid ZYF file\n");
        fprintf(stderr, "\nInvalid ZYF file%s\n", zul_getZyfXferResultStr());
    }
    return 0;
}

int cliCmdSet(QStringList *args)
{
    // set one of the flash-config parameters
    bool ok;

    if (args->size() < 4)
    {
        fprintf(stderr, "Writing failed: Missing index or value\n" );
        return -1;
    }

    int id = args->at(2).toUInt(&ok, 10);
    if ( (!ok) || (id > 0xFF) )
    {
        fprintf(stderr, "Writing failed: Index error\n" );
        return -1;
    }

    int value = args->at(3).toUInt(&ok, 10);
    if ((!ok) || (value > 0xFFFF) )
    {
        fprintf(stderr, "Writing failed: Value error\n" );
        return -1;
    }

    fprintf(stdout, "Writing %d (0x%04x) value to config parameter %d (0x%02x)\n",
               (uint16_t)value, (uint16_t)value, (uint8_t)id, (uint8_t)id );

    int retVal = zul_setConfigParamByID( (uint8_t)id, (uint16_t)value );
    if (retVal != SUCCESS)
    {
       fprintf(stderr, "Writing failed\n" );
    }
    return retVal;
}

int cliCmdGet(QStringList *args)
{
    // get one of the flash-config parameters
    bool ok;
    if (args->size() < 3)
    {
        fprintf(stderr, "Reading failed: Missing index\n" );
        return -1;
    }

    int id = args->at(2).toUInt(&ok, 10);
    if ( (!ok) || (id > 0xFF) )
    {
        fprintf(stderr, "Reading failed: Index error\n" );
        return -1;
    }

    int retVal;
    uint16_t value;
    fprintf(stderr, "Reading config parameter %d (0x%02x)\t",
            (uint8_t)id, (uint8_t)id );

    retVal = zul_getConfigParamByID( (uint8_t)id, &value );
    if (retVal == SUCCESS)
    {
        fprintf(stderr, "= %d (0x%04x)\n", value, value );
    }
    else
    {
        fprintf(stderr, "\nRead failed\n");
    }

    return retVal;
}
int cliCmdStatus(QStringList *args)
{
    // get one of the controller's status parameters
    bool ok;
    if (args->size() < 3)
    {
        fprintf(stderr, "Reading failed: Missing index\n" );
        return -1;
    }

    int id = args->at(2).toUInt(&ok, 10);
    if ( (!ok) || (id > 0xFF) )
    {
        fprintf(stderr, "Reading failed: Index error\n" );
        return -1;
    }

    int retVal;
    uint16_t value;
    fprintf(stderr, "Reading status parameter %d (0x%02x)\t",
            (uint8_t)id, (uint8_t)id );

    retVal = zul_getStatusByID( (uint8_t)id, &value );
    if (retVal == SUCCESS)
    {
        fprintf(stderr, "= %d (0x%04x)\n", value, value );
    }
    else
    {
        fprintf(stderr, "\nRead failed\n");
    }
    return retVal;
}

void cliCmdRestoreDefaults(void)
{
    char hwType[20];
    int delayMS = 2000;
    zul_Hardware(hwType, 20);
    if ( strstr(hwType, "ZXY110") )
    {
        delayMS = 10000;
    }
    fprintf(stdout, "\nPlease wait a moment ... (%ds)\n", delayMS/1000);
    zul_restoreDefaults();
    zy_msleep(delayMS);

    // ToDo: Challange this ...!
    //    Is this only needed for ZXY110? is it needed at all?
    zul_resetController();
}

void cliCmdBinding(void)
{
    char versionStr[60];

    if (SUCCESS == zul_CpuID(versionStr,60))
    {
        fprintf(stdout, "CPU Unique ID\t%s\n", versionStr);
        fprintf(stdout, "Event path\t/dev/input/event%d\n", getTouchEventPathIndex(versionStr));
    }
}

void cliCmdDevice(void)
{
    char versionStr[60];
    char hardVers[60];
    char bootVers[60];

    if (zul_isBLDevicePID(g_devPID))
    {
        if (g_devPID== ZXY100_BOOTLDR_ID)
        {
            zul_old_BLgetVersion();
            zul_BLgetVersionFromResponse(bootVers, 60);
            printf("Hardware\tZXY100\nBootloader\t%s\n", bootVers);
        }
        else
        {
            // VerIndex::  STR_BL, STR_FW, STR_HW, STR_AFC
            if(SUCCESS != zul_BLgetVersion (hardVers, 60,  STR_HW))
            {
                strcpy(bootVers, "-?-");
            }
            printf("Hardware %s\n", hardVers);
            if(SUCCESS != zul_BLgetVersion (bootVers, 60, STR_BL))
            {
                 strcpy(bootVers, "-?-");
            }
            printf("Bootloader\t%s\n", bootVers);
        }
        return;
    }

    zul_Firmware(versionStr,60);
    fprintf(stdout, "\nFirmware\t%s\n", versionStr);
    zul_Hardware(versionStr,60);
    fprintf(stdout, "Hardware\t%s\n", versionStr);
    zul_Bootloader(versionStr,60);
    fprintf(stdout, "Bootloader\t%s\n", versionStr);
    zul_Customization(versionStr,60);
    fprintf(stdout, "Customization\t%s\n", versionStr);
}


void addDetailToListEntry(char *pAddrStr, char *record)
{
    ZyConfFile *zcf = new ZyConfFile(NULL);
    zcf->ReadFile();

    if ( strstr (record, " APP") != NULL )      // Consider BL devices
    {
        // connect to this device, and fetch the extra data
        int retVal = zul_openDeviceByAddr(pAddrStr);
        if (retVal == 0)
        {
            char    versionStr[60]  = "";
            char    cpuStr[60]      = "";
            char    monName[16]     = "";
            char    monParam[20]     = "";

            char   *detailPtr = record + strlen(record);

            zul_Hardware(versionStr,60);
            if (SUCCESS == zul_CpuID(cpuStr,60))
            {
                // fetch the controller-monitor binding
                if (zcf->GetString(cpuStr, monName, 10))
                {
                    zcf->GetString(monName, monParam, 20);
                }

                // append the details to the record string
                sprintf( detailPtr, " %-18s %-25s /dev/input/event%-3d %-5s %s",
                         versionStr, cpuStr, getTouchEventPathIndex(cpuStr), monName, monParam);

            }
            else
            {
                strcpy(cpuStr,   "........................");
                strcpy(monName,  "....");
                strcpy(monParam, "..........");

                // append the details to the record string
                sprintf( detailPtr, " %-18s %-25s /dev/input/event??  %-5s %s",
                         versionStr, cpuStr, monName, monParam);
            }

            zul_closeDevice();
        }
    }

    delete zcf;
}

// ToDo - push this service down to services.c
// example output (fields should be vertically aligned):
//  4. VID:14C8 PID:0014 Addr=03_17 ZXY150 APP ZXY150-U-OFF-64-A    4F0041000251343035343036  /dev/input/event14 HDMI1
void cliCmdFullList(void)
{
    // Any changes to this function may need to be mirrored in getDeviceAddrFromKey()

    // This function lists all Zytronic devices, with a blend of
    // information from 'device' and 'binding'
    //
    // It prevents the user needed 3 separate ZyConfig calls to get the data
    int         deviceCount;
    char        buffer[2000];   // for all devices
    char        record[200];    // used to build a description of each device
    char       *bufPtr;

    // close the device opened in main()
    zul_closeDevice();

    // get a new list, which can be augmented
    deviceCount = zul_getDeviceList(buffer, 2000);

    bufPtr = buffer;
    for (int x=0; x<deviceCount; x++)
    {
        char       *pAddrStr;
        char       *cPtr;

        strncpy ( record, bufPtr, 199 );
        record[199] = '\0';
        cPtr = strchr(record, '\n');
        if (cPtr != NULL)
        {
            *cPtr = '\0';   // record holds first line of buffer report
        }

        // find the device address
        pAddrStr = strstr (bufPtr, "Addr=");
        if (pAddrStr != NULL)
        {
            pAddrStr += 5;
            pAddrStr[5] = '\0';
            bufPtr = pAddrStr + 10;

            addDetailToListEntry(pAddrStr, record);
            puts(record);
        }

        bufPtr = strchr(bufPtr, '\n');
        if (bufPtr == NULL) break;
        bufPtr ++;
    }
}


int cliCommandParse(QStringList *args)
{
    int retVal = SUCCESS;
    int numArgs = args->size();

    if(0 == QString::compare(args->at(1), "RAWVIEW"))
    {
        cliCmdRawView(args);
    }

    // also consider "TEST_SENSOR", "INTEGRATION_TEST", "TEST_INTEGRATION", INTEGRATION_TESTS"
    // else if(0 == QString::compare(cmdline_args.at(1), "SENSOR_TEST")) { }

    else if(0 == QString::compare(args->at(1), "CALIBRATE"))
    {
        cliCmdCalibrate(args);
    }

    else if(0 == QString::compare(args->at(1), "FIRMWARE"))
    {
        QString fName = NULL;
        if (numArgs > 2)
        {
            fName = args->at(2);
        }

        cliCmdFirmwareUpdate(fName);
    }

    else if(0 == QString::compare(args->at(1), "SAVE"))
    {
        // Save the configuration to file
        ConfigSaveDialog setupDialog;

        if (numArgs > 2)
        {
            setupDialog.setFileName(&args->at(2));
        }
        else
        {
            setupDialog.autoFileName();
        }

        setupDialog.exec();
    }

    else if(0 == QString::compare(args->at(1), "LOAD"))
    {
        // load a config file to the controller
        ConfigLoadDialog setupDialog;
        if (numArgs > 2)
        {
            setupDialog.setFileName(&args->at(2));
        }

        if (numArgs > 3)
        {
            setupDialog.setForce(&args->at(3));
        }

        setupDialog.exec();
    }

    else if(0 == QString::compare(args->at(1), "SET"))
    {
        return cliCmdSet(args);
    }

    else if(0 == QString::compare(args->at(1), "GET"))
    {
        return cliCmdGet(args);
    }

    else if(0 == QString::compare(args->at(1), "STATUS"))
    {
        return cliCmdStatus(args);
    }


    else if(0 == QString::compare(args->at(1), "RESTORE_DEFAULTS"))
    {
        cliCmdRestoreDefaults();
    }

    else if(0 == QString::compare(args->at(1), "FORCE_EQUALIZATION"))
    {
        zul_forceEqualisation();
    }

    else if(0 == QString::compare(args->at(1), "RESET"))
    {
        zul_resetController();
    }

    // duplicate - left for Windows compatibility
    else if(0 == QString::compare(args->at(1), "VERSIONS"))
    {
        cliCmdDevice();
    }
    else if(0 == QString::compare(args->at(1), "DEVICE"))
    {
        cliCmdDevice();
    }

    else if(0 == QString::compare(args->at(1), "BINDING"))
    {
        cliCmdBinding();
    }

    else if((0 == QString::compare(args->at(1), "LIST")) ||
            (0 == QString::compare(args->at(1), "FULLLIST")))
    {
        cliCmdFullList();
    }

    else if(0 == QString::compare(args->at(1), "HELP"))
    {
        cliCmdHelp();
    }
    else if(0 == QString::compare(args->at(1), "ABOUT"))
    {
        cliCmdAbout();
    }
    else if(0 == QString::compare(args->at(1), "SUGGESTIONS"))
    {
        cliCmdSuggestions();
    }

    else
    {
        fprintf(stderr, "\nUnrecognised command '%s'\n", args->at(1).toLatin1().data());
        retVal = FAILURE;
    }

    return retVal;
}

// === ZyConfMain Class =======================================================

ZyConfMain::ZyConfMain()
{
    const int appWidth = 780;
    const int appHeight = 500;

    if (DebugApp) fprintf(stderr, "Instantiating ZYConfMain\n");

    currentState = NotInitialized;
    createStatusBar();
    setCentralWidget(createCentralWidget());
    setWindowIcon(QIcon(":/images/Zytronic.ico"));
    QString appVersions = getVersionText();
    g_appVersions = appVersions;

    setWindowTitle(QObject::tr("ZyConfig") + "  " + appVersions);

    /*
    Getting everything to fit in effectively is hard work, with so many size
    policies and limits. We wish to define things such that they do what we want
    even if a future Qt version changes widget/text sizes somehow. An annoying
    default in Qt is that the default height is  2/3 of the screen, which means
    the page is very tall on a square(ish) monitor. This results in a non-square
    test sensor grid as the "setHeightForWidth" flag seems to be overruled. By
    setting the max size here we overcome the 2/3 screen height limit but still
    allow items to move around a little. The values selected here fit ZyConfig
    on 800x600 and give a square test sensor grid (as things stand).
    */
    this->setFixedSize(appWidth, appHeight);

    QDesktopWidget* desktop = QApplication::desktop();
    int width = desktop->width();
    int height = desktop->height();
    if (height - appHeight)
    {
        int xCorner = (width - appWidth)/2;
        int yCorner = (height - appHeight)/2;
        this->move(xCorner, yCorner);
    }

    this->setFocusPolicy(Qt::StrongFocus);
    if (g_alwaysOnTop)    // see command line arg "TOP"
    {
        this->setWindowFlags(Qt::WindowStaysOnTopHint);
    }

    firmwareUpdateContent   = NULL;
    installWizardContent    = NULL;
    installWizardPage       = NULL;
    manualSetupPage         = NULL;

    pollLedTimer    = NULL;
    pollConnected   = NULL;

    createConnections();
}


void ZyConfMain::setTabEnable(QWidget *w, bool enable)
{
    if (w)
    {
        int index = tabContainer->indexOf(w);
        if (index != -1)
        {
            tabContainer->setTabEnabled(index, enable);
        }
    }
}


void ZyConfMain::fwXfrStateInd(bool running)
{
    bool tabEnable = !running;

    if (DebugApp) fprintf( stderr, "%s - running:%d\n", __FUNCTION__, running );

    setTabEnable(installWizardPage, tabEnable);
    setTabEnable(manualSetupPage,   tabEnable);
    setTabEnable(aboutPage,         tabEnable);
}


const int HOLD_ON_COUNT = 5;
void ZyConfMain::pollForLEDs_ZXY100()
{
    static int  holdON = 0;         // persist the status

    static uint16_t equalCount  = 0;
    static uint16_t noiseCount  = 0;

    uint16_t        status      = 0;

    static int      xfrErrorCount = 0;
    bool            fwXfrActive = firmwareUpdateContent->fwXfrActive();

    setLED( led1, "Touch",      Qt::black);
    setLED( led3, "Noise",      Qt::black);
    setLED( led0, "Equalizing", Qt::black);
    setLED( led2, "NR",         Qt::black);
    if (g_devPID == ZXY110_PRODUCT_ID)
    {
        setLED( led3, "Palm",      Qt::black);
    }

    if (DebugApp > 1) fprintf(stderr, "App -- LED inhibit:%d [state:%d] FW_xfr:%d\n",
            g_inhibitLEDPoll, currentState, fwXfrActive);
    if (g_inhibitLEDPoll) return;

    if ( (Connected == currentState) && (fwXfrActive == false) )
    {
        if (g_devPID == ZXY110_PRODUCT_ID)
        {
            if (zul_getStatusByID( ZXY110_SI_LED_STATUS, &status )) {
                xfrErrorCount = 0;
            } else {
                xfrErrorCount ++;
            }
            if (DebugApp>1) printf("ZXY110 LED state %04x %04x\n", status, (status & 0x0002)  );
            setLED( led1, ((status & 0x0002) > 0) ? Qt::green :   Qt::black );  // TOUCH
            setLED( led0, ((status & 0x0001) > 0) ? Qt::green :   Qt::black );  // EQ | FTM | FreqHop
            setLED( led3, ((status & 0x0008) > 0) ? Qt::green :   Qt::black );  // Palm
        }
        else
        {
            Zxy100TouchReport   tr;
            Zxy100SysReport     sr;

            // get the touch report
            if (zul_getOldTouchReport(&tr))
            {
                // no persistence required
                setLED( led1, (tr.flags == 0x07) ? Qt::green  :   Qt::black );
                xfrErrorCount = 0;
            }
            else
            {
                xfrErrorCount++;
            }

            // get the system report
            if (zul_getOldSysReport(&sr))
            {
                xfrErrorCount = 0;

                // we'd like these report to be visible longer than the polling interval
                QColor persistCol;

                persistCol = (holdON) ? led0->palette().color(QPalette::Window) : Qt::black;
                setLED( led0, sr.numEqualizations > equalCount ? Qt::yellow :   persistCol );
                if (sr.numEqualizations > equalCount) holdON = HOLD_ON_COUNT;
                equalCount = sr.numEqualizations;

                persistCol = (holdON) ? led2->palette().color(QPalette::Window) : Qt::black;
                setLED( led2, sr.numNoiseRecoveryEvents > noiseCount ? Qt::red : persistCol );
                if (sr.numNoiseRecoveryEvents > noiseCount) holdON = HOLD_ON_COUNT;
                noiseCount = sr.numNoiseRecoveryEvents;

                persistCol = (holdON) ? led3->palette().color(QPalette::Window) : Qt::black;
                int noisy = zul_getNoiseAlgoMetric(&sr);
                if (noisy) holdON = HOLD_ON_COUNT;
                setLED( led3, "Noise", noisy ? Qt::yellow : persistCol );
            }
            else
            {
                xfrErrorCount++;
            }
        }

        if (xfrErrorCount>3)
        {
            zul_closeDevice();
            setState(NotConnected);
            if (infoDispl) infoDispl->clearControllerInfo();

            // terminate application if we loose connection
            g_mainWindow->close();
        }
    }

    if (holdON) holdON--;
}

void ZyConfMain::pollForLEDs_ZXY_MT()
{
    static const QString led0causes[] =
            { "-", "FirstTouch", "Noise", "Fault", "Equalizing","5", "6", "7" };
    static const QString led2causes[] =
            { "-", "Failsafe", "No Sensor", "3", "4","5", "6", "7" };
    static int xfrErrorCount    = 0;

    uint16_t status=0;
    uint16_t onFlag = 1, causeMask = 0x0070;
    bool ledOn[4];
    uint8_t ledCause[4];

    if (DebugApp > 1) fprintf(stderr, "App -- LED check\n");
    if (g_inhibitLEDPoll) return;
    if (DebugApp > 1) fprintf(stderr, "    -- LED Poll\n");

    if ( (Connected == currentState) && (firmwareUpdateContent->fwXfrActive() == false) )
    {
        if (zul_getStatusByID( ZXYMT_SI_STATUS_LEDS, &status ))
        {
            xfrErrorCount = 0;
        }
        else
        {
            xfrErrorCount ++;
        }
    }
    else
    {
        status = 0;
    }

    // disconnect if 3 polls in a row have failed, currently 3 seconds
    if (xfrErrorCount>3)
    {
        zul_closeDevice();
        setState(NotConnected);
        if (infoDispl) infoDispl->clearControllerInfo();

        // terminate application if we loose connection
        g_mainWindow->close();
    }

    for ( int x = 0; x<4; x++)
    {
        ledOn[x] = status & onFlag;
        ledCause[x] = (uint8_t)((status & causeMask) >> (4+x*3));

        if (DebugApp>1) fprintf (stderr, "STATUS=0x%04x || %x %04x : %x %04x\n" ,
                status, onFlag, causeMask, ledOn[x], ledCause[x]);

        onFlag <<=1;
        causeMask <<=3;
    }

    setLED( led0, led0causes[ledCause[0]]);

    setLED( led2, led2causes[1]);

    //GUI ORDER   1302
    if(ledOn[0])
    {
        setLED(led0, Qt::yellow);
    }
    else
    {
        setLED(led0, Qt::black);
    }

    if(ledOn[1])
    {
        setLED(led1, Qt::green);
    }
    else
    {
        setLED(led1, Qt::black);
    }

    if(ledOn[2])
    {
        if( zul_isZXY500AppPID(&g_devPID))
        {
            uint16_t failsafeReason;
            if (zul_getStatusByID( ZXYMT_SI_FAILSAFE_REASON, &failsafeReason))
            {
                if( failsafeReason == FAILSAFE_SENSOR_MISSING)
                {
                    setLED(led2, led2causes[2]); // no sensor

                    if (getShowNoSensor() == true)
                    {
                        setShowNoSensor(false);

                        // display failsafe no sensor information (once per connection)
                        QString message = tr ( "The touch controller has detected that there is no sensor attached.\n\n" );
                        message.append(tr("To fix this:") + "\n");
                        message.append("\t" + tr("1) Remove power to the touch controller") + "\n");
                        message.append("\t" + tr("2) Connect a sensor to the touch controller") + "\n");
                        message.append("\t" + tr("3) Connect power to the touch controller") + "\n\n");

                        QMessageBox msgBox;
                        msgBox.setWindowTitle(tr("WARNING - FailSafe"));
                        msgBox.setText( message );
                        msgBox.setInformativeText( tr("CAUTION: Connecting OR Removing a sensor without removing power may damage the touch controller.") + "\n");
                        msgBox.setStandardButtons(QMessageBox::Ok);
                        msgBox.setDefaultButton(QMessageBox::Save);
                        msgBox.setIcon(QMessageBox::Warning);

                        QPoint parentPos = this->pos();
                        msgBox.move( parentPos + QPoint( 50, 50 ) );
                        msgBox.exec();
                    }
                }
            }
        }
        setLED(led2, Qt::red);
    }
    else
    {
        setLED(led2, Qt::black);
    }

    if(ledOn[3])
    {
        setLED(led3, Qt::yellow);
    }
    else
    {
        setLED(led3, Qt::black);
    }
}

void ZyConfMain::setupTimers()
{
    if (pollConnected == NULL)
    {
        //create timer to poll for new device
        pollConnected = new QTimer(this);
        pollConnected->setInterval(500);    // milliseconds
        pollConnected->setSingleShot(false);
        QObject::connect(pollConnected, SIGNAL(timeout()),
                         this, SLOT(pollForConnection()));
        pollConnected->start();
        if (DebugApp) printf("pollForConnection  setup\n");
    }

    // read the LEDs status from connected controller periodically
    if (pollLedTimer == NULL)
    {
        pollLedTimer = new QTimer(this);
        pollLedTimer->setInterval(100);     // milliseconds
        pollLedTimer->setSingleShot(false);
        pollLedTimer->start();
        if (DebugApp) printf("pollLedTimer setup\n");
    }
}

// some key-chords ALT-zts were special ..
bool ZyConfMain::event(QEvent *event)
{
    if (QEvent::KeyPress == event->type())
    {
        if (Qt::AltModifier == ((QKeyEvent *)event)->modifiers())
        {
        }
        else
        {
        }
    }

    if (QEvent::KeyRelease == event->type())
    {
        if (Qt::NoModifier == ((QKeyEvent *)event)->modifiers())
        {
        }
    }

    if (QEvent::Shortcut == event->type())
    {
    }

    return QMainWindow::event(event);
}

#define LEDW (50)
void ZyConfMain::setLED(QLabel *led, QColor c)
{
    led->setMinimumWidth(LEDW);
    if (c == Qt::black)
    {
        led->setStyleSheet("QLabel { background-color: rgb(240, 240, 240); "
                                            "color: rgb(240, 240, 240); }" );
        //"QLabel { background-color: lightGray; color: lightGray; }" );
    }

    if (c == Qt::green)
    {
        led->setStyleSheet("QLabel { background-color : green; "
                                                        "color : white; }");
    }

    if (c == Qt::yellow)
    {
        led->setStyleSheet("QLabel { background-color : darkOrange; "
                                                        "color : white; }");
    }

    if (c == Qt::red)
    {
        led->setStyleSheet("QLabel { background-color : red; "
                                                        "color : white; }");
    }

    led->update();
}

void ZyConfMain::setLED(QLabel *led, QString txt)
{
    static QFont *f = NULL;
    if (f == NULL)
    {
        f = new QFont ( led->font() );
        f->setPointSize(8);
        f->setBold(true);
    }
    led->setAlignment(Qt::AlignHCenter);
    led->setFont(*f);
    led->setText(txt);
    led->setMargin(1);
}

void ZyConfMain::setLED(QLabel *led, QString txt, QColor c)
{
    setLED(led, txt);
    setLED(led, c);
}



QWidget *ZyConfMain::createCentralWidget()
{
    QWidget *central = new QWidget(this);
    QString vers = getVersionText();

    led0 = new QLabel("L0");
    setLED(led0,  "Fault",   Qt::black );// Qt::yellow);
    led1 = new QLabel("L1");
    setLED(led1,  "Touch",   Qt::black );// Qt::green );
    led2 = new QLabel("L2");
    setLED(led2,  "-",       Qt::black );// Qt::green );
    led3 = new QLabel("L3");
    setLED(led3,  "Palm",    Qt::black );// Qt::yellow);

    tabContainer = new QTabWidget(central);
    tabContainer->setStyleSheet("QTabBar::tab { height: 30px; } "
            "QTabWidget::tab-bar {  left: 5px; top: 2px; alignment: left; } ");

    aboutPage = new AboutPage(tabContainer, &vers);

    tabContainer->addTab(aboutPage, tr("About"));

    QVBoxLayout *centralLayout = new QVBoxLayout;
    centralLayout->addWidget(tabContainer);
    infoDispl = new SysInfoDisplay(central);
    centralLayout->addWidget(infoDispl);

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout->addWidget(led1);
    bottomLayout->addWidget(led3);
    bottomLayout->addWidget(led0);
    bottomLayout->addWidget(led2);
    bottomLayout->addStretch();
    bottomLayout->addWidget(apiStatus);
    bottomLayout->setMargin(2);
    bottomLayout->setSpacing(4);

    centralLayout->addLayout(bottomLayout);
    centralLayout->setMargin(0);
    centralLayout->setSpacing(0);

    central->setLayout(centralLayout);

    return central;
}

void ZyConfMain::createStatusBar()
{
    status = new QLabel(tr("No touchscreen attached."));
    apiStatus = new ZytAPIResult(this);
}

void ZyConfMain::setState(ZyConfMain::guiState state)
{
    currentState = state;
    g_inhibitLEDPoll = true;

    tabContainer->clear();
    if (pollLedTimer != NULL)
    {
        QObject::disconnect( pollLedTimer, 0,0,0 );
    }

    if (firmwareUpdateContent != NULL)
    {
        QObject::disconnect(firmwareUpdateContent, 0,0,0 );
        delete firmwareUpdateContent;
        firmwareUpdateContent = NULL;
    }
    if (installWizardContent != NULL)
    {
        QObject::disconnect(installWizardContent, 0,0,0 );
        delete installWizardContent;
        installWizardContent = NULL;
    }
    if (installWizardPage != NULL)
    {
        delete installWizardPage;
        installWizardPage = NULL;
    }
    if (manualSetupPage != NULL)
    {
        delete manualSetupPage;
        manualSetupPage = NULL;
    }

    setupTimers();

    switch(state)
    {
        case Connected:
            installWizardContent = new InstallWizard(this);
            installWizardPage = new ZytConfigPage(tr("Install Wizard"),
                                            installWizardContent, tabContainer);

            manualSetupPage = new ManualSetup(this);

            firmwareUpdateContent = new FirmwareUpdate(this);
            firmwareUpdatePage = new ZytConfigPage(tr("Firmware Update"),
                                         firmwareUpdateContent, tabContainer);

            // Install Wizard Page //

            installWizardContent->setLEDPoll(&g_inhibitLEDPoll);
            installWizardContent->setAppVersionStrs( g_appVersions );

            QObject::connect(installWizardContent, SIGNAL(reReadAxesReq()),
                             manualSetupPage, SLOT(reReadValues()));

            QObject::connect(installWizardContent, SIGNAL(reReadThresholds()),
                             manualSetupPage, SLOT(reReadValues()));

            QObject::connect(installWizardContent, SIGNAL(pauseConnectionCheck(bool)),
                             this, SLOT(pauseConnectionCheck(bool)));

            QObject::connect(installWizardContent, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                             apiStatus, SLOT(displayResult(ZytAPIResult::ResultState)));

            if ( (g_devPID == ZXY100_PRODUCT_ID) || (g_devPID == ZXY110_PRODUCT_ID) )
            {
                installWizardContent->setZXY100Data(&g_zxy100Data);
                QObject::connect(pollLedTimer, SIGNAL(timeout()),
                                 this, SLOT(pollForLEDs_ZXY100()));
            }
            else
            {
                installWizardContent->setZXY100Data(NULL);
                QObject::connect(pollLedTimer, SIGNAL(timeout()),
                                 this, SLOT(pollForLEDs_ZXY_MT()));
            }

            // Manual Setup Page //

            manualSetupPage->setStyleSheet("QTabBar::tab { height: 30px; } "
                    "QTabWidget::tab-bar { left: 5px; alignment: left; } ");
            manualSetupPage->passZxy100Data(&g_zxy100Data);
            manualSetupPage->setLEDPoll(&g_inhibitLEDPoll);

            QObject::connect(manualSetupPage, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                             apiStatus, SLOT(displayResult(ZytAPIResult::ResultState)));

            // Firmware Update Page //

            firmwareUpdatePage->setVisible( false );

            QObject::connect(firmwareUpdateContent , SIGNAL(reReadRequired()),
                             this, SLOT(reReadValues()));

            QObject::connect(firmwareUpdateContent, SIGNAL(pauseConnectionCheck(bool)),
                             this, SLOT(pauseConnectionCheck(bool)));

            QObject::connect(firmwareUpdateContent, SIGNAL(signalFwXfrState(bool)),
                             this, SLOT(fwXfrStateInd(bool)));

            QObject::connect(firmwareUpdateContent, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                             apiStatus, SLOT(displayResult(ZytAPIResult::ResultState)));

            QObject::connect(firmwareUpdateContent, SIGNAL(APIResult(QString, ZytAPIResult::ResultState)),
                             apiStatus, SLOT(displayResult(QString, ZytAPIResult::ResultState)));

            // Tab Setup //

            tabContainer->addTab(installWizardPage,  tr("Install Wizard"));
            tabContainer->addTab(manualSetupPage,    tr("Manual Setup"));
            tabContainer->addTab(firmwareUpdatePage, tr("Firmware Update"));
            tabContainer->addTab(aboutPage,          tr("About"));

            tabContainer->setCurrentWidget(installWizardPage);
            tabContainer->setCurrentIndex(tabContainer->indexOf(installWizardPage));

            status->setText(tr("Connected to touchscreen controller."));

            g_inhibitLEDPoll = false;
            break;

        case UpdateOnly:

            firmwareUpdateContent = new FirmwareUpdate(this);
            firmwareUpdatePage = new ZytConfigPage(tr("Firmware Update"),
                                         firmwareUpdateContent, tabContainer);
            firmwareUpdatePage->setVisible( false );

            tabContainer->addTab(firmwareUpdatePage, tr("Firmware Update"));
            tabContainer->addTab(aboutPage,          tr("About"));

            QObject::connect(firmwareUpdateContent , SIGNAL(reReadRequired()),
                             this, SLOT(reReadValues()));

            status->setText(tr("Connected to Bootloader device."));

            break;

        case Wizard:
        case NotConnected:
            // intended fall-through

        default:
            tabContainer->addTab(aboutPage, tr("&About"));
            tabContainer->setCurrentWidget(aboutPage);

            status->setText(tr("No touchscreen attached."));

            g_devPID = UNKNWN_PRODUCT_ID;
    }

    infoDispl->refreshTouchInfo();
    if (DebugApp) fprintf(stderr, "%s - %s\n", __FUNCTION__, infoDispl->getTouchInfo().toUtf8().constData() );
}

ZyConfMain::guiState ZyConfMain::getGUIState(uint16_t PID)
{
    ZyConfMain::guiState    returnState = ZyConfMain::NotInitialized;

    bool        firmwareCompatible  = fwIsCompatible(PID);
    bool        applicationRunning  = true;
    bool        onboardCalAvailable = false;

    if (zul_isBLDevicePID(PID))
    {
        applicationRunning  = false;
    }

    // test the on-board cal option is available
    if (firmwareCompatible && applicationRunning)
    {
        // So far (2018), all devices use the same bit in the register for ON BOARD CAL
        onboardCalAvailable = zul_optionAvailable (ZXYMT_OPT_BIT_ON_BOARD_CAL);

        // read a second time - ZXY110 provides odd results when just connected (TBC)
        onboardCalAvailable = zul_optionAvailable (ZXYMT_OPT_BIT_ON_BOARD_CAL);

        if (!onboardCalAvailable)
        {
            fprintf (stderr, "Option ON_BOARD_CALIBRATION is not available in this device's firmware\n");
        }
    }

    if (onboardCalAvailable)
    {
        returnState = ZyConfMain::Connected;
    }
    else
    {
        returnState = ZyConfMain::UpdateOnly;
    }

    if (DebugApp) fprintf(stderr, "%s GUI State %d\n", __FUNCTION__, returnState);
    return returnState;
}

void ZyConfMain::displayFwWarningDialogue(int16_t PID)
{
    QMessageBox msgBox;

    if (zul_isBLDevicePID(PID))
    {
        msgBox.setText(tr("Application Missing"));
        msgBox.setInformativeText(
            tr ( "Please update the firmware before continuing.\n\n" ) );
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Save);
        msgBox.setIcon(QMessageBox::Warning);
    }
    else
    {
        msgBox.setText(tr("Old firmware detected"));
        msgBox.setInformativeText(
            tr ( "Please update the firmware before using this version of ZyConfig.\n\n" )  +
            tr ( "You can save your configuration using the command line 'save' "
                "option prior to firmware update." ) );
        msgBox.setStandardButtons(QMessageBox::Ok);
        msgBox.setDefaultButton(QMessageBox::Save);
        msgBox.setIcon(QMessageBox::Warning);
    }

    QPoint parentPos = this->pos();
    msgBox.move( parentPos + QPoint( 50, 50 ) );
    msgBox.exec();
}


void ZyConfMain::reReadValues()
{
    int16_t PID = -1;
    if ( zul_getDevicePID(&PID) )
    {
        g_devPID = PID;
        setState(getGUIState(g_devPID));
    }
    else
    {
        setState( NotConnected );
    }

    if ( zul_isZXY500AppPID(&PID) )
    {
        QCoreApplication::setAttribute( Qt::AA_SynthesizeMouseForUnhandledTouchEvents, true);
    }
    else
    {
        QCoreApplication::setAttribute( Qt::AA_SynthesizeMouseForUnhandledTouchEvents, false);
    }

    if (currentState == UpdateOnly)
    {
        displayFwWarningDialogue(PID);
    }

    // tell the upper threshold and palm threshold frames under
    // manual setup to update their values

}

void ZyConfMain::pollForConnection()
{
    int         deviceCount = 0;
    char        buffer[2000 + 1];
    static int  dotCount = 0;
    char checkMsg[] = "Checking for new device .....";

    if (currentState >= UpdateOnly ) return; // connection exists

    checkMsg[25 + dotCount++] = '\0';
    dotCount %= 3;
    if (DebugApp) fprintf(stderr, "%s   \r", checkMsg );
    deviceCount = zul_getDeviceList(buffer, 2000);

    if (g_selectedAddrStr[0] != '\0')   // string not empty
    {
        if (DebugApp) printf ("Attempting to open USB device @ %s... ", g_selectedAddrStr);

        if (strstr(buffer, g_selectedAddrStr))
        {
            // create a record of which input nodes are used for various controller UniqueIDs
            cacheTouchEventPaths();

            if (0 == zul_openDeviceByAddr(g_selectedAddrStr))
            {
                g_zxy100Data.refreshInfo();
                g_mainWindow->reReadValues();
            }
            return;
        }
        else
        {
            g_selectedAddrStr[0] = '\0';
        }
    }

    if (deviceCount <= 0)
    {
        // fprintf(stderr, "No Zytronic device found\n");
        return;
    }

    if (g_selectedAddrStr[0] == 0)
    {
        char *autoAddr = strstr(buffer, "Addr=");
        if (autoAddr == NULL)
        {
            printf("Unlikely! Address not found when one or more devices found.\n");
            exit ( EXIT_FAILURE );
        }
        else
        {
            strncpy( g_selectedAddrStr, autoAddr+5, 5 );    // expecting bb_pp format
            if (DebugApp)
            {
                printf("Autoselecting device at USB address %s\n", g_selectedAddrStr);
            }
        }
    }

//    printf ("Found [%d]                           \n%s\n", deviceCount, buffer);
//    int deviceIndex = atoi(buffer);
//    if (DebugApp) printf ("Attempting to open device #%d... ", deviceIndex);
//    zul_openDevice(deviceIndex);
//    g_mainWindow->reReadValues();
}

void  ZyConfMain::pauseConnectionCheck(bool pause)
{
    if (pause && pollConnected->isActive())
    {
        if (DebugApp) printf("Conn Check Stop\n");
        pollConnected->stop();
    }
    if ((!pause) && (!pollConnected->isActive()))
    {
        if (DebugApp) printf("Conn Check Start\n");
        pollConnected->start();
    }
}

void ZyConfMain::reReadThresholds()
{
    // tell the sensitivity panel to re-read thresholds
    if(manualSetupPage != NULL)
    {
        manualSetupPage->reReadValues();
        manualSetupPage->reReadAxes();
    }
}

void ZyConfMain::createConnections()
{
    // Connections now made dynamically
}

void ZyConfMain::closeEvent(QCloseEvent *event)
{
    if(QEvent::Close == event->type())
    {
        pollConnected->stop();
        pollLedTimer->stop();

        zul_EndServices();
    }
    QMainWindow::closeEvent(event);
}



char * getDeviceAddrFromKey(char* devKey)
{
    int     deviceCount;
    char    buffer[2000];   // for all devices
    char    record[200];    // used to build a description of each device
    char    *bufPtr;
    char    *retStr = NULL;

    // get a new list, which can be augmented
    deviceCount = zul_getDeviceList(buffer, 2000);

    bufPtr = buffer;
    for (int x=0; x<deviceCount; x++)
    {
        char       *pAddrStr;
        char       *cPtr;

        strncpy ( record, bufPtr, 199 );
        record[199] = '\0';
        cPtr = strchr(record, '\n');
        if (cPtr != NULL)
        {
            // replace the '\n' with '\0'
            *cPtr = '\0';
        }

        // find the device address
        pAddrStr = strstr (bufPtr, "Addr=");
        if (pAddrStr != NULL)
        {
            pAddrStr += 5;
            pAddrStr[5] = '\0';
            bufPtr = pAddrStr + 10;

            addDetailToListEntry(pAddrStr, record);

            if (strstr(record, devKey) != NULL)
            {
                // return the address of the controller that matches the devKey
                retStr = pAddrStr;
                break;
            }
        }

        // set the pointer to that of the next end of the line character
        bufPtr = strchr(bufPtr, '\n');
        if (bufPtr == NULL) break;
        bufPtr ++;
    }

    return retStr;
}

// === END ZyConfMain Class ===================================================

void quickStop(void)
{
    /* This oddity is due to an issue found on CentOS 7.5.1804 where the app sometimes stalls on exit:
     *
     * #0  0x00007ffff5c62a47 in sched_yield () at ../sysdeps/unix/syscall-template.S:81
     * #1  0x00007fffde6a9d19 in nouveau_fence_wait (fence=fence@entry=0x7c0130, debug=debug@entry=0x0) at nouveau_fence.c:216
     * #2  0x00007fffde7b6dc0 in nvc0_screen_destroy (pscreen=0x7bf3a0) at nvc0/nvc0_screen.c:537
     * #3..9 r:icompressed:  dri_destroy_screen_helper dri_destroy_screen  driDestroyScreen dri3_destroy_screen FreeScreenConfigs glx_display_free __glXCloseDisplay
     * #10 0x00007ffff0dedd22 in XCloseDisplay (dpy=0x6c9070) at ClDisplay.c:65
     *
     * As the exit delay is not triggered when Ctrl-c is used ... SIGINT is raised here, removing the delay.
     */
    raise(SIGINT);
    sleep(1);
}


int main(int argc, char *argv[])
{
    char        verStr[200 + 1];
    int         deviceCount = 0;
    char        buffer[2000 + 1];
    int16_t     PID;
    int         deviceIndex = -1;

    if (DebugApp) zul_setLogLevel(LibDebugLvl);

    int retVal = zul_InitServices();        // open the comms library
    if (retVal != 0)
    {
        fprintf(stderr, "Error opening the library (%d)\n", retVal);
        exit( EXIT_FAILURE );
    }
    else
    {
        zul_getVersion(verStr,200);
        verStr[200] = '\0';
        deviceCount = zul_getDeviceList(buffer, 2000);
    }

    char * deviceTargetKey = zul_removeDeviceTargetKey(&argc, argv);
    char * deviceTargetAddr;
    if (deviceTargetKey == NULL)
    {
        // legacy "Addr=" selector
        deviceTargetAddr = zul_removeDeviceTargetAddr(&argc, argv);
    }

    QApplication app(argc, argv);

    bool root = false;

    // check if we are root
    if (0 == system("id -u | grep ^0$ > /dev/null"))
    {
        root = true;
    }

    // some program arguments can be processed without being root
    if (argc > 1)
    {
        if ( 0 == strcasecmp(argv[1], "version") )
        {
            cliCmdAppVersion(verStr);
            exit( EXIT_SUCCESS );
        }

        if ( 0 == strcasecmp(argv[1], "list") && !root)
        {
            if (deviceCount == 0)
            {
                printf("There are no Zytronic devices connected\n");
            }
            else
            {
                if (deviceCount >= 1)
                {
                    printf("%d Zytronic device(s) found:\n", deviceCount);
                }
                printf("%s\n", buffer);
                printf("For the long format report on the devices shown above, try running the command as root.\n\n");
            }

            exit( EXIT_SUCCESS );
        }

        if ( 0 == strcasecmp(argv[1], "about") )
        {
            cliCmdAbout();
            exit( EXIT_SUCCESS );
        }

        if ( 0 == strcasecmp(argv[1], "help") )
        {
            cliCmdHelp();
            exit( EXIT_SUCCESS );
        }

        if ( 0 == strcasecmp(argv[1], "suggestions") )
        {
            cliCmdSuggestions();
            exit( EXIT_SUCCESS );
        }

        if ( 0 == strcasecmp(argv[1], "display") )
        {
            cliCmdDisplay();
            exit( EXIT_SUCCESS );
        }
    }

    if (deviceCount < 0)
    {
        fprintf(stderr, "Error [%d] while attempting to get list of Zytronic USB devices.\n", deviceCount );
    }

    {
        int rv = init_handlers();
        if (rv != SUCCESS)
        {
            fprintf(stderr, "Failed to initialise program handlers.\n");
            exit (rv);
        }
    }

    if (deviceCount == 0)
    {
        fprintf(stderr, "No Zytronic touchscreen controllers have been found on this system.\n");
        return EXIT_SUCCESS;
    }

    // if we are not root, return
    if (!root)
    {
        fprintf(stderr, "This application must be run as root\n");
        exit (EXIT_FAILURE);
    }

    if (deviceTargetKey != NULL)
    {
        deviceTargetAddr = getDeviceAddrFromKey(deviceTargetKey);
        if (deviceTargetAddr == NULL)
        {
            printf("deviceKey not found\n");
            printf("Found Zytronic touchscreen devices:\n");
            cliCmdFullList();
            exit ( EXIT_FAILURE );
        }
    }

    char searchStr[20];

    if (deviceTargetAddr != NULL)
    {
        strcpy( searchStr, "Addr=" );
        strcat( searchStr, deviceTargetAddr );

        // check if this address/key appears in the Zytronic device list
        if (strstr ( buffer, searchStr) != NULL)
        {
            strcpy( g_selectedAddrStr, deviceTargetAddr );
        }
        else
        {
            printf("There is no Zytronic device at supplied address: '%s'\n", deviceTargetAddr);
            if(deviceTargetKey != NULL)
            {
                printf("address implied by device key: '%s'\n", deviceTargetKey);
            }
            exit ( EXIT_FAILURE );
        }
    }

    // create a record of which input nodes are used for various controller UniqueIDs
    cacheTouchEventPaths();

    if (g_selectedAddrStr[0] == 0)
    {
        if( deviceCount == 1)
        {
            char *autoAddr = strstr(buffer, "Addr=");
            if (autoAddr == NULL)
            {
                printf("Unlikely! 'Addr' not found when one devices found\n");
                exit ( EXIT_FAILURE );
            }
            else
            {
                strncpy( g_selectedAddrStr, autoAddr+5, 5 );    // expecting bb_pp format
                if (DebugApp) printf("Autoselecting device at autoAddr %s\n", g_selectedAddrStr);
            }
        }
        else
        {
            // provide the full list if no controller is specified and more than one is found
            printf("Found Zytronic touchscreen devices:\n");
            cliCmdFullList();
            printf("\nUse the deviceKey=<string> option to select a device from above list\n\n");
            exit ( EXIT_FAILURE );
        }
    }

    closeAppLock();     // LCK_FILE - only one copy of program should run at a time

    zul_SetupStandardInHandlers();

    if ((deviceCount > 1) && DebugApp)
    {
        puts("The following Zytronic devices were found:\n");
        puts(buffer);
    }

    QStringList cmdline_args = QCoreApplication::arguments();

    if (DebugApp)   // dump the application args to the console
    {
        std::cout << "Num args = " << argc << std::endl;
        for( int i=0; i<argc; i++)
        {
            std::cout << "cmdline_args.at(" << i << ") = " << cmdline_args.at(i).toLatin1().data() << std::endl;
        }
    }

    // when program has arguments, don't open the main window
    if( cmdline_args.size() > 1 )
    {
        g_inhibitLEDPoll = true;                 // no GUI, no polling needed

        if (strlen(g_selectedAddrStr) == 5)
        {
            retVal = zul_openDeviceByAddr(g_selectedAddrStr);
        }
        else
        {
            fprintf( stderr, "Failed to identify zytronic device\n");
            exit (EXIT_FAILURE);
        }

        if (retVal != 0)
        {
            fprintf(stderr, "Error [%d] opening device index %d.\n", retVal, deviceIndex );
            exit (EXIT_FAILURE);
        }
        else
        {
            if (zul_getDevicePID(&PID))
            {
                g_devPID = PID;
                if (DebugApp) fprintf(stderr, "Connected PID %d (0x%x)\n", PID, PID);
            }
            else
            {
                fprintf( stderr, "Failed to determine Zytronic PID\n");
                exit (EXIT_FAILURE);
            }
        }

        //set upper case in command name
        cmdline_args[1] = cmdline_args.at(1).toUpper();
        //replace an '-'s with '_'s
        cmdline_args[1].replace("-","_");

        int retVal = cliCommandParse(&cmdline_args);
        g_exit_value = retVal;
        quickStop();        // workaround for CentOS issue -- delay on exit

        // it's a widely accepted convention that programs return 0 for success, else an error code.
        return (retVal == SUCCESS) ? EXIT_SUCCESS : EXIT_FAILURE;
    }

    if (1)  // 0 => GUI disabled. Set to 0 for CLI ONLY releases
    {
        g_mainWindow = new ZyConfMain();

        g_mainWindow->setState(ZyConfMain::NotConnected);
        g_mainWindow->showNormal();
        g_mainWindow->raise();
        g_mainWindow->activateWindow();

        retVal = app.exec();
    }
    else
    {
        puts ("No command provided. See help text [$ ./ZyConfig help]");
    }

    close (g_lock_fd);
    unlink(LCK_FILE);

    quickStop();        // workaround for CentOS issue -- delay on exit
    return retVal;
}
