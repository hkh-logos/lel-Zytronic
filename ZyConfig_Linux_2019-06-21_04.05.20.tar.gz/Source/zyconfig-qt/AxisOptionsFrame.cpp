/* AxisOptionsFrame

      This class provides the GUI to change the X and Y cursor motion
      relative to a fingers movement on the sensor.
*/

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "AxisOptionsFrame.h"

#include "zytypes.h"
//#include "comms.h"
#include "zxymt.h"
#include "zxy100.h"
#include "zxy110.h"
#include "services.h"

#define FLEXI_LEFT      (1)
#define FLEXI_TOP       (2)
#define FLEXI_RIGHT     (3)
#define FLEXI_BOTTOM    (4)


AxisOptionsFrame::AxisOptionsFrame(QWidget *parent) :
        ZytContentFrame(parent)
{
    int16_t PID;
    bool deviceConnected = zul_getDevicePID(&PID);
    devPID = PID;

    createWidgets();

    if ( deviceConnected && (!zul_isBLDevicePID(devPID)))
    {
        readFromController();
    }

    createConnections();
    setLayout(createLayout());
}


void AxisOptionsFrame::createWidgets()
{
    // SWAP X & Y AXES
    swapXY      = new QPushButton(tr("&Swap  X-Y  axes"),this);
    swapXY->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_WIDTH*2/3);
    swapXY->setMaximumSize(STD_BUTT_WIDTH+2,STD_BUTT_WIDTH+2);
    swapXY->setCheckable(true);
    swapXY->setFocusPolicy(Qt::ClickFocus);  // NoFocus
    swapXYind   = new QCheckBox("", swapXY);

    //decrease font size
    QFont font = swapXY->font();
    font.setPointSize(font.pointSize() - 2);

    xySwapLabel = new QLabel(tr("Enabling this swaps\nhorizontal movement for\nvertical and vice-versa"));
    xySwapLabel->setWordWrap(true);
    xySwapLabel->setFocusPolicy(Qt::ClickFocus);  // NoFocus
    //xySwapLabel->setMargin(padding);
    xySwapLabel->setMinimumWidth(STD_LABEL_WIDTH*3/2);
    xySwapLabel->setAlignment(Qt::AlignRight);
    xySwapLabel->setFont(font);
    xySwapLabel->setContentsMargins (0,0,230,0);

    // INVERT X AXIS
    invertX     = new QPushButton(tr("Invert  &X  axis"),this);
    invertX->setMaximumSize(STD_BUTT_WIDTH * 3,STD_BUTT_HEIGHT*3/2);
    invertX->setMinimumSize(STD_BUTT_WIDTH * 3,STD_BUTT_HEIGHT*3/2);
    invertX->setCheckable(true);
    invertX->setFocusPolicy(Qt::ClickFocus);  // NoFocus
    invXind     = new QCheckBox("", invertX);

    xFlipLabel  =  new QLabel(tr("Enabling this reverses\nhorizontal movement"));
    xFlipLabel->setWordWrap(true);
    xFlipLabel->setFocusPolicy(Qt::ClickFocus);  // NoFocus
    xFlipLabel->setAlignment(Qt::AlignRight);
    //xFlipLabel->setMargin(padding);
    xFlipLabel->setMinimumWidth(STD_LABEL_WIDTH*3/2);
    xFlipLabel->setFont(font);
    // move it in from the right to align with edge of assocaited button
    xFlipLabel->setContentsMargins (0,0,63,0);

    // INVERT Y AXIS
    invertY     = new QPushButton(tr("Invert\n\n&Y\n\naxis"),this);
    invertY->setMinimumSize(STD_BUTT_HEIGHT*3/2, STD_BUTT_WIDTH * 2);
    invertY->setMaximumSize(STD_BUTT_HEIGHT*3/2, STD_BUTT_WIDTH * 2);
    invertY->setCheckable(true);
    invertY->setFocusPolicy(Qt::ClickFocus);  // NoFocus
    invYind     = new QCheckBox("", invertY);

    yFlipLabel  =  new QLabel(tr("Enabling this reverses\nvertical movement"));
    yFlipLabel->setWordWrap(true);
    yFlipLabel->setFocusPolicy(Qt::ClickFocus);  // NoFocus
    //yFlipLabel->setMargin(padding);
    yFlipLabel->setMinimumWidth(STD_LABEL_WIDTH);
    yFlipLabel->setFont(font);
}


QLayout * AxisOptionsFrame::createLayout()
{
    /* New Symmetric layout style - easier for user to correct bad settings
     * This does work best when the application is centered on the screen
     */

    // Top panel for Invert X
    QVBoxLayout *topLayout = new QVBoxLayout;

    topLayout->addWidget(invertX);
    topLayout->setAlignment(invertX, Qt::AlignHCenter);
    topLayout->addSpacing(1);
    topLayout->addWidget(xFlipLabel);
    topLayout->setAlignment(xFlipLabel, Qt::AlignRight);


    // Top footer
    QHBoxLayout *footerLayoutT = new QHBoxLayout;

    footerLayoutT->setAlignment(Qt::AlignTop);
    footerLayoutT->addStretch();
    footerLayoutT->addWidget(xySwapLabel);

    // Bottom footer
    QHBoxLayout *footerLayoutB = new QHBoxLayout;

    footerLayoutB->setAlignment(Qt::AlignLeft);
    footerLayoutB->addWidget(yFlipLabel);
    footerLayoutB->addStretch();

    // central right panel
    QVBoxLayout *centreLayout = new QVBoxLayout;
    centreLayout->setAlignment(Qt::AlignHCenter);

    centreLayout->addLayout(topLayout);
    centreLayout->addSpacing(30);
    centreLayout->addWidget(swapXY);
    centreLayout->setAlignment(swapXY, Qt::AlignHCenter);
    centreLayout->addSpacing(1);

    centreLayout->addLayout(footerLayoutT);
    centreLayout->addLayout(footerLayoutB);


    // left panel
    QVBoxLayout *leftLayout = new QVBoxLayout;

    leftLayout->addStretch();
    leftLayout->addWidget(invertY);
    leftLayout->addStretch();

    // Main Layout
    QHBoxLayout *mainLayout = new QHBoxLayout;

    mainLayout->setAlignment(Qt::AlignVCenter);

    mainLayout->addSpacing(50);
    mainLayout->addLayout(leftLayout);
    // mainLayout->addSpacing(50);
    mainLayout->addLayout(centreLayout);

    return mainLayout;
}

void AxisOptionsFrame::showOverlay()
{
    int varX, varY;

    varX = swapXY->width() - 25;
    varY = swapXY->height() - 25;
    swapXYind->setGeometry(varX, varY, 20, 20);

    varX = invertX->width() - 25;
    varY = invertX->height() - 25;
    invXind->setGeometry(varX, varY, 20, 20);

    varX = invertY->width() - 25;
    varY = invertY->height() - 25;
    invYind->setGeometry(varX, varY, 20, 20);
}

void AxisOptionsFrame::hideOverlay()
{
}

bool AxisOptionsFrame::event(QEvent *event)
{
    return ZytContentFrame::event(event);
}

void AxisOptionsFrame::createConnections()
{
    /* All connections made here must be broken in reReadValues()
     */

    /* Create connection for the axis flips check boxes
     * so changes are passed to the API
     */

    QObject::connect(invertX,   SIGNAL(clicked()), this, SLOT(controlYXaxis()) );
    QObject::connect(invertY,   SIGNAL(clicked()), this, SLOT(controlYXaxis()) );
    QObject::connect(swapXY,    SIGNAL(clicked()), this, SLOT(swapXYaxes()) );

    QObject::connect(invXind,   SIGNAL(clicked()), this, SLOT(crossCouple()) );
    QObject::connect(invYind,   SIGNAL(clicked()), this, SLOT(crossCouple()) );
    QObject::connect(swapXYind, SIGNAL(clicked()), this, SLOT(crossCouple()) );
}

void AxisOptionsFrame::controlYXaxis(void)
{
    emit APIResult(ZytAPIResult::Progress);

    zul_setConfigParamByID(FX,  invertX->isChecked());
    zul_setConfigParamByID(FY,  invertY->isChecked());

    reReadValues();
    emit APIResult(ZytAPIResult::Success);

}

void AxisOptionsFrame::swapXYaxes(void)
{
    emit APIResult(ZytAPIResult::Progress);

    if (devPID == ZXY100_PRODUCT_ID)
    {
        uint8_t Position = swapXY->isChecked() ? FLEXI_TOP : FLEXI_LEFT;
        zul_setConfigParamByID(SXY, Position);
        emit APIResult(ZytAPIResult::Success);
        reReadValues();
    }
    else
    {
        zul_setConfigParamByID(SXY, swapXY->isChecked());
        emit APIResult(ZytAPIResult::Success);
        reReadValues();
    }
}

void AxisOptionsFrame::crossCouple(void)
{
    if (invertX->isChecked() != invXind->isChecked())
    {
        invertX->setChecked(invXind->isChecked());
        controlYXaxis();
        return;
    }
    if (invertY->isChecked() != invYind->isChecked())
    {
        invertY->setChecked(invYind->isChecked());
        controlYXaxis();
        return;
    }
    if (swapXY->isChecked() != swapXYind->isChecked())
    {
        swapXY->setChecked(swapXYind->isChecked());
        swapXYaxes();
        return;
    }
}

void AxisOptionsFrame::reReadValues()
{
    /* Prevent writing back to controller when changing
     * GUI widget values by disconnecting all slots
     * from this object */

    invertX->disconnect(this);
    invertY->disconnect(this);
    swapXY->disconnect(this);

    readFromController();

    /* re create all the connections */
    createConnections();
}

void AxisOptionsFrame::readFromController()
{
    uint16_t val;

    if (devPID == ZXY100_PRODUCT_ID)
    {
        FX  = ZXY100_CI_FLIP_X;
        FY  = ZXY100_CI_FLIP_Y;
        SXY = ZXY100_CI_FLEXI_POSITION;
    }
    else if (devPID == ZXY110_PRODUCT_ID)
    {
        FX  = ZXY110_CI_INVERT_X;
        FY  = ZXY110_CI_INVERT_Y;
        SXY = ZXY110_CI_SWAP_XY;
    }
    else
    {
        FX  = ZXYMT_CI_INVERT_X;
        FY  = ZXYMT_CI_INVERT_Y;
        SXY = ZXYMT_CI_SWAP_XY;
    }

    if (zul_getConfigParamByID(FX, &val))
    {
            invertX->setChecked(val);
            invXind->setChecked(val);
    }

    if (zul_getConfigParamByID(FY, &val))
    {
            invertY->setChecked(val);
            invYind->setChecked(val);
    }

    if (zul_getConfigParamByID(SXY, &val))
    {
        bool checked = false;

        if (devPID == ZXY100_PRODUCT_ID)
        {
            if ((FLEXI_TOP == val) || (FLEXI_BOTTOM == val))
            {
                checked = true;
            }
        }
        else
        {
            checked = (val > 0);
        }
        swapXY->setChecked(checked);
        swapXYind->setChecked(checked);
    }
}
