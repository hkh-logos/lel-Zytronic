/*
 *      Widget to act as notifcation of result of an API call.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "ZytAPIResult.h"

ZytAPIResult::ZytAPIResult(QWidget *parent) :
    QLabel(parent)
{
    setupPalette();

    createWidgets();

    createConnections();
}

void ZytAPIResult::setupPalette()
{
    QPalette palette = this->palette();
    bgColour = palette.color(QPalette::Window);
    textColour = palette.color(QPalette::WindowText);

    this->setAutoFillBackground(true);
}

void ZytAPIResult::createWidgets()
{
    showTimer = new QTimer(this);
    //set how long to show success/failure for
    showTimer->setInterval(2000);
    showTimer->setSingleShot(true);
}

void ZytAPIResult::createConnections()
{
    QObject::connect(showTimer, SIGNAL(timeout()),
                     this, SLOT(hideResult()));
}

void ZytAPIResult::hideResult()
{
    QPalette tempPal = this->palette();
    tempPal.setColor(QPalette::Background, bgColour);
    this->setPalette(tempPal);
    this->setText("");
    update();
}

void ZytAPIResult::displayResult(QString message, ZytAPIResult::ResultState state)
{
    this->setText(message);
    QPalette tempPal = this->palette();

    switch(state)
    {
        case ZytAPIResult::Success:
            tempPal.setColor(QPalette::Window, Qt::darkGreen);
            tempPal.setColor(QPalette::WindowText, Qt::white);
            showTimer->setInterval(1000);
            showTimer->start();
            break;

        /* Deprecated 2018
        case ZytAPIResult::RootCommand:
            tempPal.setColor(QPalette::Window, Qt::blue);
            tempPal.setColor(QPalette::WindowText, Qt::white);
            showTimer->setInterval(4000);
            showTimer->start();
            break;  */

        case ZytAPIResult::Failure:
            tempPal.setColor(QPalette::Window, Qt::red);
            tempPal.setColor(QPalette::WindowText, Qt::white);
            showTimer->setInterval(5000);
            showTimer->start();
            break;

        case ZytAPIResult::HideResult:
            showTimer->stop();
            hideResult();
            [[gnu::fallthrough]];

        default:
            tempPal.setColor(QPalette::Window, bgColour);
            tempPal.setColor(QPalette::WindowText, textColour);

            showTimer->setInterval(9900);
            showTimer->start();
    }

    this->setPalette(tempPal);
    update();
}

void ZytAPIResult::displayResult(ZytAPIResult::ResultState state)
{
    // fprintf(stderr, "DISPresult %d\n", state);
    switch(state)
    {
        case ZytAPIResult::Success:
            displayResult(tr("Updated Controller"), state);
            break;
        case ZytAPIResult::Failure:
            displayResult(tr("FAILED to Update Controller"), state);
            break;
        default:
            displayResult(tr("Controller update in progress ..."), state);
    }
}
