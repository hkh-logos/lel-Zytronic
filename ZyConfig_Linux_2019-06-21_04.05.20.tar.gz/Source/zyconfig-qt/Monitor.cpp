// Monitor class implementation
//  Holds monitor name, size and location on desktop (aka screen)
//  Provides access to these values through C and Qt datatypes
//

#include <Monitor.h>
#include <string.h>
#include <stdio.h>
#include <QString>

Monitor::Monitor( const char *mName, Location mLocation, Size2d mSize, XMonitorOrientation mOrientation )
{
    strncpy( monName, mName, 12 );
    monName[11] = '\0';
    location = mLocation;
    size = mSize;
    orientation = mOrientation;
    primary = false;
    valid = true;
}

Monitor::Monitor( void )
{
    strcpy( monName, "NULL" );
    location.x = 0,  location.y = 0;
    size.x = 0,  size.y = 0;
    primary = false;
    valid = false;
}

void Monitor::setPrimary(void)
{
    primary = true;
}

const char * Monitor::getName(bool decorate)
{
    if (!decorate) return monName;
    if (!primary) return monName;

    strcpy ( decName, monName );
    strcat ( decName, "*" );
    return decName;
}

const char * Monitor::getParams(void)
{
    snprintf ( paramStr, 24, "%dx%d+%d+%d", size.x, size.y, location.x, location.y);
    paramStr[24] = '\0';
    return paramStr;
}


Location Monitor::getLocation(void)
{
    return location;
}

Size2d Monitor::getSize(void)
{
    return size;
}

XMonitorOrientation Monitor::getOrientation(void)
{
    return orientation;
}

void Monitor::getRect(QRect *r)
{
    r->setRect(location.x, location.y, size.x, size.y);
}

void Monitor::setRect(QRect *r, QString name)
{
    strncpy ( monName, name.toLatin1().constData(), 12 );
    monName[11] = '\0';
    location.x = r->left();
    location.y = r->top();
    size.x = r->width();
    size.y = r->height();
}

bool Monitor::isValid(void)
{
    return valid;
}
