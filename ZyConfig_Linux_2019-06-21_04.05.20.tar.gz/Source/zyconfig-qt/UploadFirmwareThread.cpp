/*
 *      Thread to handle uploading firmware to the controller. This expects
 *      to be passed a QTimer which will be set to update the UI with progress.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <services.h>
#include <debug.h>

#include "UploadFirmwareThread.h"
// #include <usb.h>

#define ZYFDEBUG    (4)  // ### set to 4 to silence, set to 1 for logging

UploadFirmwareThread::UploadFirmwareThread(QObject *parent) :
    QThread(parent)
{
    state = Done;
}

bool UploadFirmwareThread::checkForBootloader()
{
    int16_t pid;
    if (zul_getDevicePID(&pid))
    {
        return zul_isBLDevicePID(pid);
    }
    return false;
}

bool UploadFirmwareThread::checkForNormalConnection()
{
    return !checkForBootloader();
}

void UploadFirmwareThread::setFName(const QString name)
{
    fName = name;
}

UploadFirmwareThread::UploadState UploadFirmwareThread::getState()
{
    return state;
}

void UploadFirmwareThread::resetState()
{
    state = SwitchingToBootloader;
}

#define TEMP_BUF_LEN            (1000)

void UploadFirmwareThread::run()
{
    int     findDevLoopCount = 12;
    int     controllerDevIndex, numDevs;
    char    tempBuffer[TEMP_BUF_LEN + 1];

    emit pauseConnectionCheck(true);

    zul_log (ZYFDEBUG, "start automated FW update");

    state = UploadFirmwareThread::CheckingFile;

    // cf BootloaderFirmwareInitDownload
    if(SUCCESS != zul_loadAndValidateZyf(fName.toLatin1().data()))
    {
        //FAILED!
        state = UploadFirmwareThread::BAD_CRC;
        emit pauseConnectionCheck(false);
        fprintf(stderr, "File error: %s\n", zul_getZyfXferResultStr() );
        return;
    }

    zul_log (ZYFDEBUG,"File OK");

    state = UploadFirmwareThread::SwitchingToBootloader;

    // if the device is not in bootloader mode, send the toggle command and disconnect.
    // then poll the device list until the bootloader device appears ...
    if (!checkForBootloader())
    {
        zul_StartBootLoader();
        zul_closeDevice();
        // allow the device time to reboot and re-connect to the OS
        zy_msleep(BL_RESET_DELAY_MS);

        int     numDevs = zul_getDeviceList(tempBuffer, 1000);
        int     targetDevicePID;

        targetDevicePID = zul_getBLPIDByDevS( fName.toLatin1().data() );

        // --- FIND THE BOOTLOADER DEVICE'S NEW INDEX ---

        controllerDevIndex = -1;
        while (findDevLoopCount-- > 0)
        {
            numDevs = zul_getDeviceList(tempBuffer, TEMP_BUF_LEN);
            if (numDevs > 0)
            {
                controllerDevIndex = zul_selectPIDFromList(targetDevicePID, tempBuffer);
                if (controllerDevIndex >= 0) break;
            }
            zul_logf(ZYFDEBUG, "Waiting for BL device %04X %02d\n", targetDevicePID,
                                    findDevLoopCount); // zul_spinner());
            zy_msleep(BL_RESET_DELAY_MS/4);
        }


        zul_log (ZYFDEBUG, "\nswitch done ## open bootloader");


        // --- OPEN THE BOOTLOADER DEVICE ---

        if (controllerDevIndex >= 0)
        {
            zul_logf(ZYFDEBUG, "Open device index %d ... \n", controllerDevIndex );
            int retVal = zul_openDevice(controllerDevIndex);
            if (retVal != 0)
            {
                zul_logf(ZYFDEBUG, "Error [%d] opening device index %d.\n", retVal, controllerDevIndex );
                state = UploadFirmwareThread::FAILED;
                emit pauseConnectionCheck(false);
                return;
            }
        }
        else
        {
            zul_log (ZYFDEBUG, "Unable to select which device to update.\n");
            state = UploadFirmwareThread::FAILED;
            emit pauseConnectionCheck(false);
            return;
        }
    }

    // prepare transfer comms and device for FW packets
    zul_setCommsEndurance(COM_ENDUR_HIGH);
    zul_log (ZYFDEBUG, "Sending the ProgData header message ... \n");
    if (FAILURE == zul_testProgDataBlock())
    {
        fprintf(stderr, "\nDevice rejected this ZYF file.\n");
        fprintf(stderr, "Disconnect and reconnect the device, try again.\n");
        emit pauseConnectionCheck(false);
        zul_BL_RebootToApp();
        return;
    }

    state = UploadFirmwareThread::Uploading;
    zul_log (ZYFDEBUG, "Start Transfer.\n" );

    // this call to zul_transferFirmware only returns when done
    if(SUCCESS != zul_transferFirmware(false)) // false => no console tracking
    {
        //FAILED!
        state = UploadFirmwareThread::FAILED;
        emit pauseConnectionCheck(false);
        return;
    }

    state = UploadFirmwareThread::SwitchingToApplication;

    zul_BL_RebootToApp();
    zul_closeDevice();
    // allow the device time to reboot and re-connect to the OS
    zy_msleep(BL_RESET_DELAY_MS);

    // --- OPEN the Application device ---

    int newDevicePID = zul_getAppPIDByDevS( fName.toLatin1().data() );

    findDevLoopCount = 12;
    controllerDevIndex = -1;
    while (findDevLoopCount-- > 0)
    {
        numDevs = zul_getDeviceList(tempBuffer, TEMP_BUF_LEN);
        if (numDevs > 0)
        {
            controllerDevIndex = zul_selectPIDFromList(newDevicePID, tempBuffer);
            if (controllerDevIndex >= 0) break;
        }

        zul_logf(ZYFDEBUG, "Waiting for APP device %04X %02d %c\n",
                        newDevicePID, findDevLoopCount); // , zul_spinner());

        zy_msleep(BL_RESET_DELAY_MS/4);
    }

    if (controllerDevIndex >= 0)
    {
        zul_logf(ZYFDEBUG, "Open device index %d ... \n", controllerDevIndex );
        int retVal = zul_openDevice(controllerDevIndex);
        if (retVal != 0)
        {
            zul_logf(ZYFDEBUG, "Error [%d] opening device index %d.\n", retVal, controllerDevIndex );
            state = UploadFirmwareThread::FAILED;
            emit pauseConnectionCheck(false);
            return;
        }
        else
        {
            int16_t pid;
            zul_getDevicePID(&pid);
            state = UploadFirmwareThread::Done;
            zul_logf(ZYFDEBUG, "Device %s opened, PID %04x\n",
                                    zul_getDevStrByPID(pid),
                                    pid);
        }
    }
    else
    {
        zul_log (ZYFDEBUG, "Unable to select which device to update.\n");
        state = UploadFirmwareThread::FAILED;
        emit pauseConnectionCheck(false);
        return;
    }

    emit pauseConnectionCheck(false);

    zy_msleep(300);

    emit reReadRequired();
    zul_log (ZYFDEBUG, "ALL DONE ZYF\n");
    state = UploadFirmwareThread::Done;
}
