/*
 *      Widget to contain title for pages within tabs. Keeps conformity amongst
 *      all tabs.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef SENSEANDTHRESHFRAME_H
#define SENSEANDTHRESHFRAME_H

#include <QtWidgets>
#include "Zxy100Data.h"
#include "BigLabeledSlider.h"
// #include "TouchDetectFrame.h"
#include "ZytContentFrame.h"

class SenseAndThreshFrame : public ZytContentFrame
{
    Q_OBJECT

public:
    SenseAndThreshFrame     (QWidget *parent = 0);
    void        reReadValues            ();
    void        showOverlay             ();
    void        hideOverlay             ();
    void        passZxy100Data          (Zxy100Data * z100d);
    QMessageBox *MakeHelpBox            (int NumWires, int16_t pid);
    QString     getText                 (int16_t pid);

signals:
    void thresholdsChanged();

protected:
    virtual void showEvent(QShowEvent *Event);
    virtual void hideEvent(QHideEvent *Event);

private slots:
    void senseValueChange(void);
    void actValueChange(int value);
    void deactValueChange(int value);
    void pollForTouch();
    void changeThresholds();
    void changeSense();
    void showHelp();

private:
    void        createWidgets();
    void        readFromController();
    void        createConnections();
    QLayout *   createLayout();
    QString     getIntroText(int NumWires);

    QLabel              *senseLabel;
    QLabel              *threshLabel;

    BigLabeledSlider    *senseSlider;
    BigLabeledSlider    *actSlider;
    BigLabeledSlider    *deactSlider;

    QPushButton         *guide;

    QTimer              *pollingTimer;
    QTimer              *writeThreshChange;
    QTimer              *writeSenseChange;

    QLabel              *senInc;
    QLabel              *senDec;
    QLabel              *actInc;
    QLabel              *actDec;
    QLabel              *deactInc;
    QLabel              *deactDec;

    Zxy100Data          *zxy100Dat;
    int16_t             devPID;
    uint8_t             CS, LT, UT;

    static const QString ZXY100_32_suggestions;
    static const QString ZXY100_64_suggestions;
    static const QString ZXY100_128_suggestion;

    static const QString Zxy110_32_suggestions;
    static const QString Zxy110_64_suggestions;
    static const QString Zxy110_128_suggestion;

};

#endif // SENSEANDTHRESHFRAME_H
