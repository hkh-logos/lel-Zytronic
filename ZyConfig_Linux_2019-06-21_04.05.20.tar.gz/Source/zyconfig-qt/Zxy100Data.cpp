/*
 *
 *  Data store for ZXY100 data and state
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "Zxy100Data.h"
#include <stdio.h>
#include <string.h>

#include "zytypes.h"
//#include "comms.h"
#include "zxymt.h"
#include "zxy100.h"
#include "zxy110.h"
#include "debug.h"
#include "services.h"
#include "services_sc.h"

#include <math.h>

#define DEBUG_RAW_FRAME     (false)

Zxy100Data::Zxy100Data()
{
    // on creation, connection to device may not be available
    uint16_t numWiresX = 0, numWiresY = 0;

    rawData.sensorSz.xWires  = numWiresX;
    rawData.sensorSz.yWires  = numWiresY;

    strcpy(fwStr, "tbd");
    strcpy(ProcID, "tbd");

    xAvgTally = yAvgTally = 0.0;

    //disable the LED polling
    enableLEDs(false);

    // init the system (reset) reports
    firstReport.job         = getFirst;
    firstReport.TS_secs     = 0;
    lastReport.job          = getNormal;
    lastReport.TS_secs      = 0;
    baselineReport.job      = getBaseline;
    baselineReport.TS_secs  = 0;
    deltaReport.job         = getDelta;
    deltaReport.TS_secs     = 0;

    noiseMemory.TS_secs     = 0;

    rawDataCaptureEnabled   = false;
}

void Zxy100Data::refreshInfo()
{
    uint16_t numWiresX, numWiresY;
    int16_t  PID;
    zul_getDevicePID(&PID);

    switch (PID)
    {
        case ZXY100_PRODUCT_ID:
            DeBounce = ZXY100_THRESHOLD_DEBOUNCE;   // used in Z2SetupSensDialog.cpp
            break;
        case ZXY110_PRODUCT_ID:
            DeBounce = ZXY110_THRESHOLD_DEBOUNCE;
            break;
        default:
            return;
    }

    zul_getOldZxy100WireCnt(&numWiresX, &numWiresY);

    xAvgTally = yAvgTally = 0.0;
    rawData.sensorSz.xWires  = numWiresX;
    rawData.sensorSz.yWires  = numWiresY;

    zul_Firmware(fwStr, FieldLen);
    zul_CpuID(ProcID, 25);
    zul_logf(5, "Zxy100Data Wires:%d,%d Proc:%s FW:%s\n", numWiresX, numWiresX, ProcID, fwStr);
}

char *Zxy100Data::getProcID()
{
    return ProcID;
}

void Zxy100Data::getNewRawData(void)
{
    minOfMaxs = 0;
}

/**
 * remove any existing data, zero the accumulators, and
 * update the UPPER_THRESHOLD var
 */
void Zxy100Data::prepRawDataCollection(int UTCI)
{
    zul_logf(3, "%s", __FUNCTION__ );
    zul_getConfigParamByID(UTCI, &upperThreshold);  // ZXY100|ZXY110  CI_UPPER_THRESHOLD

    // empty the raw data store
    sampleList.clear();
    xAvgTally = yAvgTally = 0.0;
    rawData.allValid = false;   // skip current sample

    // reset the noise or 'near-touch' counters
    numFramesOvr70 = numFramesOvr50 = numFramesOvr30 = 0;
}

// ...
int Zxy100Data::getNumFrames(void)
{
    return sampleList.size();
}

void Zxy100Data::enableRawDataCapture(bool enable)
{
    int i,j;
    int numWiresX = rawData.sensorSz.xWires;
    int numWiresY = rawData.sensorSz.yWires;

    // validate sensible wirecounts
    if ((numWiresX > ZXY100_MAX_WIRES/2) || (numWiresY > ZXY100_MAX_WIRES/2))
    {
        throw ("Bad wire counts");
    }
    for (i=0, j=numWiresX;  i < numWiresX;  i++, j++)
    {
        rawData.wireSig[i] = 0; // X values reset
        rawData.wireSig[j] = 0; // Y values reset
    }

    rawDataCaptureEnabled = enable;     // local memory of setting (used ? TBD)

    // assist raw data transfer by disabling LED polling
    enableLEDs(! enable);

    if (enable)
    {
        zul_SetRawDataBuffer(&rawData);     // interrupt transfer storage location
    }

    // put the device in the correct mode
    zul_SetRawMode(enable);
}

/* Get another set of raw data samples (wire signal levels) and store the array in the list.
 * Search for max/mins.  numFramesOvr70 (etc) values are updated */
void Zxy100Data::collectNewRawData(void)
{
    RawSampleStats rawSample;                  // temporary struct

    rawSample.maxX = rawSample.maxY = rawSample.maxXY = 0;

    bool newData = scanRawSample(&rawSample);
    if (newData)
    {
        zul_logf(4, "   ==> Frame new data taken\n");
        // add to sample list
        sampleList.push_back(rawSample);    // append, temp struct is copied

        if (DEBUG_RAW_FRAME)
        {
            logFrameToConsole();
        }

        zul_logf(3, "Frames %zu [%d|%d|%d] Mxy:%d UT:%d",
                getNumFrames(),
                numFramesOvr70,  numFramesOvr50, numFramesOvr30,
                rawSample.maxXY, upperThreshold   );
    }
    else
    {
        // are we polling for the data too fast?
        zul_logf(3, "   ==> Frame read/parse miss\n");
    }
}

// dump the current rawData wirevalues to console in decimal
void Zxy100Data::logFrameToConsole(void)
{
    int i;
    uint16_t numWiresX = rawData.sensorSz.xWires;
    uint16_t numWiresY = rawData.sensorSz.yWires;

    printf("X: ");
    for (i=0; i < numWiresX; i++)
    {
        uint8_t wireLevel = rawData.wireSig[i];
        printf("%03d ", wireLevel);
    }
    printf("\nY: ");
    for ( ;  i < numWiresX + numWiresY;  i++)
    {
        uint8_t wireLevel = rawData.wireSig[i];
        printf("%03d ", wireLevel);
    }
    printf("\n");
}

// return true if new data has been acquired and processed
bool Zxy100Data::scanRawSample(RawSampleStats *rawSample)
{
    int         i,j;
    uint8_t     max, xmax, ymax;
    int         xWireTally = 0, yWireTally = 0;

    if (rawData.allValid)
    {
        uint16_t numWiresX = rawData.sensorSz.xWires;
        uint16_t numWiresY = rawData.sensorSz.yWires;

        memcpy ( &(rawSample->rawData), &rawData, sizeof(rawData) );

        // don't take again until there's a new frame
        rawData.allValid = false;

        // locate and store the X max and Y max
        xmax = 0;
        for (i=0; i < numWiresX; i++)
        {
            uint8_t wireLevel = rawData.wireSig[i];
            xWireTally += wireLevel;
            if (xmax < wireLevel) xmax = wireLevel;
        }
        rawSample->maxX = xmax;
        ymax = 0;
        for (i=0, j=numWiresX;  i < numWiresY;  i++, j++)
        {
            uint8_t wireLevel = rawData.wireSig[j];
            yWireTally += wireLevel;
            if (ymax < wireLevel) ymax = wireLevel;
        }
        rawSample->maxY = ymax;

        // select the minimum from the max of X and Y - see C# RawDataStore100
        //                  if (ut50pcX && ut50pcY) numFramesGT50pcUpperThresh++;

        max = ymax;
        if (max > xmax) max = xmax;
        rawSample->maxXY = max;

        rawSample->maxOvr70 = (max > 70 * upperThreshold / 100);
        rawSample->maxOvr50 = (max > 50 * upperThreshold / 100);
        rawSample->maxOvr30 = (max > 30 * upperThreshold / 100);

        if (rawSample->maxOvr70) numFramesOvr70++;
        if (rawSample->maxOvr50)
        {
            numFramesOvr50++;
        }
        if (rawSample->maxOvr30) numFramesOvr30++;

        xAvgTally += (float)xWireTally / numWiresX;
        yAvgTally += (float)yWireTally / numWiresY;

        return true;
    }

    return false;
}

/**
 * Find the value and location of the maximum in the X and Y wire values
 * return the smaller of the maximums
 * Remember the X and Y location of this point in wire index units (xOfMax, yOfMax)
 */
int Zxy100Data::getRawDataMinOfMaxs(void)
{
    int         i, j, maxX=0, maxY=0;
    uint16_t    numWiresX = rawData.sensorSz.xWires;
    uint16_t    numWiresY = rawData.sensorSz.yWires;

    if (minOfMaxs>0) return minOfMaxs;

    xOfMax = yOfMax = 0;

    for (i=0; i<numWiresX; i++)
    {
        uint8_t wireLevel = rawData.wireSig[i];
        if (maxX < wireLevel)
        {
            maxX = wireLevel;
            xOfMax = i;
        }
    }
    for (i=0, j=numWiresX;  i < numWiresY;  i++, j++)
    {
        uint8_t wireLevel = rawData.wireSig[j];
        if (maxY < wireLevel)
        {
            maxY = wireLevel;
            yOfMax = i;
        }
    }

    minOfMaxs = (maxX < maxY) ? maxX : maxY;
    return minOfMaxs;
}


int Zxy100Data::getXIndexforRawMax(void)
{
    // assure that a search has been run
    if (minOfMaxs==0) getRawDataMinOfMaxs();
    return xOfMax;
}
int Zxy100Data::getYIndexforRawMax(void)
{
    // assure that a search has been run
    if (minOfMaxs==0) getRawDataMinOfMaxs();
    return yOfMax;
}

// ...
float Zxy100Data::getXMeanWireAverage(void)
{
    return xAvgTally / getNumFrames();
}

// ...
float Zxy100Data::getYMeanWireAverage(void)
{
    return yAvgTally / getNumFrames();
}

bool Zxy100Data::calcStdDevs(void)
{
    float xTotalAve = getXMeanWireAverage();
    float yTotalAve = getYMeanWireAverage();

    uint16_t    numWiresX = rawData.sensorSz.xWires;
    uint16_t    numWiresY = rawData.sensorSz.yWires;

    // init the values, as a mark
    xStdDev = yStdDev = 0;

    if (upperThreshold == 0) return false;  // UThreshold must be non-zero for some tests
    if (sampleList.empty()) return false;

    float xSumDiffSqrd = 0.0, ySumDiffSqrd = 0.0;

    // interate through the set of sample frames with 'sf' pointer
    for (std::list<RawSampleStats>::iterator sf=sampleList.begin(); sf != sampleList.end(); ++sf)
    {
        int wireIndex,j;
        for (int wireIndex = 0; wireIndex < numWiresX; wireIndex++)
        {
            float wireLevel = sf->rawData.wireSig[wireIndex];
            float diff = wireLevel - xTotalAve;
            xSumDiffSqrd += diff * diff;
        }
        for (wireIndex=0, j=numWiresX;  wireIndex < numWiresY;  wireIndex++, j++)
        {
            float wireLevel = sf->rawData.wireSig[j];
            float diff = wireLevel - yTotalAve;
            ySumDiffSqrd += diff * diff;
        }
    }

    xStdDev = (float)sqrt(xSumDiffSqrd / (getNumFrames() * numWiresX));
    yStdDev = (float)sqrt(ySumDiffSqrd / (getNumFrames() * numWiresY));

    return true;
}

// ...
float Zxy100Data::getXStdDev(void)
{
    return xStdDev;
}

// ...
float Zxy100Data::getYStdDev(void)
{
    return yStdDev;
}

// ...
Zxy100Data::SysReport *Zxy100Data::getReportByJob(JobType job)
{
    Zxy100Data::SysReport *rpt;

    switch (job)
    {
        case getFirst:
            rpt = &firstReport;
            break;
        case getNormal:
            rpt = &lastReport;
            break;
        case getBaseline:
            rpt = &baselineReport;
            break;
        case getDelta:
            rpt = &deltaReport;
            break;
        default:
            // BAD JobType request!
            rpt = NULL;
    }
    return rpt;
}

void Zxy100Data::getNewNoiseReport(JobType job)
{
    Zxy100Data::SysReport  *rpt = getReportByJob(job);
    int                     i;

    if (rpt == NULL)    return;

    if ( SUCCESS == zul_getOldSysReport(&rpt->sysReport))
    {
        struct timeb timebuffer;
        ftime( &timebuffer );

        rpt->TS_secs = timebuffer.time;
        rpt->TS_msec = timebuffer.millitm;
    }
    else
    {
        zul_logf( 1, "%s FAILED", __FUNCTION__);
        rpt->TS_secs = 0;   // invalid hint
    }

    switch (job)
    {
        case getFirst:  // update normal and baseline data also
            baselineReport = firstReport;       // copy struct

            [[gnu::fallthrough]];

        case getBaseline:  // update normal also
            lastReport = firstReport;           // copy struct
            break;

        // remove a warning :
        case getNormal:
            // do nothing
            break;

        case getDelta:
            // remove the baseline values
            for (i=0; i<ZXY100_SYSRPT_NOISE_ALGOS; i++)
            {
                rpt->sysReport.noiseMetrics[i] -= baselineReport.sysReport.noiseMetrics[i];
            }
            rpt->sysReport.numEqualizations-= baselineReport.sysReport.numEqualizations;
            rpt->sysReport.numNoiseRecoveryEvents -= baselineReport.sysReport.numNoiseRecoveryEvents;
            break;
    }
}

#include <QDate>
int Zxy100Data::getNoiseReportStr(JobType j, char *return_buffer, int buf_len)
{
    QDate today = QDate::currentDate ();
    QTime now   = QTime::currentTime ();
    char tm_buffer[50+1];

    if (buf_len < 30)
    {
        // buf_len too short
        return FAILURE;
    }

    Zxy100Data::SysReport *rpt = getReportByJob(j);

    if (rpt == NULL)
    {
        return FAILURE;
    }

    snprintf (tm_buffer, 50, "%04d/%02d/%02d %02d:%02d:%02d",
              today.year(), today.month(), today.day(),
              now.hour(), now.minute(), now.second() );


    snprintf(return_buffer, buf_len,
        //"HW:%02x "
        "%s FPS: %d "
        "#NRE: %d #EqE: %d "
        "#NAE[ %d %d %d %d  %d %d %d %d ]"
        ,
            // rpt->sysReport.hwConfig,
            tm_buffer,                          // time that the count was recorded
            rpt->sysReport.framesPerSecond,

            rpt->sysReport.numNoiseRecoveryEvents,
            rpt->sysReport.numEqualizations,

            rpt->sysReport.noiseMetrics[0],
            rpt->sysReport.noiseMetrics[1],
            rpt->sysReport.noiseMetrics[2],
            rpt->sysReport.noiseMetrics[3],

            rpt->sysReport.noiseMetrics[4],
            rpt->sysReport.noiseMetrics[5],
            rpt->sysReport.noiseMetrics[6],
            rpt->sysReport.noiseMetrics[7]
    );

    return_buffer[buf_len-1] = '\0';    // force good behaviour - may clip

    return SUCCESS;
}

int Zxy100Data::getNoiseReportValue(JobType j, int v, int *ret_val)
{
    if (v >= ZXY100_SYSRPT_NOISE_ALGOS)    return FAILURE;

    Zxy100Data::SysReport *rpt = getReportByJob(j);

    if (rpt == NULL)    return FAILURE;

    *ret_val = rpt->sysReport.noiseMetrics[v];
    return SUCCESS;
}

int Zxy100Data::getNumNoiseRecoveryEvents(JobType j, int *ret_val)
{
    Zxy100Data::SysReport *rpt = getReportByJob(j);

    if (rpt == NULL)    return FAILURE;

    *ret_val = rpt->sysReport.numNoiseRecoveryEvents;
    return SUCCESS;
}

int Zxy100Data::getNumEqualizations(JobType j, int *ret_val)
{
    Zxy100Data::SysReport *rpt = getReportByJob(j);

    if (rpt == NULL)    return FAILURE;

    *ret_val = rpt->sysReport.numEqualizations;
    return SUCCESS;
}

/* Search for a noise detector increment
 *  If any have occured since last test return true,
 *  If the counts are unchanged since last test return false
 */
bool Zxy100Data::noiseDetected(void)
{
    static unsigned int     holdCount = 0;
    unsigned int            i;
    Zxy100SysReport        *lastNoise, *noiseMem;

    // ensure noiseMemory initialised before use
    if (noiseMemory.TS_secs == 0)
    {
        noiseMemory = lastReport;               // copy struct
        return false;
    }

    noiseMem = &noiseMemory.sysReport;
    lastNoise = &lastReport.sysReport;

    if (holdCount)
    {
        holdCount--;
        if (holdCount==1)
        {
            // just before we check again for a new event, zero the differences
            memcpy (noiseMem,  lastNoise,
                    ZXY100_SYSRPT_NOISE_ALGOS * sizeof(uint16_t));
        }
        return holdCount>0;
    }

    for (i=0; i<ZXY100_SYSRPT_NOISE_ALGOS; i++)
    {
        if (lastNoise->noiseMetrics[i] >
            noiseMem->noiseMetrics[i])
        {
            // zero the differences
            memcpy (noiseMem,  lastNoise,
                    ZXY100_SYSRPT_NOISE_ALGOS * sizeof(uint16_t));
            holdCount = NoiseHoldCount;
            return true;
        }
    }

    return false;                               // no noise detected
}

bool Zxy100Data::equalisationDetected(void)
{
    static unsigned int     holdCount = 0;
    Zxy100SysReport        *lastNoise, *noiseMem;

    // ensure noiseMemory initialised before use
    if (noiseMemory.TS_secs == 0)
    {
        noiseDetected();
        return false;
    }

    noiseMem = &noiseMemory.sysReport;
    lastNoise = &lastReport.sysReport;

    //fprintf(stderr, "### %03d - %03d\n", lastNoise->numEqualizations, noiseMemory.sysReport.numEqualizations);

    if (holdCount)
    {
        holdCount--;
        if (holdCount==1)
        {
            // just before we check again for a new event, zero the difference
            noiseMem->numEqualizations = lastNoise->numEqualizations;
        }
        return holdCount>0;
    }

    if ( lastNoise->numEqualizations       > noiseMem->numEqualizations )
    {
        // zero the difference
        noiseMem->numEqualizations = lastNoise->numEqualizations;
        holdCount = NoiseHoldCount;
        return true;
    }

    return false;                               // no noise detected
}

bool Zxy100Data::noiseRecoveryDetected(void)
{
    static unsigned int     holdCount = 0;
    Zxy100SysReport        *lastNoise, *noiseMem;

    // ensure noiseMemory initialised before use
    if (noiseMemory.TS_secs == 0)
    {
        noiseDetected();
        return false;
    }

    noiseMem = &noiseMemory.sysReport;
    lastNoise = &lastReport.sysReport;

    //fprintf(stderr, "### %03d - %03d\n", lastNoise->numNoiseRecoveryEvents, noiseMem->numNoiseRecoveryEvents);

    if (holdCount)
    {
        holdCount--;
        if (holdCount==1)
        {
            // just before we check again for a new event, zero the difference
            noiseMem->numNoiseRecoveryEvents = lastNoise->numNoiseRecoveryEvents;
        }
        return holdCount>0;
    }

    if ( lastNoise->numNoiseRecoveryEvents > noiseMem->numNoiseRecoveryEvents )
    {
        // zero the difference
        noiseMem->numNoiseRecoveryEvents = lastNoise->numNoiseRecoveryEvents;
        holdCount = NoiseHoldCount;
        return true;
    }

    return false;                               // no noise detected
}

/* Hold off the apps LED polling when running Raw Data view,
           Basic Setup, Integration Tests (when available) & FLASH transfer */
bool Zxy100Data::activeLEDs(void)
{
    return ledPollingIsActive;
}

void Zxy100Data::enableLEDs(bool active)
{
    //fprintf(stderr, "LEDs %sabled\n", active ? "en" : "dis");
    ledPollingIsActive = active;
}
