/*
 *      Widget to contain title for pages within tabs. Keeps conformity amongst
 *      all tabs.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef Z2SF_H
#define Z2SF_H

#include <QtWidgets>
#include "BigLabeledSlider.h"
#include "ZytContentFrame.h"

class Z2SenseFrame : public ZytContentFrame
{
    Q_OBJECT

public:
    Z2SenseFrame(QWidget *parent = 0);
    void showOverlay();
    void hideOverlay();
    QString getText(int16_t pid);

signals:
    void thresholdsChanged();

public slots:
    void reReadValues();


protected:
    virtual void showEvent(QShowEvent *Event);
    virtual void hideEvent(QHideEvent *Event);

private slots:
    void actValueChange(int value);
    void pollForTouch();
    void changeThresholds();
    QString getIntroText(int16_t pid, int NumWires);
    void showHelp();

private:
    void createWidgets();
    void readFromController();
    void createConnections();

    QLayout             *createLayout();

    BigLabeledSlider    *actSlider;

    QTimer              *writeThreshChange;
    QTimer              *feedbackTimer;

    QLabel              *threshTxtLabel;
    QLabel              *actInc;
    QLabel              *actDec;
    QLabel              *statusLabel;
    QLabel              *touchCountLabel;

    QPushButton         *guide;

    int16_t             devPID;

    static const QString Zxy150_Suggestion;
    static const QString Zxy200_Suggestion;
    static const QString Zxy300_Suggestion;

    static const QString Zxy500_64_Suggestion;
    static const QString Zxy500_128_Suggestion;
    static const QString Zxy500_256_Suggestion;

};

#endif // Z2SF_H

