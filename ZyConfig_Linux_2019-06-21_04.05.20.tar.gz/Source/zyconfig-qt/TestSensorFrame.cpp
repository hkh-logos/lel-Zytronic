/*
 *      Content of the flexi tail position tab in the configuration tab
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


/*
  TestSensorFrame

    This class provides access to the Raw Data panel.  Users are warned &
    informed on usage, having the opportunity to back out before a keyboard
    or mouse is needed
*/
#include "Z1_RawImageWindow.h"
#include "TestSensorFrame.h"

#include "zytypes.h"
//#include "comms.h"
#include "zxymt.h"
#include "zxy100.h"
#include "zxy110.h"
#include "services.h"

#define NUM_X_WIRES          (80)
#define NUM_Y_WIRES          (48)


QTime TestSensorFrame::buttonPressHoldoff;

TestSensorFrame::TestSensorFrame(QWidget *parent) :
        ZytContentFrame(parent)
{
    int16_t PID;
    zul_getDevicePID(&PID);
    devPID = PID;

    createWidgets();

    createConnections();

    setLayout(createLayout());
    inhibitLEDPolling = NULL;
}


void TestSensorFrame::createWidgets()
{
    //const int padding = 20;

    rawViewButton = new QPushButton(tr("Test &Sensor"),this);
    rawViewButton->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    intro = new QLabel(tr("The Test Sensor page provides a detailed view of the measurements "
                            "collected by the touchscreen controller."));
    intro->setWordWrap(true);
    //intro->setMargin(padding);
    intro->setMinimumWidth(STD_LABEL_WIDTH*3/2);

    warning = new QLabel(tr("WARNING:"));
    warning->setStyleSheet("QLabel { background-color : white; color : red; }");
    warning->setAlignment(Qt::AlignTop);


    warningDetail = new QLabel( tr("When you start the Test Sensor page, you will lose all touch functionality. ") +
                                tr("You will need a mouse or keyboard attached to this PC to close the ") +
                                tr("Test Sensor Page and return to normal operation.") );
    warningDetail->setWordWrap(true);
    warningDetail->setMinimumWidth(STD_LABEL_WIDTH*3/2);
    warningDetail->setAlignment(Qt::AlignTop);

    buttonPressHoldoff = QTime::currentTime();
}


QLayout * TestSensorFrame::createLayout()
{
    QVBoxLayout *mainLayout = new QVBoxLayout;

    QHBoxLayout *introLayout = new QHBoxLayout;
    QHBoxLayout *warningLayout = new QHBoxLayout;
    QHBoxLayout *rawViewButtonLayout = new QHBoxLayout;

    introLayout->addStretch();
    introLayout->addWidget(intro);
    introLayout->addStretch();

    warningLayout->addStretch();
    warningLayout->addWidget(warning);
    warningLayout->addWidget(warningDetail);
    warningLayout->addStretch();

    rawViewButtonLayout->addStretch();
    rawViewButtonLayout->addWidget(rawViewButton);
    rawViewButtonLayout->addStretch();

    mainLayout->addStretch();
    mainLayout->addLayout(introLayout);
    mainLayout->addStretch();
    mainLayout->addLayout(warningLayout);
    mainLayout->addStretch();
    mainLayout->addLayout(rawViewButtonLayout);
    mainLayout->addStretch();

    return mainLayout;
}


void TestSensorFrame::showOverlay()
{
}

void TestSensorFrame::hideOverlay()
{
}

bool TestSensorFrame::event(QEvent *event)
{
    return ZytContentFrame::event(event);
}

void TestSensorFrame::createConnections()
{
    /* All connections made here must be broken in reReadValues()
     */

    /* Create connection for the axis flips check boxes
     * so changes are passed to the API*/

    QObject::connect(rawViewButton, SIGNAL(clicked()), this, SLOT(startRawDataDisplay()) );
}


void TestSensorFrame::reReadValues()
{
    /* Prevent writing back to controller when changing
     * GUI widget values by disconnecting all slots
     * from this object */

    rawViewButton->disconnect(this);

    readFromController();

    /* re create all the connections */
    createConnections();
}

void TestSensorFrame::readFromController()
{
}

void TestSensorFrame::startRawDataDisplay(void)
{
    if (buttonPressHoldoff.addMSecs(400) < QTime::currentTime()) // stop double clicks
    {
        ZXY_sensorSize  sz;

        if (inhibitLEDPolling != NULL)
        {
            *inhibitLEDPolling = true;
        }

        buttonPressHoldoff = QTime::currentTime();
        rawViewButton->setEnabled(false);

        zul_setRawDataHandler();
        zul_getSensorSize(&sz);

        switch (devPID)
        {
            case ZXY100_PRODUCT_ID:
            case ZXY110_PRODUCT_ID:
                z1_RawWindow.setAdvancedMode( Z2RawImageWindow::FlagGridOn );
                z1_RawWindow.setDimensions(devPID, sz.xWires, sz.yWires);
                z1_RawWindow.exec();
                break;

            case ZXY150_PRODUCT_ID:
            case ZXY200_PRODUCT_ID:
            case ZXY300_PRODUCT_ID:
                // Multitouch (ZXY150, ZXY200, ZXY300, ZXY500
                z2RawWindow.setDimensions( sz.xWires, sz.yWires );

                // copy advanced output setting thru' from ZytContentFrame
                z2RawWindow.setAdvancedMode( Z2RawImageWindow::FlagGridOn );

                zul_useKernelIFace(true);
                z2RawWindow.exec();
                zul_useKernelIFace(false);
                break;

            case ZXY500_PRODUCT_ID:
            case ZXY500_PRODUCT_ID_ALT1:
                // Multitouch (ZXY150, ZXY200, ZXY300, ZXY500
                z2RawWindow.setDimensions( sz.xWires, sz.yWires );

                // copy advanced output setting thru' from ZytContentFrame
                z2RawWindow.setAdvancedMode( Z2RawImageWindow::FlagGridOn | Z2RawImageWindow::FlagColorMap2 );

                zul_useKernelIFace(true);
                z2RawWindow.exec();
                zul_useKernelIFace(false);
                break;
        }

        if ( (ZXY100_PRODUCT_ID == devPID) || (ZXY110_PRODUCT_ID == devPID) )
        {
        }
        else
        {
        }

        rawViewButton->setEnabled(true);

        buttonPressHoldoff = QTime::currentTime();
        if (inhibitLEDPolling != NULL)
        {
            *inhibitLEDPolling = false;
        }
    }
}


/**
* accept the LED polling control boolean, so that this class can then stop polling
* the controller for LED status values.
* The benefit is to reduce the comms when basic-setup and integration testsPoll(bool *inhibit)
{ are
* running (full screen => no need for LED updates).
*/
void TestSensorFrame::setLEDPoll(bool *inhibit)
{
    // remember the address of the flag
    inhibitLEDPolling = inhibit;
    // printf("Z2T Inhibit \n");
}
