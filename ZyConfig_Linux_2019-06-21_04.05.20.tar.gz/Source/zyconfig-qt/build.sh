#!/bin/bash
hostType=`uname`

# If your system has enough cores and memory,
#   increase following from 1 to 4, or higher.
#   e.g. $ export MAKE_JOBS=4
NUM_JOBS=1
if [ "$MAKE_JOBS" != "" ]; then
        NUM_JOBS="$MAKE_JOBS"
    echo "Make run with $NUM_JOBS parallel jobs requested."
else
    echo -e "For faster builds, consider :\n $ export MAKE_JOBS=4\n"
fi

export QT_SELECT=5
txtLine=" - - - - - - - - - - - - - - - - - - - - - - - - \n"
echo Build ZyConfig GUI
echo -e $txtLine
echo "    Running" `pwd`   $0 $1
echo -e $txtLine

if [ "$1" == "clean" ]; then
    rm -rf ./tmpObj ./ZyConfig
    mkdir -p ./tmpObj
fi

# check for library
if [ ! -e ../zylib/libzylib.a  ]; then
    cd ../zylib
    ./build.sh
    cd -
fi

export QT_SELECT=5
  qttool=qmake
    which $qttool 2> /dev/null
    if [ $? -eq 1 ] ; then
            qttool=qmake-qt5
    fi
$qttool ZyConfig-qt.pro
make -j$NUM_JOBS
cp ./ZyConfig ../bin
strip ../bin/ZyConfig

echo "Script $0 exit"
echo -e $txtLine
