/*
 *      Generic widget to act as container for pages of the configuration
 *      application. Each page is expected to have a content frame and
 *      a title.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef ZYTCONFIGPAGE_H
#define ZYTCONFIGPAGE_H

#include <QWidget>
#include "PageTitleFrame.h"
#include "ZytContentFrame.h"

/* Class for pages including content and title within
 * the congifuration app
 */

class ZytConfigPage : public QWidget
{
    Q_OBJECT
public:
    ZytConfigPage(const QString title, ZytContentFrame *content, QWidget *parent = 0);
    void reReadValues();

protected:
    ZytConfigPage(QWidget *parent = 0);
    QLayout * createLayout();

    //PageTitleFrame *titleFrame;
    ZytContentFrame *contentFrame;

private:
    void createWidgets(const QString title);
};

#endif // ZYTCONFIGPAGE_H
