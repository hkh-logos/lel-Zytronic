/*
 *      Widget to act as notifcation of result of an API call.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */



#ifndef ZYTAPIRESULT_H
#define ZYTAPIRESULT_H

#include <QLabel>
#include <QtWidgets>

class ZytAPIResult : public QLabel
{
    Q_OBJECT
public:
    explicit ZytAPIResult(QWidget *parent = 0);

    enum ResultState
    {
        // RootCommand,  -- Deprecated 2018
        Progress, Success, Failure,
        HideResult
    };

public slots:
    void displayResult(ZytAPIResult::ResultState state);
    void displayResult(QString message, ZytAPIResult::ResultState state);

private slots:
    void hideResult();

private:
    void setupPalette();
    void createWidgets();
    void createConnections();

    QColor bgColour;
    QColor textColour;

    QTimer *showTimer;
};

#endif // ZYTAPIRESULT_H
