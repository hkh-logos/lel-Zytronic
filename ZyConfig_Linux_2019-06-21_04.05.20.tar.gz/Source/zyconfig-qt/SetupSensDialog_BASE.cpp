/*
 * Basic Setup Process - Base class.
 *
 *  Displays a number of points on the screen in order to evaluate touch
 *  sensitivity data and then set the controller thresholds appropriately.
 *  Also set the axes for the given sensor-display integration.
 *  Also, set the noise handling parameters.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


/*
    This class holds the common services for a controller specific Basic Setup
    process, which should provide a reasonable set of values for:

    - the sensitivity setting
    - the sensor orientation:
            - axes swapped, or normal
            - axis flipped, or normal

    --------------------

    Basic Call Tree:

        exec()
            initData()
            start fastTick to call tick() -- see 'TICKS_PER_SECOND'
            QDialog::exec()

        tick()
            conditionally sample data
            if (state.timeout passed || measurementOK) changeState()

        changeState()
            save data from controller at end of state period
            determine next state, and period (terminate on error, or completion)
            move to new state, and send prep commands to controller

    --------------------
*/

#include "SetupSensDialog_BASE.h"

#include <sys/timeb.h>      // only for debug messages

/**
 * DebugText can be used to add more (debug/diagnostic) information to the
 * basic setup logfile.   See  basicSetupLog: "/tmp/zyconfig-setup.log"  */

const int SetupSensDialog_BASE::DebugText = 0;


/**
 * The touch-point sequence a user is asked to follow
 */
const int SetupSensDialog_BASE::TouchSequence[] =
{
    CALP_MIDDLE_BOTTOM,     // not used !
    CALP_MIDDLE_MIDDLE,
    CALP_LEFT_TOP,
    CALP_LEFT_BOTTOM,
    CALP_RIGHT_BOTTOM,
    CALP_RIGHT_TOP,
    CALP_MIDDLE_MIDDLE,     // not used !
};


/**********************************************************
 *          Constructor
 *********************************************************/

SetupSensDialog_BASE::SetupSensDialog_BASE(QWidget *parent) : QDialog(parent)
{
    basicSetupLog = new ZyLogFile("/tmp/zyconfig-setup.log");
    basicSetupLog->WipeFile();
    basicSetupLog->EnableTimeStamp(true);
    basicSetupLog->Write2Log("BasicSetup - Construction");

    // mark invalid
    devPID = -1;
    pAssignedMonitor = NULL;
    noiseMax = 0;
}

// Destructor
SetupSensDialog_BASE::~SetupSensDialog_BASE()
{
    basicSetupLog->Sync2Disk();
    delete basicSetupLog;
}


/*---------------------------------------------------------
 *  Launch point for Dialog
 *-------------------------------------------------------*/
int SetupSensDialog_BASE::exec()
{
    int ret = QDialog::Rejected;

    //create tick timer to drive the process
    //      NB: don't access a timer from different threads
    fastTick = new QTimer();
    fastTick->setInterval(1000/TICKS_PER_SECOND); // milliseconds per tick
    fastTick->setSingleShot(false);
    QObject::connect(fastTick, SIGNAL(timeout()), this, SLOT(tick()));

    if (pAssignedMonitor == NULL)
    {
        basicSetupLog->Write2LogF("Set the monitor before starting.");
        return ret;
    }

    initData();

    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    showFullScreen();
    update();
    this->move(monitorRect.topLeft());
    this->resize(monitorRect.width(), monitorRect.height());
    activateWindow();
    update();

    fastTick->start();
    QDialog::exec();
    if (state.panelState == Finished)
        ret = QDialog::Accepted;
    fastTick->stop();
    delete fastTick;

    basicSetupLog->Sync2Disk();     // flush LogFile
    pAssignedMonitor = NULL;        // client must set for each run
    return ret;
}


/**
 * module global initialisation
 */
bool SetupSensDialog_BASE::initData(void)
{
    state.firstTick = true;
    zul_getDevicePID(&devPID);
    zul_getSensorSize(&szSensor);
    basicSetupLog->Write2LogF("%s PID: %d, Sensor x:%d y:%d",
                __FUNCTION__, devPID, szSensor.xWires, szSensor.yWires);

    noiseMax = 50;

    state.panelState = SaveSettings;
    state.timeout = 1;
    state.touchSeqLoc = 0;
    state.currentPointIndex = TouchSequence[state.touchSeqLoc];
    state.touchMargin  = 0;
    state.touchMinimum = 2000;
    state.touchStateCount = 0;
    wipeTouchSamples();

    initData2();    // call sub-class init

    initProposal();

    return true;
}


/**
 */
void SetupSensDialog_BASE::setMonitor(Monitor *m)
{
    pAssignedMonitor = m;
    pAssignedMonitor->getRect(&monitorRect);
}


/**
 * initialize the settings SettingProposal
 */
void SetupSensDialog_BASE::initProposal(void)
{
    /* getNextState_* sets the some values before use:
     *   - setProposal.pseudoUpperThr
     *   - setProposal.palm
     */

    setProposal.glassThickness     = ZXY100_GLASS_THIN;
    setProposal.flexiLocation      = ZXY100_FLEXI_LEFT;  // => landscape
    setProposal.invertXaxis        = false;
    setProposal.invertYaxis        = false;
    setProposal.swapAxes           = false;
    setProposal.interpolatorBias   = 0;
}


/**
 * zero the data collection per point
 */
void SetupSensDialog_BASE::wipeTouchSamples(void)
{
    basicSetupLog->Write2Log( __FUNCTION__ );

    touchData.xLoc        = 2000; // obviously out-of-bounds
    touchData.yLoc        = 2000;
    touchData.xPressMax   = 0;
    touchData.yPressMax   = 0;

    touchData.numAboveThresh = 0;
    touchData.numBelowThresh = 0;

    // SelfCap status
    touchData.isPseudoTouched   = false;
    touchData.wasPseudoTouched  = false;
    touchData.wasTouchedCounter = 0;

    if ((szSensor.xWires > MAX_X_BINS) || (szSensor.yWires > MAX_X_BINS))
    {
        throw "Invalid sensor size";
    }

    for (int x=0; x<szSensor.xWires; x++)
    {
        touchData.sumAtX[x] = touchData.numAtX[x] = 0;
        touchData.minAtX[x] = 2000; // obviously out-of-bounds
    }

    for (int y=0; y<szSensor.yWires; y++)
    {
        touchData.sumAtY[y] = touchData.numAtY[y] = 0;
        touchData.minAtY[y] = 2000;
    }
}

/**
 * From the samples collected during a single contact, locate the X and Y for
 * the touch, and the minimum touch signal level of that touch
 */
void SetupSensDialog_BASE::processPseudoTouch(void)
{
    // locate the max X pressure
    for (int x=0; x<szSensor.xWires; x++)
    {
        if (touchData.numAtX[x])
        {
            int v = touchData.sumAtX[x];
            if (touchData.xPressMax < v )
            {
                touchData.xPressMax = v;
                touchData.xLoc      = x;
            }
        }
    }

    // locate the max Y pressure
    for (int y=0; y<szSensor.yWires; y++)
    {
        if (touchData.numAtY[y])
        {
            int v = touchData.sumAtY[y];
            if (touchData.yPressMax < v)
            {
                touchData.yPressMax = v;
                touchData.yLoc      = y;
            }
        }
    }

    if (touchData.yPressMax == 0)
    {
        basicSetupLog->Write2LogF("processPseudoTouch - ZERO raw data! ");
        exit(0);
    }

    // accumulate the valid touch signal level
    if ((touchData.yPressMax/touchData.numAtX[touchData.xLoc] > 0) && (touchData.yPressMax/touchData.numAtY[touchData.yLoc] > 0))
    {
        testPtData[state.touchSeqLoc].signal = getPseudoTouchSignal();
        testPtData[state.touchSeqLoc].xLoc   = touchData.xLoc;
        testPtData[state.touchSeqLoc].yLoc   = touchData.yLoc;
    }
    else
    {
        basicSetupLog->Write2LogF(" >>> ERROR - assume that there was no touch !");
        // should never happen - throw an exception!
    }

    basicSetupLog->Write2LogF(" >>> %d %d %d %d",
            state.touchSeqLoc, testPtData[state.touchSeqLoc].signal,
            touchData.xLoc, touchData.yLoc );
}


/*
 *
 */
bool SetupSensDialog_BASE::isTouched(void)
{
    Contact c;
    if (zul_TouchAvailable(&c))
    {
        basicSetupLog->Write2Log( "Exit touch detected" );
        return true;
    }
    return false;
}


/**
 * handling keyboard events during the process
 */
void SetupSensDialog_BASE::keyPressEvent(QKeyEvent *event)
{
    haltRawData();

    if ((state.panelState == Finished))
    {
        basicSetupLog->Write2Log("NormalExit - any key Pressed");
        accept();
    }

    if (   (state.panelState == Failed_NoTouch)     ||
           (state.panelState == Failed_NoRelease)   ||
           (state.panelState == Failed_CommsError)  ||
           (state.panelState == Failed_Noise)
       )
    {
        basicSetupLog->Write2LogF("FailExit - any key Pressed");
        partialRestoreFactorySettings();
    }

    if ((event->key() == Qt::Key_Escape))
    {
        basicSetupLog->Write2Log("Process cancelled, esc pressed" );
        if ((state.panelState != Finished))
        {
            state.panelState = RestoreSettings;
            state.timeout = getStateTO();

            update();
            QApplication::processEvents();

            basicSetupLog->Write2Log("Reset to factory defaults");
            partialRestoreFactorySettings();
        }
    }
}

/**
 */
void SetupSensDialog_BASE::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        basicSetupLog->Write2LogF("YouReleasedEsc");
    }
}


float SetupSensDialog_BASE::getTimeLeft(void)
{
    return ((float)state.timeout)/TICKS_PER_SECOND;
}

/**
 * return a debug string reporting the time left in this state
 */
QString SetupSensDialog_BASE::getTimeLeft(int precision)
{
    if (DebugText > 0)
        return QString("\n" + tr("Time remaining") + " %1").arg( getTimeLeft(), -4, 'f', precision, ' ');
    else
        return "\n";
}


/**
 */
QString SetupSensDialog_BASE::getStateName2(void)
{
    return QString("state: ") + getStateCStr();
}

/**
 */
QString SetupSensDialog_BASE::getStateName(void)
{
    if (DebugText)
    {
        return getStateName2() + "\n";
    }
    return "";
}

/**
 * convert a PanelState value to a C printable state-name
 */
char const * SetupSensDialog_BASE::getStateCStr(void)
{
    switch (state.panelState)
    {
        case SaveSettings       : return "SaveSettings";
        case RestoreDefaults    : return "RestoreDefaults";
        case FirstTouchMeasureW : return "FirstTouchMeasureW";
        case FirstTouchMeasureB : return "FirstTouchMeasureB";
        case EqualizeSensor     : return "EqualizeSensor";
        case GetNoiseProfile    : return "GetNoiseProfile";
        case GetTouch           : return "GetTouch";
        case ReleaseTouch       : return "ReleaseTouch";
        case Confirm            : return "Confirm";
        case Finished           : return "Finished";
        case Failed_NoTouch     : return "Failed_NoTouch";
        case Failed_NoRelease   : return "Failed_NoRelease";
        case Failed_CommsError  : return "Failed_CommsError";
        case Failed_Noise       : return "Failed_Noise";
        case RestoreSettings    : return "RestoreSettings";
        case ChangeSens100      : return "ChangeSens(SC)";
        case NotifyChgSens100   : return "NotfyChgSen(SC)";
        default                 : return "Undefined state";
    }
}



/**
 * A set of tests for each of the 8 glass orientations.
 */
void SetupSensDialog_BASE::orientationTestFunc(void)
{
    int p;

    fprintf(stderr, "TEST for Select Axes Style A");
    p=1;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 40;      testPtData[p].yLoc      = 24;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 1;       testPtData[p].yLoc      = 1;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 1;       testPtData[p].yLoc      = 47;

    p++;        testPtData[p].signal = 200;
    p++;        testPtData[p].signal = 200;     processData();

    fprintf(stderr, "TEST for Select Axes Style B");
    p=1;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 40;      testPtData[p].yLoc      = 24;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 1;       testPtData[p].yLoc      = 1;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 79;      testPtData[p].yLoc      = 1;

    p++;        testPtData[p].signal = 200;
    p++;    testPtData[p].signal = 200;         processData();


    fprintf(stderr, "TEST for Select Axes Style C");
    p=1;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 40;      testPtData[p].yLoc      = 24;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 1;       testPtData[p].yLoc      = 47;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 1;       testPtData[p].yLoc      = 1;
    p++;        testPtData[p].signal = 200;
    p++;        testPtData[p].signal = 200;     processData();

    fprintf(stderr, "TEST for Select Axes Style D");
    p=1;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 40;      testPtData[p].yLoc      = 24;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 1;       testPtData[p].yLoc      = 48;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 79;      testPtData[p].yLoc      = 47;
    p++;        testPtData[p].signal = 200;
    p++;        testPtData[p].signal = 200;     processData();


    fprintf(stderr, "TEST for Select Axes Style E");
    p=1;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 40;      testPtData[p].yLoc      = 24;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 79;      testPtData[p].yLoc      = 1;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 79;      testPtData[p].yLoc      = 47;
    p++;        testPtData[p].signal = 200;     p++;        testPtData[p].signal = 200;
    processData();

    fprintf(stderr, "TEST for Select Axes Style F");
    p=1;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 40;      testPtData[p].yLoc      = 24;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 79;      testPtData[p].yLoc      = 1;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 1;       testPtData[p].yLoc      = 1;

    p++;        testPtData[p].signal = 200;
    p++;        testPtData[p].signal = 200;     processData();

    fprintf(stderr, "TEST for Select Axes Style G");
    p=1;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 40;      testPtData[p].yLoc      = 24;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 79;      testPtData[p].yLoc      = 48;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 1;       testPtData[p].yLoc      = 47;
    p++;        testPtData[p].signal = 200;
    p++;        testPtData[p].signal = 200;     processData();

    fprintf(stderr, "TEST for Select Axes Style H");
    p=1;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 40;      testPtData[p].yLoc      = 24;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 79;      testPtData[p].yLoc      = 47;
    p++;        testPtData[p].signal = 200;     testPtData[p].xLoc      = 79;      testPtData[p].yLoc      = 1;
    p++;        testPtData[p].signal = 200;
    p++;        testPtData[p].signal = 200;     processData();
}


/**
 * Draw the centre circle or corner arrows
 */
void SetupSensDialog_BASE::drawTarget(QPoint centre, int radius, QPainter *painter,
                                    int cx, int cy)
{
    int r2 = radius / 2;
    int x = centre.x(),         y = centre.y();
    int boxSize = (radius * 2);
    int boxXPos = (x - radius), boxYPos = (y - radius);

    // define the box to hold the centred target number
    QRect digitBox;     // consider setting dimensions based on radius (see boxSize,...)
    {                   // perhaps radius should alter the font size also ... or drop radius as a param!
        QPoint topLeft = QPoint(x-10,y-10);
        digitBox.setTopLeft(topLeft);
        digitBox.setBottomRight(topLeft+QPoint(20,20));
    }

    if (state.panelState != GetTouch)
    {
        return;
    }

    //Store previous painter settings
    painter->save();

    // draw main target blue circle
    painter->setPen(Qt::NoPen);
    painter->setBrush(QBrush(Qt::blue, Qt::SolidPattern));

    painter->drawPie(boxXPos, boxYPos, boxSize, boxSize, (0 * 16), (360 * 16));
                                            // angles specified in degrees/16

    // draw the sausage and arrow
    QPolygon polygon;
    if (y-cy != 0)  // skip the arrow on the centre spot
    {
        int percentage = 85;
        int dx = x-cx,              dy = y-cy;
        int headLenX = dx*4/100,    headLenY = dy*4/100;
        int xh = x-headLenX,        yh = y-headLenY;
        int hdSz = std::max(abs(headLenX), abs(headLenY))/2;
        double angle = atan(((double)(dy))/dx);

        // move cx,cy X% towards target 'centre'
        cx += dx*percentage/100;
        cy += dy*percentage/100;


        if (xh-cx < 0) angle += M_PI;

        int points[] = {
            xh,yh,    xh,yh,    xh,yh,    xh,yh,
        };
        // modify to a triangle
        points[0] += hdSz*cos( angle+M_PI+M_PI/7 ),
        points[1] += hdSz*sin( angle+M_PI+M_PI/7 );
        points[2] += hdSz*cos( angle+M_PI-M_PI/7 ),
        points[3] += hdSz*sin( angle+M_PI-M_PI/7 );
        polygon.setPoints(4, points);

        painter->setBrush(QBrush(Qt::blue,Qt::SolidPattern));

        painter->setPen(QPen(Qt::blue, radius, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter->drawLine( cx, cy, x, y );      // chunky blue slot

        painter->setPen(QPen(Qt::white, 1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter->drawLine( cx, cy, xh, yh );    // arrow shaft
        painter->drawEllipse( cx-r2/4, cy-r2/4, r2/2, r2/2 );
        painter->drawPolygon ( polygon, Qt::OddEvenFill );
    }

    // draw the target number last
    {
        QFont font=painter->font();
        font.setPointSize ( 18 );
        font.setWeight(QFont::DemiBold);
        painter->setFont(font);
        painter->setPen(Qt::white);
        painter->drawText( digitBox, (Qt::AlignHCenter | Qt::AlignVCenter),
                           QString("%1").arg(state.touchSeqLoc)
                         );
    }

    //restore painter settings
    painter->restore();
}

/**
 * called periodically to provide user guidance
 */
void SetupSensDialog_BASE::paintEvent(QPaintEvent*)
{
    static QString  suppTxtCopy = "";
    QString         supportText, signalData;
    QColor          bgColor = Qt::white;
    QColor          penColor = Qt::darkBlue;

    if (pAssignedMonitor == NULL)
    {
        basicSetupLog->Write2LogF("Painting IT - no monitor set");
        return;
    }

    switch (state.panelState)
    {
        case SaveSettings:
        // might call this process prior to opening this full screen dialogue ...
            supportText = QString( ""); // "Saving controller settings\n" );
            supportText += getStateName();
            supportText += getTimeLeft(2);
            break;

        case FirstTouchMeasureB:
            bgColor = Qt::black;
            [[gnu::fallthrough]];

        case RestoreDefaults:
        case FirstTouchMeasureW:
        case EqualizeSensor:
            supportText = QString( tr("Setting factory defaults") + "\n" +
                                   tr("and equalizing sensor") );

            //if ( (state.panelState == RestoreDefaults) && (ZXY300_PRODUCT_ID == devPID) )
            //    supportText +=  QString(" (%1)").arg(state.timeout/TICKS_PER_SECOND + 4);

            supportText += "\n\n" + tr("DO NOT TOUCH THE SENSOR")  + "\n" ;

            supportText += getStateName();
            supportText += getTimeLeft(2);
            penColor = Qt::red;
            break;

        case ChangeSens100:  // .. OR ... supportText = QString( tr("REMOVE FINGER FROM SENSOR") )  + "\n"; ??
        case NotifyChgSens100:
            supportText = QString( tr("TOUCH SEQUENCE RESTART")      + "\n" +
                                   tr("Changing coarse sensitivity") + "\n\n" +
                                   tr("DO NOT TOUCH THE SENSOR")     + "\n" );
            supportText += getStateName();
            supportText += getTimeLeft(2);
            penColor = Qt::red;
            break;

      case GetNoiseProfile:
            supportText = QString( tr("Collecting ambient noise data") + "\n\n" +
                                   tr("DO NOT TOUCH THE SENSOR\n") );

            // sets some state values only

            supportText += getStateName();
            supportText += getTimeLeft(2);
            penColor = Qt::red;
            break;

        case GetTouch:
            if (state.touchSeqLoc == 1)
            {
                supportText = QString( tr("Place your finger on target ") + " %1 \n" +
                                       tr("and do not remove it") + "\n\n" +
                                       tr("Only one finger should be in") + "\n" +
                                       tr("contact with the sensor") + "\n"
                                     ).arg(state.touchSeqLoc);
            }
            else
            {
                supportText = QString( tr("Move a finger along the arrow to") + " \n" +
                                       tr("target %1 and hold it on the number") + "\n\n" +
                                       tr("Only one finger should be in ") + "\n" +
                                       tr("contact with the sensor") + "\n"
                                     ).arg(state.touchSeqLoc);
            }

            supportText += getStateName();
            supportText += getTimeLeft(2);
            break;

        case ReleaseTouch:
            supportText = QString( tr("REMOVE FINGER FROM SENSOR") + "\n" );
            supportText += getStateName();
            supportText += getTimeLeft(2);
            penColor = Qt::red;
            break;

        case Confirm:
            supportText = QString( "Results\nUpper Threshold  %1\n"
                                            "Palm Threshold   %2\n"
                                   ).arg(setProposal.pseudoUpperThr)
                                    .arg(setProposal.palmThresh)  ;

            supportText += QString("\n\n"
                                    "Preparing test screen ..."
                                    );
            supportText += getStateName();
            supportText += getTimeLeft(2);
            break;

        case Finished:
            supportText = QString(  tr("Basic Setup Complete") + "\n\n" +
                                    tr("Controller has been updated") + "\n\n" +
                                    tr("Press") + " \"ESC\" "+ tr("key or touch and hold to exit")
                                 );
            break;

        case Failed_NoTouch:
            supportText = QString(  tr("ERROR. Unable to detect touch") + "\n" +
                                    tr("Please see Integration Manual") + "\n" +
                                    tr("Press any key to exit") + "\n"
                                 );
            supportText += getTimeLeft(1);
            break;

        case Failed_NoRelease:
            supportText = QString(  tr("ERROR. Unable to confirm finger removal.") + "\n" +
                                    tr("Probable noise issue") + "\n" +
                                    tr("Press any key to exit") + "\n"
                                 );
            supportText += getTimeLeft(1);
            break;

        case Failed_CommsError:
            supportText = QString(  tr("USB ERROR.") + "\n" +
                                    tr("Press any key to exit") + "\n"
                                 );
            supportText += getTimeLeft(1);
            break;

        case Failed_Noise:
            supportText = QString(  tr("ERROR: Noise events detected") + "\n" +
                                    tr("Restoring controller state ... ")  + "\n" );
            supportText += getTimeLeft(1);
            break;

        case RestoreSettings:
            supportText = QString( tr("Restoring controller state") + "\n" +
                                   tr("Please wait ... ") + "\n" );

            supportText += getTimeLeft(1);
            break;

        case LastState:
        default:
            supportText = QString( tr("Error in state Machine") + "\n" );
            break;
    }

    // ----------------------------------------------------

    QPainter painter(this);
    painter.fillRect(rect(), bgColor);
    painter.setRenderHint(QPainter::Antialiasing);

    int width  = this->width();
    int height = this->height();

    border = std::min(width, height) / 30;
    int cBorder = border; //  * 2.5;
    int targetRadius = border-1;

    //find point for current calibration target
    setCalibrationPoint(width, height, border, state.currentPointIndex);

    //draw calibration target
    drawTarget(state.currentPoint, targetRadius, &painter, width/2, height/2);

    //set size and position of cancel box
    QPoint topLeft;
    QPoint bottomRight;

    positionInfoBox(width, height, cBorder, &topLeft, &bottomRight);
    infoBox.setTopLeft(topLeft);
    infoBox.setBottomRight(bottomRight);

    topLeft += QPoint(0, infoBox.height());
    bottomRight += QPoint(0, 40);
    dataBox.setTopLeft(topLeft);
    dataBox.setBottomRight(bottomRight);

    //draw info box
    painter.setPen(Qt::black);
    painter.drawRect(infoBox);

    int dimension = (width < height) ? width : height;
    QFont font=painter.font();
    font.setPointSize ( (int)(dimension * 8) / 600 );
    painter.setFont(font);
    painter.setPen(penColor);

    painter.drawText(infoBox, (Qt::AlignCenter | Qt::TextWordWrap), supportText);
    int lineEnd = supportText.indexOf('\n');
    supportText = supportText.left(lineEnd);
    if (suppTxtCopy.compare(supportText))
    {
        suppTxtCopy = supportText;
        basicSetupLog->Write2LogF( "User guidance: %s", supportText.toLatin1().data() );
    }

    // painter.setPen(Qt::black);  painter.drawRect(dataBox);
    painter.setPen(Qt::red);
    painter.drawText(dataBox, (Qt::AlignCenter | Qt::TextWordWrap), signalData);
}

/**
 */
void SetupSensDialog_BASE::setCalibrationPoint(int width, int height, int border, int index)
{
    switch(index)
    {
        case CALP_LEFT_TOP:
            state.currentPoint = QPoint(border, border);
            break;
        case CALP_LEFT_MIDDLE:
            state.currentPoint = QPoint(border, (height / 2));
            break;
        case CALP_LEFT_BOTTOM:
            state.currentPoint = QPoint(border, (height - border));
            break;
        case CALP_MIDDLE_BOTTOM:
            state.currentPoint = QPoint((width / 2), (height - border));
            break;
        case CALP_RIGHT_BOTTOM:
            state.currentPoint = QPoint((width - border), (height - border));
            break;
        case CALP_RIGHT_MIDDLE:
            state.currentPoint = QPoint((width - border), (height / 2));
            break;
        case CALP_RIGHT_TOP:
            state.currentPoint = QPoint((width - border), border);
            break;
        case CALP_MIDDLE_TOP:
            state.currentPoint = QPoint((width / 2), border);
            break;
        case CALP_MIDDLE_MIDDLE:
        default:
            state.currentPoint = QPoint((width / 2), (height / 2));
            break;
    }
}

/**
 *
 */
void SetupSensDialog_BASE::positionInfoBox (
    int width, int height, int cBorder, // int index,
    QPoint *topLeft, QPoint *bottomRight
)
{
    *topLeft = QPoint(cBorder*7, cBorder);
    *bottomRight = QPoint((width - cBorder*7), (height / 3 - cBorder));
}



/**
 * Based on the measurements, here we determine the values for the controller.
 * This optimally sets the 'setProposal' values, which applySettings() transmits
 * to controller.
 */
void SetupSensDialog_BASE::processData(void)
{
    // Find minimum touch from the 5
    for (int t=0; t<NUM_TSEQ_POINTS; t++)
    {
        if (state.touchMinimum > testPtData[t+1].signal)
        {
            state.touchMinimum = testPtData[t+1].signal;
        }
        basicSetupLog->Write2LogF(" >>> Target:%d Signal:%d @ (%d,%d)\n",
                                t+1, testPtData[t+1].signal,
                                testPtData[t+1].xLoc, testPtData[t+1].yLoc );
    }

    state.touchMargin = state.touchMinimum - noiseMax;
    if (state.touchMargin > 0)
    {
        updateSetProposal();
    }
    else
    {
        basicSetupLog->Write2LogF(
            "Can't determine optimal upper threshold as there is no noise margin!"
            "NoiseMax : %d, MinTouch : %d, PseudoThreshold : %d",
            noiseMax, state.touchMinimum, setProposal.pseudoUpperThr       );
    }

    struct testPtData_s *pTD = testPtData;
    basicSetupLog->Write2LogF(
        "The first 3 test-touch sensor locations are : [%d,%d] [%d,%d] [%d,%d]",
                    pTD[1].xLoc, pTD[1].yLoc,
                    pTD[2].xLoc, pTD[2].yLoc,
                    pTD[3].xLoc, pTD[3].yLoc    );

    // set the axis flips
    if (testPtData[2].xLoc < testPtData[1].xLoc)
    {
        if (testPtData[2].yLoc < testPtData[1].yLoc)
        {
            if (testPtData[3].yLoc > testPtData[1].yLoc)
            {
                // here we deal with the touches  |  2     5
                //                                |     1
                //                                |  3     4

                basicSetupLog->Write2LogF("Select Axes Style A");
                setProposal.swapAxes = false, setProposal.invertXaxis = false, setProposal.invertYaxis = false;
            }
            else
            {
                // here we deal with the touches  |  2     3
                //                                |     1
                //                                |  5     4

                basicSetupLog->Write2LogF("Select Axes Style B");
                setProposal.swapAxes = true, setProposal.invertXaxis = false, setProposal.invertYaxis = false;

                if (devPID == ZXY100_PRODUCT_ID) setProposal.invertXaxis = !setProposal.invertXaxis;
            }
        }
        else  // (testPtData[2].yLoc > testPtData[1].yLoc)
        {
            if (testPtData[3].yLoc < testPtData[1].yLoc)
            {
                // here we deal with the touches  |  3     4
                //                                |     1
                //                                |  2     5

                basicSetupLog->Write2LogF("Select Axes Style C");
                setProposal.swapAxes = false, setProposal.invertXaxis = false, setProposal.invertYaxis = true;
            }
            else //(testPtData[3].yLoc > testPtData[1].yLoc)
            {
                // here we deal with the touches  |  5     4
                //                                |     1
                //                                |  2     3

                basicSetupLog->Write2LogF("Select Axes Style D");
                setProposal.swapAxes = true, setProposal.invertXaxis = true, setProposal.invertYaxis = false;

                if (devPID == ZXY100_PRODUCT_ID) setProposal.invertXaxis = !setProposal.invertXaxis;
            }

        }
    }
    else // (testPtData[2].xLoc > testPtData[1].xLoc)
    {
        if (testPtData[2].yLoc < testPtData[1].yLoc)
        {
            if (testPtData[3].yLoc > testPtData[1].yLoc)
            {
                // here we deal with the touches  |  5     2
                //                                |     1
                //                                |  4     3

                basicSetupLog->Write2LogF("Select Axes Style E");
                setProposal.swapAxes = false, setProposal.invertXaxis = true, setProposal.invertYaxis = false;
            }
            else // (testPtData[3].yLoc < testPtData[1].yLoc)
            {
                // here we deal with the touches  |  3     2
                //                                |     1
                //                                |  4     5

                basicSetupLog->Write2LogF("Select Axes Style F");
                setProposal.swapAxes = true, setProposal.invertXaxis = false, setProposal.invertYaxis = true;

                if (devPID == ZXY100_PRODUCT_ID) setProposal.invertXaxis = !setProposal.invertXaxis;
            }
        }
        else  // (testPtData[2].yLoc > testPtData[1].yLoc)
        {
            if (testPtData[3].yLoc > testPtData[1].yLoc)
            {
                // here we deal with the touches  |  4     5
                //                                |     1
                //                                |  3     2

                basicSetupLog->Write2LogF("Select Axes Style G");
                setProposal.swapAxes = true, setProposal.invertXaxis = true, setProposal.invertYaxis = true;


                if (devPID == ZXY100_PRODUCT_ID) setProposal.invertXaxis = !setProposal.invertXaxis;
            }
            else //(testPtData[3].yLoc < testPtData[1].yLoc)
            {
                // here we deal with the touches  |  4     3
                //                                |     1
                //                                |  5     2

                basicSetupLog->Write2LogF("Select Axes Style H");
                setProposal.swapAxes = false, setProposal.invertXaxis = true, setProposal.invertYaxis = true;
            }
        }
    }
}



/**  ======================================================================================
 *      state Progression Control
 *   ======================================================================================
 *   The following pattern is applied to a state change:
 *      1. Retrieve any data from controller required at the end of current state
 *      2. Change the state variable to next state
 *      3. Execute the state-initialization code for the new state
 *
 *  A 'transition' is either "scNormal", or "scExit" to deal with abnormal situations
 */
void SetupSensDialog_BASE::changeState(StateChange transition)
{
    basicSetupLog->Sync2Disk();

    // reset the timers to the defaults
    state.timeout = 3 * TICKS_PER_SECOND;

    switch (transition)
    {
        case scExit:
        case scCancel:
            if ((state.panelState == Finished))
            {
                haltRawData();
                basicSetupLog->Write2LogF("  - - - -   exit/cancel\n");
                accept();
                return;
            }
            break;

        case scNormal:      // normal progress

            // === take info from this state ============================

            if ( storeStateData() > 0)
            {
                basicSetupLog->Write2LogF("EARLY RETURN REQUESTED [%d] %s\n",
                            state.panelState, getStateCStr() );

                // do not process a normal state change, do not prep for new state
                return;
            }

            // === move to next state   =================================

            basicSetupLog->Write2LogF("Old %s [%d]\t\t-- Z1_TSC:%d",
                    getStateCStr(), state.panelState, state.touchStateCount);

            // change the state variables, according to the MT/SC rules
            getNextState();
            state.timeout = getStateTO();

            basicSetupLog->Write2LogF("New %s [%d]\t\t-- Z1_TSC:%d",
                    getStateCStr(), state.panelState, state.touchStateCount);

            // === handle prep work for new state   =====================

            prepNewState();
            state.currentPointIndex = TouchSequence[state.touchSeqLoc];

            break;          // scNormal transition
    }
}


/**
 * Periodically measure sensor values, to trigger the state-machine transitions
 */
void SetupSensDialog_BASE::tick()
{
    if (state.firstTick)
    {
        update();
        state.firstTick = false;
    }

    uint16_t    tpMin=0, tp_x=0, tp_y=0;

    if (DebugText>=2)
    {
        struct timeb timebuffer;
        char timeStr[80];

        ftime( &timebuffer );
        sprintf( timeStr, "%.19s.%03d", ctime( & ( timebuffer.time ) ), timebuffer.millitm );

        basicSetupLog->Write2LogF( "BS @ %s %s[%d] - ticksLeft:%03d TchSmpls:%02d/%02d",
                    timeStr+11, getStateCStr(), state.panelState,
                    state.timeout, touchData.numAboveThresh, touchData.numBelowThresh );
    }

    if (state.panelState >= GetTouch)
    {
        tpMin = getSignalLevel();
    }
    else
    {
        update();
    }

    if (state.panelState == GetTouch)
    {
        if (tpMin > 0) // ignore ZERO readings
        {
            if (tpMin >= setProposal.pseudoUpperThr)
            {
                touchData.numAboveThresh ++ ;
                touchData.isPseudoTouched = true;
                touchData.wasPseudoTouched = true;
                touchData.wasTouchedCounter++;

                getSignalLocation(&tp_x, &tp_y);

                touchData.sumAtX[tp_x] += tpMin;
                touchData.numAtX[tp_x] ++;
                if (touchData.minAtX[tp_x] > tpMin) touchData.minAtX[tp_x] = tpMin;

                touchData.sumAtY[tp_y] += tpMin;
                touchData.numAtY[tp_y] ++;
                if (touchData.minAtY[tp_y] > tpMin) touchData.minAtY[tp_y] = tpMin;
            }

            if (tpMin < setProposal.pseudoUpperThr - ZXY110_THRESHOLD_DEBOUNCE) // this should work for 100, 110 and MT devices
            {
                touchData.numBelowThresh ++;
                touchData.isPseudoTouched = false;
            }
        }

        if (DebugText==1)
        {
            // summary line
            basicSetupLog->Write2LogF( "= SAMPLE %04d min|x:%04d,y:%04d| @ (%02d,%02d) UT:%d GT:%d",
                        tpMin, touchData.minAtX[tp_x], touchData.minAtY[tp_y], tp_x, tp_y,
                        setProposal.pseudoUpperThr, setProposal.glassThickness);
            basicSetupLog->Write2LogF( "= SAMPLE Nums:%02d/%02d is/was:%d/%d wasCount:%d",
                        touchData.numAboveThresh, touchData.numBelowThresh,
                        touchData.isPseudoTouched, touchData.wasPseudoTouched, touchData.wasTouchedCounter
                        );
        }
    }

    if ((state.panelState == ReleaseTouch) && (tpMin <= noiseMax))
    {
        touchData.numBelowThresh ++ ;
    }

    state.timeout--;

    if (state.panelState == Finished)
    {
        // allow a touch to return to main app (or exit)
        if (isTouched())
        {
            zy_msleep(500);   // dummy for press and hold!
            changeState(scExit);
        }
    }
    else
    {
        if  ( (state.timeout <= 0) ||
              ( (state.panelState == GetTouch) && (touchData.numAboveThresh > REQD_ON_SAMPLES) )   ||
              ( (state.panelState == ReleaseTouch) && (touchData.numBelowThresh > REQD_OFF_SAMPLES) )
            )
        {
            changeState(scNormal);
        }
    }

    // The ZXY110 has finished the restore defaults process when the device
    // reports a FTM is not active. It searches for a (new) stable frequency
    // after the factory default settings are requested.
    if (    (devPID == ZXY110_PRODUCT_ID) &&
            ( (state.panelState == RestoreDefaults) || (state.panelState == RestoreSettings) )
       )
    {
        changeStateWhenRestoreDone();
    }

    if (state.panelState == Finished)
    {
        if ((state.timeout % 2) == 1)
        {
            update();
        }
    }
    else
    {
        // periodic maintenance
        if ((state.timeout % (TICKS_PER_SECOND/2)) == 1)
        {
            update();
        }
        if ((state.timeout % TICKS_PER_SECOND) == 1)
        {
            // for some controllers, the setup process can't continue
            // under all circumstances (from C# Basic_Setup_110)
            if (errorEventsOccurred())
            {
                state.panelState = Failed_Noise;
                state.timeout = getStateTO();

                // ensure users are informed
                update();
                QApplication::processEvents();
            }
        }
    }
}
