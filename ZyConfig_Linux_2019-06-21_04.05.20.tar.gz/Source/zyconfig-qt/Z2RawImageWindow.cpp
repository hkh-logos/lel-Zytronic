/*  Z2RawImageWindow
  ================

  This class provides a real-time graphic of the data detected by the sensor,
  prior to touch detection.

*/


/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#define MARK_PACKETS            (0)     // diagnostic aid
#define COPY_TO_FILE            (0)     // diagnostic aid
#define USE_QIMAGE_PAINT        (0)     // alternative repaint method
#define FRAME_PERIOD_MS         (15)    // ??? ToDo Tune


// set to true to observe some status/progress messages on stderr
static const int    DebugText  = 0;

#include <stdio.h>
#include <unistd.h>
#include <QtWidgets>
#include <QScreen>
#include <QClipboard>

#include "zytypes.h"
//#include "comms.h"
#include "zxymt.h"
#include "services.h"


#include "Z2RawImageWindow.h"
#include <time.h>
#include <sys/timeb.h>

/**
 * Constructor
 */
Z2RawImageWindow::Z2RawImageWindow(QWidget *parent) :
    QDialog(parent)
{
    Title       = QString(tr("Test Sensor"));
    exitStr     = QString(tr("Press any key to exit"));

    numXWires   = 0;
    numYWires   = 0;
    cellCount   = 0;
    running     = false;
    drawResize  = false;
    xFlip       = false;
    yFlip       = false;

    dumpFile    = NULL;
    modeBitField= 0;

#if (COPY_TO_FILE)
    dumpFile    = fopen("./dump.bin", "w");
#else
    dumpFile    = NULL;
#endif

    msToRun     = 600000;   // 10 minute maximum runtime

    //create timeout timer
    frameTimer = new QTimer(this);
    QObject::connect(frameTimer,SIGNAL(timeout()), this,SLOT(monitor()));
}


/**
 * Key Handlers
 */
void Z2RawImageWindow::keyPressEvent(QKeyEvent *event)
{
    if ((event->key() != Qt::Key_Escape))
    {
        //if (DebugText) fprintf(stderr, "\tStopTick\n");
        frameTimer->stop();

        accept();
    }

    if ((event->key() == Qt::Key_Escape))
    {
        if (DebugText)
        {
            fprintf(stderr, "Process cancelled, esc pressed\n");
            fprintf(stderr, "\tStopTick\n");
        }
        frameTimer->stop();

        reject();
    }
}
void Z2RawImageWindow::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        if (DebugText) fprintf(stderr, "YouReleasedEsc");
    }
}

/**
 *
 */
void Z2RawImageWindow::dumpToFile(void)
{
    size_t ws;
    if (dumpFile == NULL) return;

    rawData[0] = 0xEE;          // frame Sync
    ws = write(fileno(dumpFile), rawData, sizeof(rawData));

    if (ws != sizeof(rawData)) fprintf(stderr, "dumpFile write error\n");
}

void Z2RawImageWindow::setDimensions(uint16_t width, uint16_t heigth)
{
    if (!running)
    {
        numXWires = width;
        numYWires = heigth;
        cellCount = numXWires * numYWires;
    }
}


/**
 *
 */
void Z2RawImageWindow::setAdvancedMode(int bitField)
{
    modeBitField = bitField;
}

/**
 *
 */
void Z2RawImageWindow::setMsToRun(long msTimeout)
{
    msToRun = msTimeout;
}

/**
 * allow for per-second stats calculations
 */
void Z2RawImageWindow::monitor()
{
    long lastPacketAgeMS = zul_getRawInAgeMS();
    struct timeb now;

    if (!running)
    {
        fprintf(stderr, "Z2RawImageWindow - data transfers NOT RUNNING !!!! \n ");
        return;
    }

    if (lastPacketAgeMS > 500)
    {
        fprintf(stderr, "Raw data stream has been lost [%ldms]\n", lastPacketAgeMS );
        QApplication::postEvent(this , new QKeyEvent(QEvent::KeyPress, Qt::Key_Escape, Qt::NoModifier));
    }

    ftime(&now);
    long msTimePassed = ( now.time - startTime.time ) * 1000;
    msTimePassed += ( now.millitm - startTime.millitm );

    if (msTimePassed > msToRun)
    {
        fprintf(stderr, "Requested time has elapsed\n");
        QApplication::postEvent(this , new QKeyEvent(QEvent::KeyPress, Qt::Key_Escape, Qt::NoModifier));
    }

    // tell the driver to copy over the newest frame from the controller
    ++frameIndex;

    // refresh the display
    update();

    if (dumpFile != NULL) dumpToFile();

    if (DebugText)
    {
        // report frame rate info
        int secs = (int)(now.time % 1000);

        if (0) fprintf(stderr, "%d:Frame %04d, Time %d.%03d\n",
                        USE_QIMAGE_PAINT, frameIndex, secs, now.millitm);
    }
}


void Z2RawImageWindow::resizeEvent(QResizeEvent* event)
{
    drawResize = true;
    memset(refData, 0x1, cellCount);
    if (DebugText && (event != NULL))
    {
        fprintf(stderr, "NewSize %d,%d\n", event->size().width(), event->size().height() );
    }
}

/**
 *  Test drawing at 800x600 and 1280x1024, ... and ... ?
 */

void Z2RawImageWindow::paintEvent(QPaintEvent*)
{
    static int              width, height;
    QPainter                painter(this);
    static int              xRef, yRef, tileWd, tileHg, tickLen;
    static QColor           bkGndColor = Qt::black;

    // if (DebugText) fprintf(stderr, "PAINT %04x -- ", modeBitField );

    if (drawResize == true)
    {
        drawResize = false;

        if (modeBitField & Z2RawImageWindow::FlagBrightBackground)
        {
            bkGndColor = Qt::white;
            painter.fillRect(rect(), bkGndColor );
        }
        else
        {
            bkGndColor = QColor ( 20, 20, 20 );  // dark grey
            painter.fillRect(rect(), bkGndColor );
        }

        //painter.setRenderHint(QPainter::Antialiasing);

        width = size().width();
        height = size().height();

        tileWd = (width - 2) / numXWires;
        tileHg = (height - 2) / numYWires;
        tickLen = tileWd < tileHg ? tileWd : tileHg;      // take smaller side
        tickLen /= 4;
        xRef = ( width  - tileWd * numXWires ) / 2;
        yRef = ( height - tileHg * numYWires ) / 2;

        // if (DebugText) fprintf(stderr, "sz %d.%d Ref %d,%d\n", tileWd,tileHg, xRef, yRef);
    }

    // if (DebugText) fprintf(stderr, "DRAWING\n");

    unsigned int x,y;
    for (x=0; x<numXWires; x++)
    {
        unsigned int xx = xFlip ? numXWires-x-1 : x;

        painter.setPen(Qt::black);

        for (y=0; y<numYWires; y++)
        {
            const int location = x*numYWires + y;

            // only draw a cell when it has a new value
            if( rawData[location] != refData[location])
            {
                int yy = yFlip ? numYWires-y-1 : y;

                int xTopLeft = xRef + xx*tileWd;
                int yTopLeft = yRef + yy*tileHg;

                // const int ww = tileWd-grid, hh = tileHg-grid;
                int r = rawData[location];
                QColor heatColor;

                // use the Zytronic colour "heatmap"
                if (modeBitField & Z2RawImageWindow::FlagColorMap2)
                {
                    int g;
                    // preference for ZXY500
                    if (r >= 128)
                    {
                        g = (255+128) - r*6/4;
                        heatColor = QColor ( r, g, 0 );
                    }
                    else
                    {
                        g = r*2;
                        heatColor = QColor ( r, g, 0 );
                    }
                }
                else
                {
                    heatColor = (r) ? QColor ( r, 255-r, 0 ) : bkGndColor ; // Qt::black;
                }

                if ( (location % 60 == 59) && (MARK_PACKETS))
                {
                    heatColor = QColor ( 20, 20, 240 );
                }

                painter.fillRect( xTopLeft, yTopLeft,
                                      tileWd, tileHg, heatColor );
                if ( ((x%8==0) || (y%8==0) ) &&
                     (modeBitField & Z2RawImageWindow::FlagGridOn)
                   )
                {
                    painter.drawLine( xTopLeft, yTopLeft,
                                      xTopLeft, yTopLeft + tickLen );

                    painter.drawLine( xTopLeft, yTopLeft,
                                      xTopLeft + tickLen, yTopLeft );
                }

                refData[location] = rawData[location];
            }
        }
    }
}


/**
 *  Launch point for Dialog
 */
int Z2RawImageWindow::exec()
{
    int         ret = QDialog::Accepted;
    uint16_t    flip;

    ftime(&startTime);

    if (cellCount == 0)
    {
        // signal some fault - user must call setDimensions()
        fprintf(stderr, "User must call setDimensions() before running ...\n");
        return QDialog::Rejected;
    }

    if (DebugText) fprintf( stderr, ">>> X Y Cells:: %d %d %d\n", numXWires, numYWires, cellCount );

    memset(refData, 0x00, cellCount);
    memset(rawData, 0x01, cellCount);

    if (DebugText)
    {
        fprintf(stderr, "Rawdata transfer buffer @ %p, size %d\n", rawData, cellCount );
    }

    zul_getConfigParamByID(ZXYMT_CI_INVERT_X, &flip);
    xFlip = (flip > 0);

    zul_getConfigParamByID(ZXYMT_CI_INVERT_Y, &flip);
    yFlip = (flip > 0);

    // these two calls remove the auto-clear service of normal update()
    setAttribute(Qt::WA_OpaquePaintEvent);
    setAttribute(Qt::WA_NoSystemBackground);

    frameTimer->setInterval(FRAME_PERIOD_MS);
    frameTimer->start();


    zul_SetRawDataBuffer((void *)rawData);
    zy_msleep(200);
    zul_SetRawMode(1);
    running = true;

    setWindowTitle(tr("Test Sensor - Press 'ESC' to exit"));
    this->setModal(true);
    raise();
    activateWindow();
    // showMaximized();
    frameIndex = 0;
    update();
    // drawResize = true;
    // 
    resizeEvent(NULL);

    // Let the animation run ... escape key exits
    QDialog::exec();

    // when finished - stop the raw data
    zul_SetRawMode(0);
    zy_msleep(700);

    if (dumpFile != NULL)
    {
        fclose(dumpFile);
        dumpFile = NULL;
    }

    ret = QDialog::Accepted;
    frameTimer->stop();
    running = false;

    return ret;
}
