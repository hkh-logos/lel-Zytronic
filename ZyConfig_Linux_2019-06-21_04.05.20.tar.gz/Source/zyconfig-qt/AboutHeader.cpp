/*
 *      Header for the About Tab in the config app
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "AboutHeader.h"


#if defined(Q_OS_LINUX)

#define APP_FONT_SIZE       (20)
#define EDITION_FONT_SIZE   (10)

#else

#define APP_FONT_SIZE       (28)
#define EDITION_FONT_SIZE   (16)

#endif

AboutHeader::AboutHeader(QWidget *parent) :
    QFrame(parent)
{
    createWidgets();
    setLayout(createLayout());
}

void AboutHeader::createWidgets()
{
    logoLabel = new QLabel(this);
    QPixmap pixmap(":/images/zytronic_transparent.png");
    logoLabel->setPixmap(pixmap);
    logoLabel->setMask(pixmap.mask());

    setMaximumHeight(pixmap.height() + 20);

    createAppLogo();
}



void AboutHeader::createAppLogo()
{
    appLogo = new QWidget(this);

    QLabel *appName = new QLabel(tr("ZyConfig"),appLogo);
    QLabel *tm = new QLabel(tr("TM"),appLogo);
    QFont appFont = appName->font();
    appFont.setPointSize(APP_FONT_SIZE);
    appName->setFont(appFont);
    
    Qt::Alignment qta(Qt::AlignRight & Qt::AlignTop);

    appName->setAlignment(qta);
    QLabel *edition = createOSSpecificLabel();
    QFont editionFont = appName->font();
    editionFont.setPointSize(EDITION_FONT_SIZE);
    edition->setFont(editionFont);
    tm->setFont(editionFont);
    tm->setAlignment(Qt::AlignTop);
    edition->setAlignment(Qt::AlignRight);

    QHBoxLayout *frameLayout = new QHBoxLayout;
    QVBoxLayout *mainLayout = new QVBoxLayout;
    QHBoxLayout *appLayout = new QHBoxLayout;

    appLayout->addWidget(appName);

    // mainLayout->addStretch();
    mainLayout->addLayout(appLayout);
    mainLayout->addWidget(edition);
    mainLayout->addStretch();

    frameLayout->addLayout(mainLayout);
    frameLayout->addWidget(tm);
    frameLayout->setContentsMargins ( 0, 26, 0, 0);      //    left, top, right, bottom

    appLogo->setLayout(frameLayout);
}

#if defined(Q_OS_LINUX)

QLabel * AboutHeader::createOSSpecificLabel()
{
    return new QLabel(tr("Linux Edition"),appLogo);
}

#elif defined(Q_OS_WIN32)

QLabel * AboutHeader::createOSSpecificLabel()
{
    return new QLabel(tr("Windows Edition"),appLogo);
}

#elif defined(Q_OS_DARWIN)

QLabel * AboutHeader::createOSSpecificLabel()
{
    return new QLabel(tr("OSX Edition"),appLogo);
}

#else

QLabel * AboutHeader::createOSSpecificLabel()
{
    return new QLabel(tr("Unknown Edition"),appLogo);
}

#endif

QLayout * AboutHeader::createLayout()
{
    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addSpacing(40);
    mainLayout->addWidget(logoLabel);
    mainLayout->addStretch();
    mainLayout->addWidget(appLogo);
    mainLayout->addSpacing(106);
    mainLayout->setMargin(0);

    return mainLayout;
}

void AboutHeader::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.fillRect(rect(), Qt::white);

    QFrame::paintEvent(event);
}
