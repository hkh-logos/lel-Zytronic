/*
 *      Thread to handle uploading firmware to the controller. This expects
 *      to be passed a QTimer which will be set to update the UI with progress.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef UPLOADFIRMWARETHREAD_H
#define UPLOADFIRMWARETHREAD_H

#include <QThread>
#include <QtWidgets>


class UploadFirmwareThread : public QThread
{
    Q_OBJECT
public:
    explicit UploadFirmwareThread(QObject *parent = 0);
    void setFName(const QString name);
    void setProgressTimer(QTimer *timer);
    enum UploadState{CheckingFile, BAD_CRC, SwitchingToBootloader, Uploading, SwitchingToApplication, FAILED, Done};
    UploadState getState();
    void resetState();

signals:
    void reReadRequired();
    void pauseConnectionCheck(bool pause);

protected:
    void run();

private:
    bool checkForBootloader();
    bool checkForNormalConnection();

    QString fName;
    UploadState state;

};

#endif // UPLOADFIRMWARETHREAD_H
