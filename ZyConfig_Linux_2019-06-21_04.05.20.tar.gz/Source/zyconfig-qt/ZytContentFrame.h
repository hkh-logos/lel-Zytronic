/*
 *      Generic widget to act as container for pages of the configuration
 *      application. Each page is expected to have a content frame and
 *      a title.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */



#ifndef ZYTCONTENTFRAME_H
#define ZYTCONTENTFRAME_H

#include <QFrame>
#include "ZytAPIResult.h"

#define SML_FONT_SIZE       (7)
#define STD_BUTT_HEIGHT     (47)
#define STD_BUTT_WIDTH      (168)
#define STD_LABEL_WIDTH     (250)

/* Class for content of pages within the congifuration app
 * These can be used as sub tabs or as part of a ZytConfigPage
 */

class ZytContentFrame : public QFrame
{
    Q_OBJECT
public:
    explicit            ZytContentFrame(QWidget *parent = 0);
    virtual void        reReadValues();
    virtual void        showOverlay();
    virtual void        hideOverlay();

    static int          getAdvancedMode();
    static void         setAdvancedMode(int);

    static const char   *toCString(const QString *s);


signals:
    void APIResult      (ZytAPIResult::ResultState state);
    void APIResult      (QString message, ZytAPIResult::ResultState state);

protected:
    void                paintEvent(QPaintEvent *event);

private:
    static int          advancedMode;

};

#endif // ZYTCONFFRAME_H
