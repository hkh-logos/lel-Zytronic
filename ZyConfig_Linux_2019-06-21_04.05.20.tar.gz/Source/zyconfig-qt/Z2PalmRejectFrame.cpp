/*
 *      Content of the palm rejection tab.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */



#include "zytypes.h"
//#include "comms.h"
#include "zxymt.h"
// #include "zxy100.h"
#include "zxy110.h"
#include "services.h"

#include "Z2PalmRejectFrame.h"

#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

#define MAX_THRESHOLD       (500)
#define MAX_THRESHOLD_110   (100)
#define MIN_THRESHOLD       (0)
#define MIN_ALLOWED         (50)
#define MIN_ALLOWED_110     (10)

static bool writePending = false;

Z2PalmRejectFrame::Z2PalmRejectFrame(QWidget *parent) :
        ZytContentFrame(parent)
{
    int16_t PID;
    bool deviceConnected = zul_getDevicePID(&PID);
    devPID = PID;

    createWidgets();
    if ( deviceConnected && (!zul_isBLDevicePID(devPID)))
    {
        readFromController();
    }

    createConnections();
    setLayout(createLayout());

    feedbackTimer->start();
}

void Z2PalmRejectFrame::showOverlay()
{
    actSlider->showOverlay();
}

void Z2PalmRejectFrame::hideOverlay()
{
    actSlider->hideOverlay();
}

/**
 * Handle the setting of ZERO to present OFF on the label.
 * ALso, if reading > MAX, show with ** decorations to indicate oddity
 *       ... must have been set with sysFS or non-Zytronic config program.
 */
char *transVal(int val)
{
    static char str[7];
    if (val == 0)
    {
        strcpy(str,"off");  // FIXME - Translation ####
    }
    else if (val > MAX_THRESHOLD)
    {
        sprintf(str, "*%d*", val);
    }
    else
    {
        sprintf(str, "%d", val);
    }
    return str;
}

void Z2PalmRejectFrame::createWidgets()
{
    QFont font;
    threshTxtLabel  = new QLabel(
            tr("A hand resting on the sensor should not trigger touch events.\n\n") +

            tr("This page provides a manual override for the Palm Rejection, to cater for ") +
            tr("systems where the Basic Setup has not achieved the required operation.\n\n") +

            tr("This feature can be disabled by setting the Palm Rejection Threshold to 0.")
                                );


    threshTxtLabel->setWordWrap(true);
    threshTxtLabel->setMinimumWidth(500);
    // threshTxtLabel->setAlignment(Qt::AlignHCenter);

    guide           = new QPushButton(tr("&Suggested\nSettings"),this);

    maxThreshold = MAX_THRESHOLD;
    minAllowed   = MIN_ALLOWED;
    statusIndex  = ZXYMT_SI_PALM_REJECT_WEIGHT;
    configIndex  = ZXYMT_CI_PALM_REJECT_WEIGHT_LIMIT;
    if (devPID == ZXY110_PRODUCT_ID)
    {
        maxThreshold = MAX_THRESHOLD_110;
        minAllowed   = MIN_ALLOWED_110;
        statusIndex  = ZXY110_SI_PALM_REJECT_SIGNAL;
        configIndex  = ZXY110_CI_PALM_REJECT_THRESHOLD;
    }

    actSlider = new BigLabeledSlider(tr("Palm Rejection Threshold"), MIN_THRESHOLD, maxThreshold, 50, "&+", "&-",
                                     new QKeySequence("+"), new QKeySequence("-"), NULL, this);
    actSlider->LabelValTranslator(transVal);
    actSlider->enableReading(true);

    feedbackTimer = new QTimer(this);
    feedbackTimer->setInterval(200);

    statusLabel = new QLabel(this);
    statusLabel->setText(tr("Controller Status") + ": ----");
    statusLabel->setAlignment(Qt::AlignRight);
    font = statusLabel->font();
    font.setPointSize(SML_FONT_SIZE);
    statusLabel->setFont(font);
    statusLabel->setVisible(getAdvancedMode() == 0 ? false : true);

    touchCountLabel = new QLabel(this);
    touchCountLabel->setText("Active Touch Count: ----");
    touchCountLabel->setAlignment(Qt::AlignLeft);
    touchCountLabel->setFont(font);
    touchCountLabel->setVisible(getAdvancedMode() == 0 ? false : true);

    writeThreshChange = new QTimer(this);
    writeThreshChange->setInterval(500);
    writeThreshChange->setSingleShot(true);
}


QLayout * Z2PalmRejectFrame::createLayout()
{
    QVBoxLayout *main_Layout = new QVBoxLayout;
    QVBoxLayout *threshLayout = new QVBoxLayout;
    QHBoxLayout *sliderWrapLayout = new QHBoxLayout;
    QHBoxLayout *suggestionLayout = new QHBoxLayout;
    QHBoxLayout *threshWrapLayout = new QHBoxLayout;

    threshLayout->addWidget(actSlider);

    sliderWrapLayout->addStretch();
    sliderWrapLayout->addLayout(threshLayout);
    sliderWrapLayout->addStretch();

    threshWrapLayout->addStretch();
    threshWrapLayout->addWidget(threshTxtLabel);
    threshWrapLayout->addStretch();

    suggestionLayout->addWidget(guide);
    suggestionLayout->setAlignment(guide, Qt::AlignRight);
    suggestionLayout->setContentsMargins(0,0,20,0);  //   (int left, int top, int right, int bottom)

    main_Layout->addStretch();
    main_Layout->addLayout(threshWrapLayout);
    main_Layout->addStretch();
    main_Layout->addLayout(sliderWrapLayout);
    main_Layout->addStretch();
    main_Layout->addLayout(suggestionLayout);
    main_Layout->addStretch();

    main_Layout->addWidget(touchCountLabel);
    main_Layout->addWidget(statusLabel);

    return main_Layout;
}

void Z2PalmRejectFrame::readFromController()
{
    uint16_t threshold;

    if (writePending) return;
    zul_getConfigParamByID(configIndex, &threshold);

    if ( threshold != actSlider->getValue() )
    {
        actSlider->setValue(threshold);
    }
}

void Z2PalmRejectFrame::showHelp()
{
    QMessageBox helpBox;
    uint16_t configVal;
    uint16_t numWires;

    ZXY_sensorSize sz;
    zul_getSensorSize(&sz);
    numWires = sz.xWires + sz.yWires;

    QString over10Text = QString( "<p>" +
            tr("It is recommended that this is set to 0 if the maximum number of touches has been set above 10.") + "</p>" );

    helpBox.setWindowTitle(tr("Suggested Settings"));
    QString introText;
    if (devPID == ZXY110_PRODUCT_ID)
    {
        zul_getConfigParamByID(ZXY110_CI_GLASS_THICKNESS, &configVal);
        introText = QString(
            "<p>"+tr("The table below provides suggested settings for the Palm Rejection Threshold based on the glass sensor size ") +
            tr("and the Coarse Sensitivity. Currently, coarse sensitivity = ") + QString::number(configVal) + ".</p>" );
    }
    else
    {
        zul_getConfigParamByID(ZXYMT_CI_UPPER_THRESHOLD, &configVal);
        introText = QString(
            "<p>"+tr("The table below provides suggested settings for the Palm Rejection Threshold based on the glass sensor size ") +
            tr("and the Touch Threshold. Currently touch threshold = ") + QString::number(configVal) + ".</p>"
            );
    }

    if (devPID == ZXY110_PRODUCT_ID)
    {
        over10Text = QString( "" );
        introText.append( "<br><center><table cellpadding=\"5\">");
        switch (numWires)
        {
            case 32:
                introText.append(
                "<tr>"
                    "<th align=\"right\">Glass</th>" "<th align=\"right\">CS</th>"
                      "<th align=\"right\">   7\"</th><th align=\"right\">  17\"</th>"
                "</tr>"

                "<tr>"
                    "<th align=\"left\">4mm</th> <td align=\"left\">2</td>"
                      "<td > 70 </td><td > 50  </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\">8mm</th> <td align=\"left\">4</td>"
                      "<td > 50 </td><td > 65  </td>"
                "</tr>"

                        );
                break;
            case 64:
                introText.append(
                "<tr>"
                    "<th align=\"right\">Glass</th>" "<th align=\"right\">CS</th>"
                      "<th align=\"right\">  22\"</th><th align=\"right\">  32\"</th><th align=\"right\">  42\"</th>"
                "</tr>"

                "<tr>"
                    "<th align=\"left\">4mm</th> <td align=\"left\">2</td>"
                      "<td > 40 </td><td > 40  </td><td > 35  </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\">8mm</th> <td align=\"left\">4</td>"
                      "<td > 40 </td><td > 45  </td><td > 45  </td>"
                "</tr>"

                        );
                break;
        }
        introText.append( "</table></center>");
    }


    if (devPID == ZXY150_PRODUCT_ID)
    {
        introText.append(
            "<br><center><table cellpadding=\"5\">"
                "<tr>"
                    "<th align=\"right\"></th>"
                    "<th align=\"right\">   7 \"</th><th align=\"right\">  10 \"</th><th align=\"right\">  12 \"</th><th align=\"right\">  15 \"</th><th align=\"right\">  19 \"</th><th align=\"right\">  21 \"</th>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\" width=\"90\">"+tr("Touch")+"<br>"+tr("Threshold")+"</th> <td > </td><td > </td><td> </td><td> </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\">50-75 </th>"
                    "<td align=\"right\">  OFF  </td><td align=\"right\">  OFF  </td><td align=\"right\">  OFF  </td><td align=\"right\">  OFF  </td><td align=\"right\">  OFF  </td><td align=\"right\">  OFF </td>"
                "</tr>"

                "<tr>"
                    "<th align=\"left\">  75-100  </th>"
                    "<td align=\"right\">  300  </td><td align=\"right\">  290  </td><td align=\"right\">  280  </td><td align=\"right\">  240  </td><td align=\"right\">  160  </td><td align=\"right\">  160 </td>"
                "</tr>"

                "<tr>"
                    "<th align=\"left\">  100-125  </th>"
                    "<td align=\"right\">  270  </td><td align=\"right\">  220  </td><td align=\"right\">  200  </td><td align=\"right\">  160  </td><td align=\"right\">  140  </td><td align=\"right\">  140 </td>"
                "</tr>"

                "<tr>"
                    "<th align=\"left\">  125-150  </th>"
                    "<td align=\"right\">  240  </td><td align=\"right\">  200  </td><td align=\"right\">  180  </td><td align=\"right\">  150  </td><td align=\"right\">  130  </td><td align=\"right\">  130 </td>"
                "</tr>"

                "<tr>"
                    "<th align=\"left\">  150-200  </th>"
                    "<td align=\"right\">  210  </td><td align=\"right\">  180  </td><td align=\"right\">  170  </td><td align=\"right\">  140  </td><td align=\"right\">  120  </td><td align=\"right\">  120 </td>"
                "</tr>"

                "<tr>"
                    "<th align=\"left\">  200-250  </th>"
                    "<td align=\"right\">  180  </td><td align=\"right\">  170  </td><td align=\"right\">  160  </td><td align=\"right\">  130  </td><td align=\"right\">  110  </td><td align=\"right\">  110 </td>"
                "</tr>"

                "<tr>"
                    "<th align=\"left\">  250-300  </th>"
                    "<td align=\"right\">  170  </td><td align=\"right\">  160  </td><td align=\"right\">  150  </td><td align=\"right\">  130  </td><td align=\"right\">  110  </td><td align=\"right\">  110 </td>"
                "</tr>"

            "</table></center>"
                        );

    }

    if (devPID == ZXY200_PRODUCT_ID)
    {
        introText.append(
            "<br><center><table cellpadding=\"2\">"
                "<tr>"
                    "<th align=\"right\"></th><th>22\"</th><th>32\"</th><th>46\"</th><th>55\"</th>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\" width=\"90\">"+tr("Touch")+"<br>"+tr("Threshold")+"</th> <td > </td><td > </td><td> </td><td> </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\">50-75 </th>  <td align=\"right\"> 375 </td><td align=\"right\"> 315 </td><td align=\"right\"> 225 </td><td align=\"right\"> 200 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\">  75-100 </th>  <td align=\"right\"> 285 </td><td align=\"right\"> 280 </td><td align=\"right\"> 210 </td><td align=\"right\"> 160 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 100-125 </th>  <td align=\"right\"> 255 </td><td align=\"right\"> 245 </td><td align=\"right\"> 185 </td><td align=\"right\"> 150 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 125-150 </th>  <td align=\"right\"> 205 </td><td align=\"right\"> 225 </td><td align=\"right\"> 155 </td><td align=\"right\"> 120 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 150-200 </th>  <td align=\"right\"> 180 </td><td align=\"right\"> 190 </td><td align=\"right\"> 150 </td><td align=\"right\"> 100 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 200-250 </th>  <td align=\"right\"> 135 </td><td align=\"right\"> 155 </td><td align=\"right\"> 130 </td><td align=\"right\">  90 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 250-300 </th>  <td align=\"right\"> 130 </td><td align=\"right\"> 125 </td><td align=\"right\"> 125 </td><td align=\"right\">  85 </td>"
                "</tr>"

            "</table></center>"
                        );

    }

    if (devPID == ZXY300_PRODUCT_ID)
    {
        introText.append(
            "<br><center><table cellpadding=\"2\">"
                "<tr>"
                    "<th align=\"right\"></th><th>55\"</th><th>65\"</th><th>72\"</th><th>84\"</th>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\" width=\"90\">"+tr("Touch")+"<br>"+tr("Threshold")+"</th> <td > </td><td > </td><td> </td><td> </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\">50-75 </th>  <td align=\"right\"> 450 </td><td align=\"right\"> 315 </td><td align=\"right\"> 300 </td><td align=\"right\"> 240 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\">  75-100 </th>  <td align=\"right\"> 410 </td><td align=\"right\"> 280 </td><td align=\"right\"> 240 </td><td align=\"right\"> 195 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 100-125 </th>  <td align=\"right\"> 310 </td><td align=\"right\"> 245 </td><td align=\"right\"> 210 </td><td align=\"right\"> 180 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 125-150 </th>  <td align=\"right\"> 280 </td><td align=\"right\"> 225 </td><td align=\"right\"> 155 </td><td align=\"right\"> 155 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 150-200 </th>  <td align=\"right\"> 220 </td><td align=\"right\"> 190 </td><td align=\"right\"> 145 </td><td align=\"right\"> 145 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 200-250 </th>  <td align=\"right\"> 180 </td><td align=\"right\"> 155 </td><td align=\"right\"> 105 </td><td align=\"right\"> 105 </td>"
                "</tr>"
                "<tr>"
                    "<th align=\"left\"> 250-300 </th>  <td align=\"right\"> 145 </td><td align=\"right\"> 125 </td><td align=\"right\">  95 </td><td align=\"right\">  90 </td>"
                "</tr>"

            "</table></center>"
                        );
    }

    if ( zul_isZXY500AppPID(&devPID) )
    {
        switch (numWires)
        {
            case 64:
                introText.append(
                                "<br><center><table cellpadding=\"2\">"
                                "<tr>"
                                    "<th align=\"right\"></th><th>10\"</th><th>15\"</th><th>22\"</th>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\" width=\"90\">"+tr("Touch")+"<br>"+tr("Threshold")+"</th> <td > </td><td > </td><td> </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\">  50-75 </th>   <td align=\"right\"> 325 </td><td align=\"right\"> 250 </td><td align=\"right\"> 225 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\">  75-100 </th>  <td align=\"right\"> 250 </td><td align=\"right\"> 175 </td><td align=\"right\"> 175 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 100-125 </th>  <td align=\"right\"> 250 </td><td align=\"right\"> 150 </td><td align=\"right\"> 150 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 125-150 </th>  <td align=\"right\"> 225 </td><td align=\"right\"> 125 </td><td align=\"right\"> 125 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 150-200 </th>  <td align=\"right\"> 125 </td><td align=\"right\"> 100 </td><td align=\"right\">  75 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 200-250 </th>  <td align=\"right\"> 125 </td><td align=\"right\">  75 </td><td align=\"right\">  50 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 250-300 </th>  <td align=\"right\"> 100 </td><td align=\"right\">  50 </td><td align=\"right\">  25 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 300-400 </th>  <td align=\"right\"> 100 </td><td align=\"right\">  50 </td><td align=\"right\">  25 </td>"
                                "</tr>"
                            "</table></center>"
                            );
                break;
            case 128:
                over10Text.replace("10", "20");
                introText.append(
                                "<br><center><table cellpadding=\"2\">"
                                "<tr>"
                                    "<th align=\"right\"></th><th>22\"</th><th>32\"</th><th>55\"</th>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\" width=\"90\">"+tr("Touch")+"<br>"+tr("Threshold")+"</th> <td > </td><td > </td><td> </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\">  50-75 </th>   <td align=\"right\"> 400 </td><td align=\"right\"> 300 </td><td align=\"right\"> 150 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\">  75-100 </th>  <td align=\"right\"> 350 </td><td align=\"right\"> 275 </td><td align=\"right\"> 125 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 100-125 </th>  <td align=\"right\"> 250 </td><td align=\"right\"> 200 </td><td align=\"right\"> 125 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 125-150 </th>  <td align=\"right\"> 175 </td><td align=\"right\"> 150 </td><td align=\"right\">  75 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 150-200 </th>  <td align=\"right\"> 175 </td><td align=\"right\"> 125 </td><td align=\"right\">  75 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 200-250 </th>  <td align=\"right\"> 150 </td><td align=\"right\"> 100 </td><td align=\"right\">  50 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 250-300 </th>  <td align=\"right\"> 125 </td><td align=\"right\">  75 </td><td align=\"right\">  25 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 300-400 </th>  <td align=\"right\"> 125 </td><td align=\"right\">  75 </td><td align=\"right\">  25 </td>"
                                "</tr>"
                            "</table></center>"
                            );
                break;

            case 256:
                over10Text.replace("10", "40");
                introText.append(
                                "<br><center><table cellpadding=\"2\">"
                                "<tr>"
                                    "<th align=\"right\"></th><th>55\"</th><th>72\"</th><th>84\"</th>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\" width=\"90\">"+tr("Touch")+"<br>"+tr("Threshold")+"</th> <td > </td><td > </td><td> </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\">  50-75 </th>   <td align=\"right\"> 250 </td><td align=\"right\"> 200 </td><td align=\"right\"> 125 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\">  75-100 </th>  <td align=\"right\"> 150 </td><td align=\"right\"> 150 </td><td align=\"right\"> 125 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 100-125 </th>  <td align=\"right\"> 150 </td><td align=\"right\"> 125 </td><td align=\"right\"> 100 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 125-150 </th>  <td align=\"right\"> 150 </td><td align=\"right\"> 125 </td><td align=\"right\"> 100 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 150-200 </th>  <td align=\"right\"> 125 </td><td align=\"right\"> 100 </td><td align=\"right\">  75 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 200-250 </th>  <td align=\"right\">  75 </td><td align=\"right\">  75 </td><td align=\"right\">  50 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 250-300 </th>  <td align=\"right\">  50 </td><td align=\"right\">  50 </td><td align=\"right\">  25 </td>"
                                "</tr>"
                                "<tr>"
                                    "<th align=\"left\"> 300-400 </th>  <td align=\"right\">  50 </td><td align=\"right\">  50 </td><td align=\"right\">  25 </td>"
                                "</tr>"
                            "</table></center>"
                            );
                break;
        }
    }

    introText.append( over10Text );
    introText.append( + "<p>" +
                        tr("NOTE:  These values are only a guide and may need to be optimised for your system.")
                    );

    helpBox.setTextFormat(Qt::RichText);
    helpBox.setText(introText);

    helpBox.setIcon(QMessageBox::Information);
    helpBox.setStandardButtons(QMessageBox::Ok);
    helpBox.setModal(true);
    //remove the close button from the dialog if there is one
    Qt::WindowFlags wFlags = helpBox.windowFlags();

    if(Qt::WindowCloseButtonHint == (wFlags & Qt::WindowCloseButtonHint))
    {
        wFlags = wFlags ^ Qt::WindowCloseButtonHint;
        helpBox.setWindowFlags(wFlags);
    }
    helpBox.setDefaultButton(QMessageBox::Ok);

    helpBox.exec();
}


void Z2PalmRejectFrame::createConnections()
{
    QObject::connect(actSlider, SIGNAL(valueChanged(int)),
                        this, SLOT(actValueChange(int)));

    QObject::connect(feedbackTimer, SIGNAL(timeout(void)),
                        this, SLOT(sampleTouch()));

    QObject::connect(writeThreshChange, SIGNAL(timeout(void)),
                        this, SLOT(changeThresholds()));

    QObject::connect(guide, SIGNAL(clicked(void)),
                     this, SLOT(showHelp()));
}

void Z2PalmRejectFrame::actValueChange(int value)
{
    writeThreshChange->start();
    writePending = true;
    value++;
}

void Z2PalmRejectFrame::changeThresholds()
{
    emit APIResult(ZytAPIResult::Progress);

    int         v = actSlider->getValue();

    if (actSlider->getValue() != v)
    {
        actSlider->setValue(v);
    }

    if ( SUCCESS != zul_setConfigParamByID( configIndex, v ) )
    {
        emit APIResult(ZytAPIResult::Failure);
        reReadValues();
    }
    else
    {
        emit APIResult(ZytAPIResult::Success);
        writePending = false;
    }
}

void Z2PalmRejectFrame::sampleTouch()
{
    static int  counter = 0;
    uint16_t    palmReading, status, touchCount;
    char        buffer[40];

    if (!isVisible())
    {
        return;
    }


    statusLabel->setVisible(getAdvancedMode() == 0 ? false : true);
    touchCountLabel->setVisible(statusLabel->isVisible());

    if (SUCCESS != zul_getStatusByID(statusIndex, &palmReading))
    {
        return;
    }

    if (SUCCESS == zul_getStatusByID(ZXYMT_SI_STATUS_ACTIVE, &status))
    {
        sprintf(buffer, "Controller Status: %04X", status);
        statusLabel->setText(buffer);
    }
    else
    {
        statusLabel->setText("Controller Status: ----");
    }

    if (SUCCESS == zul_getStatusByID( ZXYMT_SI_NUM_LIVE_TOUCHES, &touchCount))
    {
        sprintf(buffer, "Active Touch Count: %04X", touchCount);
        touchCountLabel->setText(buffer);
    }
    else
    {
        touchCountLabel->setText("Active Touch Count: ----");
    }

    if (palmReading>MAX_THRESHOLD)
        palmReading = MAX_THRESHOLD;

    actSlider->setReading((int)palmReading);

    if ((counter++ % 25) == 0) reReadValues();
}

void Z2PalmRejectFrame::reReadValues()
{
    /* Prevent writing back to controller when changing
     * GUI widget values by disconnecting all slots
     * from this object */

    actSlider->disconnect(this);
    writeThreshChange->disconnect(this);
    feedbackTimer->disconnect(this);
    guide->disconnect(this);

    readFromController();

    /* re create all the connections */
    createConnections();
}

void Z2PalmRejectFrame::showEvent(QShowEvent *Event)
{
    if(QEvent::Show == Event->type())
    {
        //pollingTimer->start();
    }

    ZytContentFrame::showEvent(Event);
}

void Z2PalmRejectFrame::hideEvent(QHideEvent *Event)
{
    if(QEvent::Hide == Event->type())
    {
        //pollingTimer->stop();
    }

    ZytContentFrame::hideEvent(Event);
}
