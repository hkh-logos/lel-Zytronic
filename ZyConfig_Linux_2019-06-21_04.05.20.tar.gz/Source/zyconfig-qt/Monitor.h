// class to hold a monitor's data

#ifndef MONITOR_H
#define MONITOR_H

#include <QRect>
#include "sysdata.h"

class Monitor
{
    public:
        Monitor     ( void );
        Monitor     ( const char *mName, Location mLocation, Size2d mSize, XMonitorOrientation mOrientation );

        void                    setPrimary      (void);
        const char              *getName        (bool decorate);
        const char              *getParams      (void);
        Location                getLocation     (void);
        Size2d                  getSize         (void);
        XMonitorOrientation     getOrientation  (void);
        void                    getRect         (QRect *r);
        void                    setRect         (QRect *r, QString name);

        bool                    isValid         (void);

    private:
        bool                    primary;
        char                    monName [12];
        char                    decName [12];  // provides decorations (like primary)
        char                    paramStr[30];  // e.g. 1920x1080+400+2400
        Location                location;
        Size2d                  size;
        XMonitorOrientation     orientation;
        bool                    valid;
} ;

#endif //  MONITOR_H
