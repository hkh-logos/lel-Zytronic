/*
 * Integration Test class: This code is intended to hold all the
 * presentation elements of a test, to simplify the test management
 * in the TBC#### test execution code.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "IntegrationTest.h"

int     IntegrationTest::testCount = 0;
int     IntegrationTest::yBase = Y_INIT;

IntegrationTest::IntegrationTest(const QString &s, QWidget *parent)
{
    debugDetail = "";

    gb_Panel = new QGroupBox("", parent);  // no title set for the panel!
    yLocation = yBase + testCount * (fieldHeight + 9);
    testCount ++ ;
    gb_Panel->setGeometry(5,   yLocation, 920, fieldHeight + 4);
    gb_Panel->setStyleSheet( "QGroupBox { border: 0px solid white; padding: 0px}" );

    name    = new QLabel(s,      (QWidget*)gb_Panel);
    name    ->setGeometry(5,   5, 180, 30);

    pass    = new QLabel("::: ", (QWidget*)gb_Panel);
    pass    ->setGeometry(210, 5,  90, 30);

    comment = new QLabel("... ", (QWidget*)gb_Panel);
    comment ->setWordWrap(true);
    comment ->setGeometry(330, 5, 400, 36);

    debugDetail = "";
}

void  IntegrationTest::setLargeFonts(bool large)
{
    if (large)
    {
        fontSz1 = "18px;}";
        fontSz2 = "22px;}";
        pass    ->setGeometry(210, 5, 130, 30);
        comment ->setGeometry(370, 5, 400, 36);
    }
    else
    {
        fontSz1 = "12px;}";
        fontSz2 = "14px;}";
    }
    name    ->setStyleSheet("QLabel { color : blue; font : bold " + fontSz1);
    comment ->setStyleSheet("QLabel { color : blue; font : " + fontSz1);
}

IntegrationTest::~IntegrationTest()
{
    delete name;
    delete pass;
    delete comment;
    delete gb_Panel;
}

QString IntegrationTest::getName(void)
{
    return (name->text());
}

void IntegrationTest::setDebugDetail(const QString &s)
{
    debugDetail = s;
}

void IntegrationTest::addDebugDetail(const QString &s)
{
    debugDetail += s;
}

QString IntegrationTest::getDebugDetail(void)
{
    return debugDetail;
}

void IntegrationTest::setTestPass(const QString &s)
{
    pass->setText(s);
    if (s.contains("PASS"))
        pass->setStyleSheet("QLabel { color : green; font : bold " + fontSz2);
    else if (s.contains("FAIL"))
        pass->setStyleSheet("QLabel { color : red; font : bold " + fontSz2);
    else
        pass->setStyleSheet("QLabel { color : blue; font : bold " + fontSz2);  // e.g. "WARNING"
}

void IntegrationTest::setTestComment(const QString &s)
{
    comment->setText(s);
}

void IntegrationTest::setLocation(QPoint topLeft)
{
    int w,h;
    w=gb_Panel->width();
    h=gb_Panel->height();
    gb_Panel->setGeometry(topLeft.x(), topLeft.y(), w,h);
}


QString IntegrationTest::getReportText(void)
{
    QString report = name->text();

    while (report.size() < 24)
        report.append(' ');

    report += pass->text();

    while (report.size() < 34)
        report.append(' ');

    report += comment->text();

    if (debugDetail.size() > 0)
    {
        report += debugDetail + "\n";
    }
    else
    {
        report += "\n";
    }

    return report ;
}

void IntegrationTest::appendDebugDetail2Comment(void)
{
    QString t = comment->text();
    t += debugDetail;
    clearDebugDetail();
    comment->setText(t);
}


void IntegrationTest::clearDebugDetail(void)
{
    debugDetail = QString("");
}


void IntegrationTest::appendDebugDetail(QString s)
{
    debugDetail += s;
}
