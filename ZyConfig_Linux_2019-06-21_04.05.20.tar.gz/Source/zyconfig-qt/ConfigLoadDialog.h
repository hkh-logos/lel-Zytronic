/*
 *      Load the Configuration Parameters from a ZYS file to the controller.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef CONFIGLOADDIALOG_H
#define CONFIGLOADDIALOG_H

#include <QDialog>
#include "ZytAPIResult.h"

class ConfigLoadDialog : public QDialog
{
    Q_OBJECT
public:
    ConfigLoadDialog(QWidget *parent = 0);
    void            setLocation(QPoint loc);
    void            setFileName(const QString *name);
    void            setForce(const QString *name);

signals:
    void APIResult(ZytAPIResult::ResultState state);

public slots:
    int exec();

protected:

private:
    void            createWidgets(void);
    QLayout *       createLayout();

    QLabel          *textLabel;
    QProgressBar    *progressBar;
    QString         fileName;
    bool            forceLoad;
    QPoint          location;
};

#endif // CONFIGLOADDIALOG_H
