/*
 *      Sub class of QTabWidget to contain the configuration tabs
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <QtWidgets>

#include "ManualSetup.h"

#include "protocol.h"
#include "debug.h"
#include "services.h"
//#include "comms.h"
#include "zytypes.h"

ManualSetup::ManualSetup(QWidget *parent) :
        QTabWidget(parent)
{
    int16_t PID;
    zul_getDevicePID(&PID);
    devPID = PID;

    switch (devPID)
    {
        case ZXY100_PRODUCT_ID:
            z2SenseFrame      = NULL;
            z2PalmRejectFrame = NULL;

            controllerOptions   = new ControllerOptionsFrame();
            axisOptions         = new AxisOptionsFrame();
            senseFrame          = new SenseAndThreshFrame(this);
            testSensor          = new TestSensorFrame();

            addTab(controllerOptions,   tr("Controller Options"));
            addTab(senseFrame,          tr("Sensitivity"));
            addTab(axisOptions,         tr("Axis Options"));
            addTab(testSensor,          tr("Test Sensor"));
            break;

        case ZXY110_PRODUCT_ID:
            z2SenseFrame      = NULL;
            z2PalmRejectFrame = new Z2PalmRejectFrame();
            //z2PalmRejectFrame = NULL;

            controllerOptions = new ControllerOptionsFrame();
            axisOptions       = new AxisOptionsFrame();
            senseFrame        = new SenseAndThreshFrame(this);
            testSensor        = new TestSensorFrame();

            addTab(controllerOptions,   tr("Controller Options"));
            addTab(senseFrame,          tr("Sensitivity"));
            addTab(axisOptions,         tr("Axis Options"));
            addTab(z2PalmRejectFrame,   tr("Palm Rejection"));
            addTab(testSensor,          tr("Test Sensor"));
            break;

        default:
        // Multi Touch { ZXY200, ZXY300, ..? }
            controllerOptions = new ControllerOptionsFrame();
            z2SenseFrame      = new Z2SenseFrame();
            z2PalmRejectFrame = new Z2PalmRejectFrame();
            axisOptions       = new AxisOptionsFrame();
            testSensor        = new TestSensorFrame();

            senseFrame = NULL;

            addTab(controllerOptions,   tr("Controller Options"));
            addTab(z2SenseFrame,        tr("Sensitivity"));
            addTab(axisOptions,         tr("Axis Options"));
            addTab(z2PalmRejectFrame,   tr("Palm Rejection"));
            addTab(testSensor,          tr("Test Sensor"));
            break;
    }

    zxy100Dat = NULL;
    createConnections();
}

void ManualSetup::passZxy100Data(Zxy100Data * z100d)
{
    zxy100Dat = z100d;
    if (senseFrame != NULL)
    {
        senseFrame->passZxy100Data(zxy100Dat);
    }
}

void ManualSetup::showOverlay()
{
    switch(this->currentIndex())
    {
        case 0:
            if (z2SenseFrame)
            {
                z2SenseFrame->showOverlay();
            }
        break;

        case 1:
            if (z2PalmRejectFrame)
            {
                z2PalmRejectFrame->showOverlay();
            }
        break;

        case 2:
            if (axisOptions)
            {
                axisOptions->showOverlay();
            }
        break;

        case 3:
            if (controllerOptions)
            {
                controllerOptions->showOverlay();
            }
        break;
    }
}

void ManualSetup::hideOverlay()
{
    switch(this->currentIndex())
    {
        case 0:
            if (z2SenseFrame)
            {
                z2SenseFrame->hideOverlay();
            }
        break;

        case 1:
            if (senseFrame)
            {
                senseFrame->hideOverlay();
            }
            if (z2PalmRejectFrame)
            {
                z2PalmRejectFrame->hideOverlay();
            }
        break;

        case 2:
            if (axisOptions)
            {
                axisOptions->hideOverlay();
            }
        break;

        case 3:
            if (controllerOptions)
            {
                controllerOptions->hideOverlay();
            }
        break;
    }
}

void ManualSetup::createConnections()
{
    if (senseFrame)
    {
        QObject::connect(senseFrame, SIGNAL(thresholdsChanged()),
                               this, SIGNAL(thresholdsChanged()));
        QObject::connect(senseFrame, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                               this, SIGNAL(APIResult(ZytAPIResult::ResultState)));
    }

    if (z2SenseFrame)
    {
        QObject::connect(z2SenseFrame, SIGNAL(thresholdsChanged()),
                                 this, SIGNAL(thresholdsChanged()));
        QObject::connect(z2SenseFrame, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                                 this, SIGNAL(APIResult(ZytAPIResult::ResultState)));
    }

    if (z2PalmRejectFrame)
    {
        QObject::connect(z2PalmRejectFrame, SIGNAL(thresholdsChanged()),
                                      this, SIGNAL(thresholdsChanged()));
        QObject::connect(z2PalmRejectFrame, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                                      this, SIGNAL(APIResult(ZytAPIResult::ResultState)));
    }


    if (axisOptions)
    {
        QObject::connect(axisOptions, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                                this, SIGNAL(APIResult(ZytAPIResult::ResultState)));
    }


    if (controllerOptions)
    {
        QObject::connect(controllerOptions, SIGNAL(reReadAxesReq()),
                                  this, SLOT(reReadValues()));

        QObject::connect(controllerOptions, SIGNAL(reReadRequired()),
                                  this, SLOT(reReadValues()));

        QObject::connect(controllerOptions, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                                  this, SIGNAL(APIResult(ZytAPIResult::ResultState)));
    }

    QObject::connect(this, SIGNAL(currentChanged(int)),
                     this, SLOT  (indexChange(int)));
}

void ManualSetup::reReadValues()
{
    if (senseFrame)
    {
        senseFrame->reReadValues();
    }
    if (z2SenseFrame)
    {
        z2SenseFrame->reReadValues();
    }
    if (z2PalmRejectFrame)
    {
        z2PalmRejectFrame->reReadValues();
    }
    if (controllerOptions)
    {
        controllerOptions->reReadValues();
    }
    reReadAxes();
}

void ManualSetup::reReadAxes()
{
    if (axisOptions)
    {
        axisOptions->reReadValues();
    }
}


void ManualSetup::showEvent(QShowEvent * event)
{
    if(QEvent::Show == event->type())
    {
        emit showPrevNextButtons(false);     // was true, but we removed them
        indexChange(currentIndex());
    }

    QTabWidget::showEvent(event);
}

void ManualSetup::hideEvent(QHideEvent * event)
{
    if(QEvent::Hide == event->type())
    {
        emit showPrevNextButtons(false);
    }

    QTabWidget::hideEvent(event);
}

void ManualSetup::indexChange(int index)
{
    if(0 >= index)
    {
        emit enablePrevNextButtons(false,true);
    }
    else if ((this->count() - 1) <= index)
    {
        emit enablePrevNextButtons(true, false);
    }
    else
    {
        emit enablePrevNextButtons(true,true);
    }
}

void ManualSetup::setLEDPoll(bool *inhibit)
{
    // remember the address of the flag
    if (testSensor != NULL)
    {
        testSensor->setLEDPoll( inhibit );
    }
}
