/*
 *      Sub class of QTabWidget to contain the configuration tabs
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef MANUALSETUP_H
#define MANUALSETUP_H

#include <QWidget>
#include <QtWidgets>

#include "ZytAPIResult.h"

#include "SenseAndThreshFrame.h"
#include "Z2SenseFrame.h"
#include "ControllerOptionsFrame.h"
#include "Z2PalmRejectFrame.h"
#include "AxisOptionsFrame.h"
#include "TestSensorFrame.h"
#include "Zxy100Data.h"

class ManualSetup : public QTabWidget
{
    Q_OBJECT

public:
    ManualSetup                 (QWidget *parent = 0);
    void showOverlay            (void);
    void hideOverlay            (void);
    void passZxy100Data         (Zxy100Data * z100d);

public slots:
    void reReadValues           (void);
    void reReadAxes             (void);
    void setLEDPoll             (bool *inhibit);

protected:
    virtual void showEvent      (QShowEvent * event);
    virtual void hideEvent      (QHideEvent * event);

signals:
    void reReadRequired         (void);
    void thresholdsChanged      (void);
    void APIResult              (ZytAPIResult::ResultState state);
    void showPrevNextButtons    (bool show);
    void enablePrevNextButtons  (bool prev, bool next);

private slots:
    void indexChange            (int index);


private:
    void createConnections      (void);

    SenseAndThreshFrame         *senseFrame;
    Z2SenseFrame                *z2SenseFrame;
    Z2PalmRejectFrame           *z2PalmRejectFrame;
    AxisOptionsFrame            *axisOptions;
    ControllerOptionsFrame      *controllerOptions;
    TestSensorFrame             *testSensor;

    Zxy100Data                  *zxy100Dat;
    int16_t                     devPID;
};

#endif
