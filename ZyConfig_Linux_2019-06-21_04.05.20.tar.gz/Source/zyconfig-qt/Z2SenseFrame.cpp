/*
 *      Content of the sensitivity and thresholds tab in the
 *      configuration tab (multitouch).
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "zytypes.h"
#include "comms.h"
#include "zxymt.h"
#include "zxy100.h"
#include "zxy110.h"
#include "services.h"

#include "Z2SenseFrame.h"

#define MAX_THRESHOLD   (600)
#define MIN_THRESHOLD   (1)
#define MIN_ALLOWED     (25)

static bool writePending = false;

Z2SenseFrame::Z2SenseFrame(QWidget *parent) :
        ZytContentFrame(parent)
{
    int16_t PID;
    bool deviceConnected = zul_getDevicePID(&PID);
    devPID = PID;

    createWidgets();
    if ( deviceConnected && (!zul_isBLDevicePID(devPID)))
    {
        readFromController();
        createConnections();
        setLayout(createLayout());

        feedbackTimer->start();
    }
}

void Z2SenseFrame::showOverlay()
{
    actSlider->showOverlay();
}

void Z2SenseFrame::hideOverlay()
{
    actSlider->hideOverlay();
}

void Z2SenseFrame::createWidgets()
{
    QFont font;

    threshTxtLabel = new QLabel( tr("This page provides a manual control for the Touch Sensitivity, to optimize\r\n") +
                                  "\r\n" +
                                 tr("systems where the default settings do not achieve the required operation.") );
    /* windows text
        "This page provides a manual override for the touch sensitivity, to cater for "
        "systems where the Basic Setup has not achieved the required operation.\n\n"  */

    threshTxtLabel->setWordWrap(true);
    threshTxtLabel->setMinimumWidth(500);
    threshTxtLabel->setAlignment(Qt::AlignHCenter);

    guide = new QPushButton(tr("&Suggested\nSettings"),this);

    actSlider = new BigLabeledSlider(tr("Touch Threshold"), MIN_THRESHOLD, MAX_THRESHOLD, 25, "&+", "&-",
                                     new QKeySequence("+"), new QKeySequence("-"), NULL, this);

    actSlider->enableReading(true);

    feedbackTimer = new QTimer(this);
    feedbackTimer->setInterval(500);

    statusLabel = new QLabel(this);
    statusLabel->setText("Controller Status: ----");
    statusLabel->setAlignment(Qt::AlignRight);
    font = statusLabel->font();
    font.setPointSize(SML_FONT_SIZE);
    //font.setFamily("Courier New");
    //font.setStyleHint(QFont::TypeWriter); //Monospace);
    statusLabel->setFont(font);
    statusLabel->setVisible(true); // (getAdvancedMode() == 0 ? false : true);

    touchCountLabel = new QLabel(this);
    touchCountLabel->setText("Active Touch Count: ----");
    touchCountLabel->setAlignment(Qt::AlignLeft);
    touchCountLabel->setFont(font);
    touchCountLabel->setVisible(true); // (getAdvancedMode() == 0 ? false : true);

    writeThreshChange = new QTimer(this);
    writeThreshChange->setInterval(500);
    writeThreshChange->setSingleShot(true);
}


QLayout * Z2SenseFrame::createLayout()
{
    QVBoxLayout *main_Layout = new QVBoxLayout;
    QVBoxLayout *threshLayout = new QVBoxLayout;
    QHBoxLayout *sliderWrapLayout = new QHBoxLayout;
    QHBoxLayout *suggestionLayout = new QHBoxLayout;
    QHBoxLayout *threshWrapLayout = new QHBoxLayout;

    threshLayout->addWidget(actSlider);

    sliderWrapLayout->addStretch();
    sliderWrapLayout->addLayout(threshLayout);
    sliderWrapLayout->addStretch();

    threshWrapLayout->addStretch();
    threshWrapLayout->addWidget(threshTxtLabel);
    threshWrapLayout->addStretch();

    suggestionLayout->addWidget(guide);
    suggestionLayout->setAlignment(guide, Qt::AlignRight);
    suggestionLayout->setContentsMargins(0,0,20,0);
    //   (int left, int top, int right, int bottom)

    main_Layout->addStretch();
    main_Layout->addLayout(threshWrapLayout);
    main_Layout->addStretch();
    main_Layout->addLayout(sliderWrapLayout);
    main_Layout->addStretch();
    main_Layout->addLayout(suggestionLayout);
    main_Layout->addStretch();

    main_Layout->addWidget(touchCountLabel);
    main_Layout->addWidget(statusLabel);

    readFromController();

    return main_Layout;
}


void Z2SenseFrame::readFromController()
{
    uint16_t upperThresh;
    if (writePending) return;

    if(SUCCESS == zul_getConfigParamByID(ZXYMT_CI_UPPER_THRESHOLD, &upperThresh))
    {
        if ( upperThresh != actSlider->getValue())
        {
            actSlider->setValue(upperThresh);
        }
    }
}




const QString Z2SenseFrame::Zxy150_Suggestion = QString(
            "<br><center><table cellpadding=\"5\">"
            "<tr>"
                "<th align=\"right\"></th>"
                "<th> 7\"</th><th>10\"</th><th>12\"</th><th>15\"</th><th>19\"</th><th>21\"</th>"
            "</tr>"

            "<tr>"
                "<th align=\"left\"></th>"
                "<th>    </th><th>    </th><th>    </th><th>    </th><th>    </th><th>    </th>"
            "</tr>"

            "<tr>"
                "<th align=\"left\">3mm</th>"
                "<th> 200</th><th> 200</th><th> 200</th><th> 200</th><th> 200</th><th> 200</th>"
            "</tr>"

            "<tr>"
                "<th align=\"left\">6mm</th>"
                "<th> 180</th><th> 180</th><th> 180</th><th> 180</th><th> 180</th><th> 180</th>"
            "</tr>"

            "<tr>"
                "<th align=\"left\">9mm</th>"
                "<th> 100</th><th> 100</th><th> 100</th><th> 100</th><th> 120</th><th> 120</th>"
            "</tr>"


            //"<tr>" -- hidden - performance is not great at 12 mm, so recommendations are not provided

            "</table></center>"
        );

const QString Z2SenseFrame::Zxy200_Suggestion = QString(
            "<br><center><table cellpadding=\"3\">"
            "<tr>"
            "<th align=\"right\"></th><th>22\"</th><th>32\"</th><th>46\"</th><th>55\"</th>"
            "</tr>"

            "<tr>"
            "<th align=\"left\"></th><th></th><th></th><th></th><th></th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td align=\"right\"> 225 </td><td align=\"right\"> 200 </td><td align=\"right\"> 200 </td><td align=\"right\"> 160 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td align=\"right\"> 100 </td><td align=\"right\"> 125 </td><td align=\"right\"> 125 </td><td align=\"right\">  90 </td>"
            "</tr>"

            //"<tr>" -- hidden - performance is not great at 12 mm, but if required these values are recommended
            //"<th>12mm</td><td align=\"right\"> 65 </td><td align=\"right\"> 90 </td><td align=\"right\"> 90 </td><td align=\"right\">  75 </td>"
            //"</tr>"

            "</table></center>"
        );

const QString Z2SenseFrame::Zxy300_Suggestion = QString(
            "<br><center><table cellpadding=\"3\">"
            "<tr>"
            "<th align=\"right\"></th><th>55\"</th><th>65\"</th><th>72\"</th><th>84\"</th>"
            "</tr>"

            "<tr>"
            "<th align=\"left\"></th><th></th><th></th><th></th><th></th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td align=\"right\"> 225 </td><td align=\"right\"> 200 </td><td align=\"right\"> 200 </td><td align=\"right\"> 140 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td align=\"right\"> 140 </td><td align=\"right\"> 125 </td><td align=\"right\"> 120 </td><td align=\"right\">  100 </td>"
            "</tr>"

            //"<tr>" -- hidden - performance is not great at 12 mm, but if required these values are recommended
            //"<th>12mm</td><td align=\"right\"> 100 </td><td align=\"right\"> 100 </td><td align=\"right\"> 100 </td><td align=\"right\"> 80 </td>"
            //"</tr>"

            "</table></center>"
        );




const QString Z2SenseFrame::Zxy500_64_Suggestion = QString(
        "<br><center><table cellpadding=\"3\">"
        "<tr>"
        "<th align=\"right\"></th><th>10\"</th><th>15\"</th><th>22\"</th>"
        "</tr>"
        "<tr>"
        "<th align=\"left\"></th><th></th><th></th><th></th>"
        "</tr>"
        "<tr>"
        "<th>3mm</td><td align=\"right\"> 325 </td><td align=\"right\"> 275 </td><td align=\"right\"> 225 </td>"
        "</tr>"
        "<tr>"
        "<th>6mm</td><td align=\"right\"> 150 </td><td align=\"right\"> 150 </td><td align=\"right\"> 125 </td>"
        "</tr>"
        "<tr>"
        "<th>9mm</td><td align=\"right\"> 100 </td><td align=\"right\"> 100 </td><td align=\"right\"> 100 </td>"
        "</tr>"
        "</table></center>"
        );

const QString Z2SenseFrame::Zxy500_128_Suggestion = QString(
        "<br><center><table cellpadding=\"3\">"
            "<tr>"
            "<th align=\"right\"></th><th>22\"</th><th>32\"</th><th>55\"</th>"
            "</tr>"
            "<tr>"
            "<th align=\"left\"></th><th></th><th></th><th></th>"
            "</tr>"
            "<tr>"
            "<th>3mm</td><td align=\"right\"> 300 </td><td align=\"right\"> 275 </td><td align=\"right\"> 200 </td>"
            "</tr>"
            "<tr>"
            "<th>6mm</td><td align=\"right\"> 125 </td><td align=\"right\"> 150 </td><td align=\"right\"> 150 </td>"
            "</tr>"
            "<tr>"
            "<th>9mm</td><td align=\"right\">  75 </td><td align=\"right\">  75 </td><td align=\"right\"> 100 </td>"
            "</tr>"
        "</table></center>"
        );

const QString Z2SenseFrame::Zxy500_256_Suggestion = QString(
         "<br><center><table cellpadding=\"3\">"
             "<tr>"
             "<th align=\"right\"></th><th>55\"</th><th>72\"</th><th>84\"</th>"
             "</tr>"
             "<tr>"
             "<th align=\"left\"></th><th></th><th></th><th></th>"
             "</tr>"
             "<tr>"
             "<th>3mm</td><td align=\"right\"> 325 </td><td align=\"right\"> N/A </td><td align=\"right\"> N/A </td>"
             "</tr>"
             "<tr>"
             "<th>6mm</td><td align=\"right\"> 150 </td><td align=\"right\"> 150 </td><td align=\"right\"> 150 </td>"
             "</tr>"
             "<tr>"
             "<th>9mm</td><td align=\"right\"> 100 </td><td align=\"right\"> 100 </td><td align=\"right\"> 100 </td>"
             "</tr>"
         "</table></center>"
        );


QString Z2SenseFrame::getIntroText(int16_t devPID, int numWires)
{
    QString introText = QString("<p>") +
            tr("The table below provides suggested settings for Touch Threshold based on the glass sensor size and thickness.") +
            + "</p><p>" +
            tr("NOTE:  These values are only a guide and may need to be optimised for your system.") + "</p>";


    if (devPID == UNKNWN_PRODUCT_ID)
    {
        return introText;
    }

    if (devPID == ZXY150_PRODUCT_ID)
    {
        introText.append(Zxy150_Suggestion);
    }

    if (devPID == ZXY200_PRODUCT_ID)
    {
        introText.append(Zxy200_Suggestion);
    }

    if (devPID == ZXY300_PRODUCT_ID)
    {
        introText.append(Zxy300_Suggestion);
    }

    if ( zul_isZXY500AppPID(&devPID) )
    {
        switch ( numWires )
        {
            case 64:
                introText.append(Zxy500_64_Suggestion);
                break;

            case 128:
                introText.append(Zxy500_128_Suggestion);
                break;

            case 256:
                introText.append(Zxy500_256_Suggestion);
                break;
        }
    }

    return introText;
}

void Z2SenseFrame::showHelp()
{
    QMessageBox helpBox;
    uint16_t numXwires, numYwires, numWires;

    zul_getStatusByID( ZXYMT_SI_NUM_X_WIRES, &numXwires );
    zul_getStatusByID( ZXYMT_SI_NUM_Y_WIRES, &numYwires );
    numWires = numXwires + numYwires;

    helpBox.setWindowTitle(tr("Suggested Settings"));
    QString introText = getIntroText(devPID, numWires);

    /*
    if (devPID == ZXY150_PRODUCT_ID)
    {
        introText.append(Zxy150_Suggestion);
    }

    if (devPID == ZXY200_PRODUCT_ID)
    {
        introText.append(Zxy200_Suggestion);
    }

    if (devPID == ZXY300_PRODUCT_ID)
    {
        introText.append(Zxy300_Suggestion);
    }

    if ( zul_isZXY500AppPID(&devPID) )
    {
        switch ( numWires )
        {
            case 64:
                introText.append(Zxy500_64_Suggestion);
                break;

            case 128:
                introText.append(Zxy500_128_Suggestion);
                break;

            case 256:
                introText.append(Zxy500_256_Suggestion);
                break;
        }
    }
    */

    helpBox.setTextFormat(Qt::RichText);
    helpBox.setText(introText);

    helpBox.setTextFormat(Qt::RichText);
    helpBox.setText(introText);

    helpBox.setIcon(QMessageBox::Information);
    helpBox.setStandardButtons(QMessageBox::Ok);
    helpBox.setModal(true);
    //remove the close button from the dialog if there is one
    Qt::WindowFlags wFlags = helpBox.windowFlags();

    if(Qt::WindowCloseButtonHint == (wFlags & Qt::WindowCloseButtonHint))
    {
        wFlags = wFlags ^ Qt::WindowCloseButtonHint;
        helpBox.setWindowFlags(wFlags);
    }
    helpBox.setDefaultButton(QMessageBox::Ok);

    helpBox.exec();
}

void Z2SenseFrame::createConnections()
{
    QObject::connect(actSlider, SIGNAL(valueChanged(int)),
                     this, SLOT(actValueChange(int)));

    QObject::connect(feedbackTimer, SIGNAL(timeout(void)),
                     this, SLOT(pollForTouch()));

    QObject::connect(writeThreshChange, SIGNAL(timeout(void)),
                     this, SLOT(changeThresholds()));

    QObject::connect(guide, SIGNAL(clicked(void)),
                     this, SLOT(showHelp()));

}


void Z2SenseFrame::actValueChange(int value)
{
    writeThreshChange->start();
    writePending = true;
    value++;
}

void Z2SenseFrame::changeThresholds()
{
    emit APIResult(ZytAPIResult::Progress);
    int v = actSlider->getValue();
    v = MIN_ALLOWED > v ? MIN_ALLOWED : v;

    if (actSlider->getValue() != v)
    {
        actSlider->setValue(v);
    }

    if(SUCCESS != zul_setConfigParamByID(ZXYMT_CI_UPPER_THRESHOLD, v))
    {
        emit APIResult(ZytAPIResult::Failure);
        reReadValues();
    }
    else
    {
        emit APIResult(ZytAPIResult::Success);
        writePending = false;
        emit thresholdsChanged(); // -- for test / raw data update
    }
}

void Z2SenseFrame::pollForTouch()
{
    static int  counter = 0;
    uint16_t    touchPressure, status=0xffff;
    char        buf[40];

    if (!isVisible())
    {
        return;
    }


    statusLabel->setVisible(getAdvancedMode() == 0 ? false : true);
    touchCountLabel->setVisible(statusLabel->isVisible());


    if (SUCCESS != zul_getStatusByID(ZXYMT_SI_CURRENT_SIGNAL_LEVEL, &touchPressure))
    {
        return;
    }

    if ((statusLabel->isVisible()))
    {
        if (SUCCESS == zul_getStatusByID(ZXYMT_SI_STATUS_ACTIVE, &status))
        {
            sprintf(buf, "Controller status: %04X", status);
            statusLabel->setText(buf);
        }
        else
        {
            statusLabel->setText("Controller status: ----");
        }
    }

    if ((touchCountLabel->isVisible()))
    {
        if (SUCCESS == zul_getStatusByID( ZXYMT_SI_NUM_LIVE_TOUCHES, &status))
        {
            sprintf(buf, "Active Touch Count: %04X", status);
            touchCountLabel->setText(buf);
        }
        else
        {
            touchCountLabel->setText("Active Touch Count: ----");
        }
    }

    if (touchPressure>MAX_THRESHOLD)
        touchPressure = MAX_THRESHOLD;

    actSlider->setReading((int)touchPressure);

    if (touchPressure > actSlider->getValue())
    {
    }
    else
    {
    }

    if ((counter++ % 25) == 0) reReadValues();

    // printf("Polling (%05d) [%04x] done\n", touchPressure, status);
}

void Z2SenseFrame::reReadValues()
{
    /* Prevent writing back to controller when changing
     * GUI widget values by disconnecting all slots
     * from this object */
    actSlider->disconnect(this);
    writeThreshChange->disconnect(this);
    feedbackTimer->disconnect(this);
    guide->disconnect(this);


    readFromController();

    /* re create all the connections */
    createConnections();
}

void Z2SenseFrame::showEvent(QShowEvent *Event)
{
    if(QEvent::Show == Event->type())
    {
        //pollingTimer->start();
    }

    ZytContentFrame::showEvent(Event);
}

void Z2SenseFrame::hideEvent(QHideEvent *Event)
{
    if(QEvent::Hide == Event->type())
    {
        //pollingTimer->stop();
    }

    ZytContentFrame::hideEvent(Event);
}


QString Z2SenseFrame::getText(int16_t pid)
{
    QString text;

    switch (pid)
    {
        default:
            text = QString("Bad PID; MT devices only");
            break;
        case ZXY150_PRODUCT_ID:
            text = QString("ZXY150 suggestions:\n");
            text.append( getIntroText(pid, 0)+ "\n");
            break;
        case ZXY200_PRODUCT_ID:
            text = QString("ZXY200 suggestions:\n");
            text.append( getIntroText(pid, 0)+ "\n");
            break;
        case ZXY300_PRODUCT_ID:
            text = QString("ZXY300 suggestions:\n");
            text.append( getIntroText(pid, 0)+ "\n");
            break;
        case ZXY500_PRODUCT_ID:
        case ZXY500_PRODUCT_ID_ALT1:
            text = QString("ZXY500 suggestions:\n");
            text.append( getIntroText(pid, 64) + "\n");
            text.append( getIntroText(pid, 128)+ "\n");
            text.append( getIntroText(pid, 256)+ "\n");
            break;
        case UNKNWN_PRODUCT_ID:
            text = getIntroText(UNKNWN_PRODUCT_ID, 0)+ "\n";
            break;
    }
    text.replace("</hr>", "\n");
    text.replace("</tr>", "\n");
    text.replace("</p>", "\n");
    text.replace(QRegularExpression("<.+?>"), "");
    return text;
}
