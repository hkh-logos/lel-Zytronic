/*
 *  Data store that describes a ZXY100 controller.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef ZXY100DATA_H
#define ZXY100DATA_H


#include <stdint.h>
#include <string>
#include <map>
#include <utility>
#include <list>

using namespace std;

#include <sys/timeb.h>

#include "services_sc.h"

const int           FieldLen        =           60;
const unsigned int  NoiseHoldCount  =           16;     // 100ms units

class Zxy100Data
{
public:

    struct rawSample_t
    {
        ZXY100_rawImage     rawData;            // 27/11/2018
        int                 maxX, maxY, maxXY;
        bool                maxOvr70, maxOvr50, maxOvr30;

    };
    typedef struct rawSample_t RawSampleStats;

    enum JobType
    {
        getFirst,   getNormal,  getBaseline,    getDelta
    };

    struct sysReport_t
    {
        JobType                 job;
        time_t                  TS_secs;
        unsigned short          TS_msec;    // milliseconds - see ftime()
        Zxy100SysReport         sysReport;
    };
    typedef struct sysReport_t SysReport;

    static const int    MIN_LOWER_THR_SETTING = 20;
    static const int    BS_FinalThresholdAdjustment = 5;
    static const int    BS_ThresholdAdjustment = 3;
    static const int    BS_InitialThreshold = 50;

    uint16_t            DeBounce;

    // --- Methods ------------------------------

    Zxy100Data();
    void            refreshInfo();

    char           *getProcID(void);

    void            getNewRawData(void);
    int             getRawDataMinOfMaxs(void);

    // get the wire index holding the max reading
    int             getXIndexforRawMax(void);
    int             getYIndexforRawMax(void);

    void            prepRawDataCollection(int UTCI);
    void            collectNewRawData(void);
    void            enableRawDataCapture(bool);
    bool            calcStdDevs(void);

    void            getNewNoiseReport(JobType j);
    int             getNoiseReportStr(JobType j, char *return_buffer, int buf_len);
    int             getNoiseReportValue(JobType j, int v, int *ret_val);
    int             getNumNoiseRecoveryEvents(JobType j, int *ret_val);
    int             getNumEqualizations(JobType j, int *ret_val);
    bool            noiseDetected(void);
    bool            equalisationDetected(void);
    bool            noiseRecoveryDetected(void);

    bool            activeLEDs(void);
    void            enableLEDs(bool active);

    // allow access to test results
    int             getNumFrames(void);
    int             numFramesOvr70, numFramesOvr50, numFramesOvr30;
    float           getXMeanWireAverage(void);
    float           getYMeanWireAverage(void);
    float           getXStdDev(void);
    float           getYStdDev(void);

private:

    uint16_t            upperThreshold;

    ZXY100_rawImage      rawData;                // 27/11/2018
    list<RawSampleStats> sampleList;

    bool                rawDataCaptureEnabled;

    int                 minOfMaxs;
    int                 xOfMax,     yOfMax;
    float               xAvgTally,  yAvgTally;   // sum of the average wire levels (X/Y) in all frames
    float               xStdDev,    yStdDev;

    bool                ledPollingIsActive;

    char                fwStr[FieldLen];

    char                ProcID[24+1];           // e.g. "57FF6B064884575219481387"

    SysReport           firstReport, lastReport, baselineReport, deltaReport;
    SysReport           noiseMemory;            // special internal store



    // --- Methods ------------------------------

    SysReport         * getReportByJob      (JobType j);
    bool                scanRawSample       (RawSampleStats *rawSample);
    void                logFrameToConsole   (void);
};

#endif // ZXY100DATA_H
