/*
 *      Present the ZXY100 wire values. This implementation replaces
 *      the WireLevelDisplay class.  (started Feb 2015 - CFM)
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef Z1_RAWIMAGEWIN_H
#define Z1_RAWIMAGEWIN_H

#include <stdio.h>
#include <QDialog>
#include <stdint.h>
#include <sys/timeb.h>

#include "WireLevelDisplay.h"
#include "WireLevelXLabels.h"
#include "WireLevelYLabels.h"

#include "services.h"
#include "services_sc.h"

class Z1_RawImageWindow : public QDialog
{
    Q_OBJECT

public:
    Z1_RawImageWindow       (QWidget *parent = 0);
    void setAdvancedMode    (int optBitField);
    void setDimensions      (uint16_t pid, uint16_t width, uint16_t heigth);
    void setMsToRun         (long msTimeOut);

    enum RAW_Flags
    {
        FlagGridOn     =        1 << 0,
        FlagFrameCount =        1 << 1,
        FlagFrameIndex =        1 << 2,
        FlagBrightBackground =  1 << 3,
    };

public slots:
    int exec();

protected:
    void paintEvent         (QPaintEvent*);
    void resizeEvent        (QResizeEvent*);

private slots:
    void monitor            ();
    void keyPressEvent      (QKeyEvent *event);
    void keyReleaseEvent    (QKeyEvent *event);
    void dumpToFile         (void);
    void updateView         ();
    void readThresholds     ();

private:
    QGridLayout     *createLeftLayout();
    QLayout         *createLayout();


    WireLevelDisplay   *wireLevelDis;
    WireLevelXLabels   *wireLevelXLabels;
    WireLevelYLabels   *wireLevelYLabels;

    QLabel             *xAxisTitle;
    QLabel             *yAxisTitle;

    QTimer             *frameTimer;

    int                 stateSeconds;
    int                 modeBitField;
    int                 frameIndex;
    bool                drawResize;
    FILE               *dumpFile;
    bool                running;

    // required for ZXY110, not ZXY100.
    bool                xFlip, yFlip, xySwap;

    unsigned int        numXWires, numYWires, cellCount;
    uint16_t            devPID;
    QString             Title, exitStr;
    struct timeb        startTime;
    long                msToRun;

    ZXY100_rawImage     rawImage100;
    ZXY110_rawImage     rawImage110;
};

#endif // Z1_RAWIMAGEWIN_H
