/*
 *      Class to test sensor-controller-display integrations
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef Z2INTEG2TESTS_H
#define Z2INTEG2TESTS_H

#include <QtWidgets>

#include "logfile.h"
#include "services.h"

#include "IntegrationTest.h"
#include "Monitor.h"
#include "Zxy100Data.h"

enum WireID {X_WIRES, Y_WIRES};

class Z2IntegTests : public QDialog
{
    Q_OBJECT

public:
    Z2IntegTests(QWidget *parent = 0);


    void setZXY100Data(Zxy100Data *dd);
    void setAppVersionStrs(QString &s);
    void setMonitor(Monitor *m);

    enum ITState
    {
        // ### Multi-Touch mode state-progression #############################
        // ZXY150, ZXY200, ZXY200,  ZXY500

        MT_InitDelay,
        SensorDetect,
        SensorIntegrity,        TSpause1,

        SensorQuiet,

          FirstTouchMode,         // These 3 are not used for ZXY500 devices
          DetectedNoise,
          NoiseRejection,       TSpause2,
        FrameRate,

        MT_Finished,                // halt activity await user exit (escape) event

        // ### ZXY100 mode state-progression ##################################

        Z100_InitDelay,

        Z100_Capture_W,
        Z100_Capture_B,
        Z100_Capture_Rslt,          Z100pause1,
        Z100_SIG_70PC_THRESHOLD,
        Z100_SIG_50PC_THRESHOLD,
        Z100_SIG_30PC_THRESHOLD,    Z100pause2,
        Z100_MEAN_VALUES,
        Z100_STDDEV_VALUES,         Z100pause3,
        Z100_NOISE_ALGO_COUNTS,
        Z100_EQ_COUNTS,
        Z100_NOISE_FIX_EVENTS,

        Z100_Finished,                // halt activity await user exit (escape) event

        // ### ZXY110 mode state-progression ##################################
        // straight copy from Windows state machine

        Z110_InitDelay,
        Z110_STABILIZING_UP,
        Z110_STABILIZING_EQ_1,
        Z110_STABILIZING_FTM,
        Z110_STABILIZING_EQ_2,

        Z110_EQUALISE,
        Z110_EQUALISE_WAIT,

        Z110_Capture_W,
        Z110_Capture_B,
        Z110_Capture_Rslt,

        Z110_RAW_DATA_70pc_HITS,
        Z110_RAW_DATA_50pc_HITS,  Z110pause1,

        Z110_RAW_DATA_MEANXY,
        Z110_RAW_DATA_StdDevXY,   Z110pause2,

        Z110_CHECK_STATUS_VALUES,

        Z110_Finished,

        LastState
    };

    // structure to organise the const initial states of the test-sets {ZXY100, ZXY200, ZXY300, ... TBD}
    struct stateRefData_t
    {
        QString         name; //, result, notes, clipNotes;
        ITState         state;
        int             durationSecs;
        bool            visible;
    };
    typedef struct stateRefData_t IT_StateDefn;

    // structure to hold the dynamic data of each test and facilitate presentation
    struct stateRunData_t
    {
        ITState         state;
        int             durationSecs, elapsedSecs;
        IntegrationTest *dispData;
        bool            visible;
    };
    typedef struct stateRunData_t IT_StateRunData;

    // storage allocation for 'MaxTests' test states and results
    QMap<ITState, IT_StateRunData *> *testStateMap;

    void        setAdvancedMode(bool mode);

public slots:
    int         exec();
    void        collectNewRawData(void);  // FIXME private ?

protected:
    void        paintEvent(QPaintEvent*);

private slots:
    void        changeState();
    void        keyPressEvent(QKeyEvent *event);
    void        keyReleaseEvent(QKeyEvent *event);

private:
    int16_t             devPID;
    Zxy100Data         *zxy100Data;         // CONTROLLING instance
    Zxy100Data         *zxy100DataBlack;    // BLACK screen data collector only
    bool                blackScreen;
    ITState             currentTest;
    QTimer             *secondTick;
    QTimer              pollingTimer;
    bool                advancedMode;

    Zxy110SysState      zxy110initState, zxy110TestState;

    QRect               infoBox;
    QRect               titleBox;
    QRect               procBox;
    QRect               recomendBox;
    QRect               exitBox;
    QString             recommendation;
    int                 border;
    QString             versAppStr;

    void        initData(void);

    void        positionInfoBox(int width, int height, int cBorder, // int index,
                                    QPoint *topLeft, QPoint *bottomRight);

    void        InitMeasurementData(void);
    QString     getTestResultStr(void);
    void        tmpReportFile(void);
    void        notifyUserOfResultFile(void);
    void        offerCopyToClipboard(void);
    int         expectedWires(WireID rowORcol);
    int         desiredFrameRate(void);
    QString     getStateName(int stateNo);

    ZyLogFile          *integTestLog;

    QString             Title, ControllerID, exitStr;

    uint16_t            numActiveCells;
    uint16_t            xF, xL, yF, yL;             // xFirst, .. yLast
    int                 xR, yR;                     // numActiveRows / numActiveColumns

    uint16_t            statusOrSincePrevious,      statusAndSincePrevious,      status_leds;
    uint16_t            numLiveRow,   numLiveCol;
    uint16_t            numResampled, frameRate,    firstTouchModeSetting;

    uint16_t            firstTouchModeOffMetricBlack, firstTouchModeOffMetricWhite;
    uint16_t            firstTouchModeOffThreshold;

    uint16_t            firstTouchModeOnMetricMaxValue;
    uint16_t            firstTouchModeOnThreshold;
    bool                failed50pcTest;

    ZXY_sensorSize      szSensor;
    Monitor            *pAssignedMonitor;
    QRect               monitorRect;
};

#endif // Z2INTEG2TESTS_H
