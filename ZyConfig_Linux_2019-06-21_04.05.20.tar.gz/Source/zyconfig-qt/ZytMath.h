/*
 *      Generic math functions used by some of the classes.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef ZYTMATH_H
#define ZYTMATH_H

#include <math.h>

#define zy_pi           (3.1415926)

inline
int min(const int a, const int b)
{
    return (a) < (b) ? a : b;
}

inline
int max(const int a, const int b)
{
    return (a) > (b) ? a : b;
}

inline
double round(const double val)
{
    return (val > 0.0) ? floor(val + 0.5) : ceil(val - 0.5);
}

#endif
