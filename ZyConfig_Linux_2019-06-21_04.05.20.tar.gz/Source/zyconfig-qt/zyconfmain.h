/*
 *      Main Window for the configuration application.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef ZYCONFMAIN_H
#define ZYCONFMAIN_H

#include <QMainWindow>
#include <QTimer>
#include "ZytConfigPage.h"
#include "InstallWizard.h"
#include "ManualSetup.h"
#include "FirmwareUpdate.h"
#include "AboutPage.h"
#include "SysInfoDisplay.h"
#include "ZytAPIResult.h"

class ZyConfMain : public QMainWindow
{
    Q_OBJECT

public:
    enum guiState
    {
        NotInitialized=0, NotConnected, UpdateOnly, Connected, Wizard
    };

    ZyConfMain();
    void                setState(ZyConfMain::guiState state);
    ZyConfMain::guiState  getGUIState(uint16_t pid);
    virtual void        closeEvent(QCloseEvent *event);

public slots:
    void                reReadValues();
    void                pauseConnectionCheck(bool pause);

protected:
    virtual bool        event(QEvent *event);


signals:
    void                connection(const char *t);

private slots:
    void                pollForConnection();
    void                pollForLEDs_ZXY_MT();
    void                pollForLEDs_ZXY100();
    void                reReadThresholds();
    void                fwXfrStateInd(bool running);

private:
    void                createStatusBar();
    void                setupTimers();
    void                createConnections();
    QWidget         *   createCentralWidget();

    void                setTabEnable(QWidget *w, bool enable);

    void                setLED(QLabel *led, QString txt, QColor c);
    void                setLED(QLabel *led, QString txt);
    void                setLED(QLabel *led, QColor c);

    void                displayFwWarningDialogue(int16_t pid);

    guiState                currentState;

    QTabWidget              *tabContainer;

    ZytConfigPage           *installWizardPage;
    InstallWizard           *installWizardContent;

    ZytConfigPage           *firmwareUpdatePage;
    FirmwareUpdate          *firmwareUpdateContent;

    ManualSetup             *manualSetupPage;

    AboutPage               *aboutPage;

    SysInfoDisplay          *infoDispl;

    QLabel                  *status;
    ZytAPIResult            *apiStatus;

    QTimer                  *pollConnected, *pollLedTimer;

    QLabel                  *led0, *led1, *led2, *led3;
};

#endif
