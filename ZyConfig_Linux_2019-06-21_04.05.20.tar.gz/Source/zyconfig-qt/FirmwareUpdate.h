/*
 *      Content of the Firmware Update Tab in the config app
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef FIRMWAREUPDATE_H
#define FIRMWAREUPDATE_H

#include <QtWidgets>
#include "ZytContentFrame.h"
#include "UploadFirmwareThread.h"


class FirmwareUpdate : public ZytContentFrame
{
    Q_OBJECT
public:
    explicit        FirmwareUpdate          (QWidget *parent = 0);

    void            clearProgress           (void);
    bool            fwXfrActive             (void);

protected:
    virtual void    showEvent               (QShowEvent *Event);

signals:
    void            reReadRequired          (void);
    void            pauseConnectionCheck    (bool pause);
    void            signalFwXfrState        (bool running);

private slots:
    void            startUpdate             (void);
    void            checkProgress           (void);

private:
    void            createWidgets           (void);
    void            createConnections       (void);
    QLayout         *createLayout();


    QLabel                  *descriptionLabel;
    QLabel                  *methodLabel;
    QLabel                  *importantLabel;
    QLabel                  *warningLabel;

    QProgressBar            *progressBar;
    QLabel                  *statusLabel;
    QPushButton             *updateButton;
    QLabel                  *noteLabel;

    QTimer                  *progressTimer;
    UploadFirmwareThread    *uploader;
};

#endif // FIRMWAREUPDATE_H
