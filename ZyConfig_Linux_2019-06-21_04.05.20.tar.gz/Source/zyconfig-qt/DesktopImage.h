// Desktop Image Widget

#ifndef DESKTOP_IMAGE_H
#define DESKTOP_IMAGE_H

#include <QtWidgets>
#include "Monitor.h"

class DesktopImage : public QWidget
{
    Q_OBJECT

    public:

        DesktopImage ( QWidget *parent = 0 );
        int heightForWidth (int) const;
        QSize sizeHint() const;

    public slots:
        void setOutline( Monitor * m );
        void setSelected( Monitor * m );
        void addMonitors( QVector<Monitor*> * monVec );

    protected:
        void paintEvent(QPaintEvent *);

    private:
        Monitor *outline;
        QVector<Monitor*> * monitorVector;
        Monitor *selectedMon;
};


#endif // DESKTOP_IMAGE_H
