/*
 *      Calibration Widget. Displays a number of points on the screen in order
 *      to calculate calibration data and then write it to the controller
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef Z2RAWIMAGEWIN_H
#define Z2RAWIMAGEWIN_H

#include <stdio.h>
#include <QDialog>
#include <stdint.h>
#include <sys/timeb.h>

class Z2RawImageWindow : public QDialog
{
    Q_OBJECT

public:
    Z2RawImageWindow(QWidget *parent = 0);
    void setAdvancedMode(int optBitField);
    void setDimensions(uint16_t width, uint16_t heigth);
    void setMsToRun(long msTimeOut);


    enum RAW_Flags
    {
        FlagGridOn     =        1 << 0,
        FlagFrameCount =        1 << 1,
        FlagFrameIndex =        1 << 2,
        FlagBrightBackground =  1 << 3,
        FlagColorMap2  =        1 << 4,
    };

public slots:
    int exec();

protected:
    void paintEvent(QPaintEvent*);
    void resizeEvent(QResizeEvent*);

private slots:
    void monitor();
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
    void dumpToFile(void);

private:
    QTimer         *frameTimer;
    int             stateSeconds;
    int             modeBitField;
    int             frameIndex;
    bool            drawResize;
    FILE           *dumpFile;
    bool            running;
    bool            xFlip, yFlip;
    unsigned int    numXWires, numYWires, cellCount;
    QString         Title, exitStr;
    struct timeb    startTime;
    long            msToRun;

    // make the buffers big enough for any sensor
    unsigned char   rawData[160*96];
    unsigned char   refData[160*96];

};

#endif // Z2RAWIMAGEWIN_H
