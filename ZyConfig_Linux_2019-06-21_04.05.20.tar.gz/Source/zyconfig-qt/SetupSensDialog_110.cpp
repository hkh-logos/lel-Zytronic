/*
 *      Basic Setup Process. Displays a number of points on the screen in order
 *      to evaluate touch sensitivity data and then write it to the controller.
 *      Also set the axes for the given sensor-display integration.
 *      Also, On multi-touch controllers, set the noise handling parameters.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *366

 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */

/*
  SetupSensDialog_110

    16/1/2019 : covers ZXY110

    This class is designed to guide a user through a process which determines
    a reasonable set of values for the following
    - the sensitivity setting
    - the sensor orientation:
            - axes swapped, or normal
            - axis flipped, or normal

    - the Palm Detection Threshold setting is not automatically handled for ZXY110

    - the First Touch Mode settings - TBC ZYX110

    Users need not learn about these settings, only follow the on-screen guidance

    The whole process is driven by the periodic tick() operation, located in the base class

    NB: This does not complete a calibration!

    --------------------

    Basic Call Tree (see BASE class):

        exec()
            initData()
            start fastTick to call tick() -- see 'TICKS_PER_SECOND'
            QDialog::exec()

        tick()
            conditionally sample data
            if (state.timeout passed) changeState()

        changeState()
            save data from controller at end of state period
            determine next state, and period (terminate on error, or completion)
            move to new state, and send prep commands to controller

    --------------------

    NB: Also, separate the 'view' from the 'controller'!
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

#include "services.h"
#include "services_sc.h"
#include "debug.h"
#include "logfile.h"

#include "Zxy100Data.h"
#include "SetupSensDialog_110.h"


/**********************************************************
 *          Constructor
 *********************************************************/

SetupSensDialog_110::SetupSensDialog_110(QWidget *parent) : SetupSensDialog_BASE(parent)
{
    zxy110RestoreDefaultTimer = NULL;
    zxy110IsRestoringToDefaults = false;
    zxy100Data = NULL;
    basicSetupLog->Write2Log("Basic Setup Created");
}

/**
 * remember provided with Zxy100Data (self-cap) object
 */
void SetupSensDialog_110::setZXY100Data(Zxy100Data *dd)
{
    zxy100Data = dd;
}

/**
 * module global initialisation
 */
bool SetupSensDialog_110::initData2(void)
{
    basicSetupLog->Write2Log( "Basic Setup - ZXY110 - RESTART" );
    return true;
}

/*
 * update the setProposal values, based on all data collected.
 * called from BASE class processData()
 */
void SetupSensDialog_110::updateSetProposal(void)
{
    setProposal.pseudoUpperThr = state.touchMinimum - zxy100Data->BS_FinalThresholdAdjustment;
    if (setProposal.pseudoUpperThr < 12)
    {
        setProposal.pseudoUpperThr = 12;       // MAGIC
    }
}

/**
 * return the minimum of the X and Y max accumulated signal
 *
 */
int SetupSensDialog_110::getPseudoTouchSignal(void)
{
    int a = touchData.minAtX[touchData.xLoc];
    int b = touchData.minAtY[touchData.yLoc];
    return (a < b) ? a : b;
}


/**
 * following processData() the controller is configured here
 */
void SetupSensDialog_110::applySettings(void)
{
    basicSetupLog->Write2LogF("Write UThres:%03d PalmT:%03d - SwapAxis:%d FlipX:%d FlipY:%d",
                        setProposal.pseudoUpperThr, setProposal.palmThresh,
                        setProposal.swapAxes, setProposal.invertXaxis, setProposal.invertYaxis);

    FILE *fp = fopen("/tmp/ZyConfig-BasicSettings.txt", "w");
    if (fp != NULL)
    {
        fprintf(fp, "Glass Thickness: %1d  Upper Threshold:%03d Palm Rejection Threshold:%03d\r\n",
                    setProposal.glassThickness,
                    setProposal.pseudoUpperThr,
                    setProposal.palmThresh);
        fprintf(fp, "SwapAxis:%d FlipX:%d FlipY:%d\r\n",
                    setProposal.swapAxes,
                    setProposal.invertXaxis,
                    setProposal.invertYaxis);

        fclose(fp);
    }


    zul_inhibitFlashWrites(true);
    //FTM handled when leaving state FirstTouchMeasureB

    if (setProposal.pseudoUpperThr < 99)
    {
        SET_CONFIG_PARAM( ZXY110_CI_LOWER_THRESHOLD, setProposal.pseudoUpperThr - zxy100Data->DeBounce);
        SET_CONFIG_PARAM( ZXY110_CI_UPPER_THRESHOLD, setProposal.pseudoUpperThr);

        SET_CONFIG_PARAM( ZXY110_CI_SWAP_XY, setProposal.swapAxes );

        SET_CONFIG_PARAM( ZXY110_CI_INVERT_X, setProposal.invertXaxis );
        SET_CONFIG_PARAM( ZXY110_CI_INVERT_Y, setProposal.invertYaxis );

        //Save the digital pot value that gave a stable frequency
        SET_CONFIG_PARAM( ZXY110_CI_DIGITAL_POT_VALUE,      zxy110initState.digitalPotValue);

        //Put these params back to their default values
        SET_CONFIG_PARAM( ZXY110_CI_DYNAMIC_EQUALISE_SCANS, zxy110initState.cfg_DynEqScans );
        SET_CONFIG_PARAM( ZXY110_CI_FTPM_TIMER,             zxy110initState.cfg_FtpmTimer );
    }
    else
    {
        basicSetupLog->Write2LogF("%s ERROR", __FUNCTION__ );
    }

    zul_inhibitFlashWrites(false);

    emit APIResult(ZytAPIResult::Success);
}


/**
 */
void SetupSensDialog_110::getNextState(void)
{
    if (DebugText>1) basicSetupLog->Write2LogF(__FUNCTION__);

    if (state.panelState == NotifyChgSens100)
    {
        state.panelState = EqualizeSensor;
        return;
    }

    // if (state.panelState == RestoreSettings) -- stay in state ...

    if (state.panelState == ReleaseTouch)
    {
        if (state.touchSeqLoc < NUM_TSEQ_POINTS)
        {
            state.panelState = GetTouch;
        }
        else
        {
            haltRawData();
            /*  switch back to default handler so rawview is OK
             *  zul_SetSpecialHandler(,handle_IN_rawdata_110_Clipped)
             */
            zul_setRawDataHandler();

            processData();
            state.panelState = Finished;
        }
    }
    else
    {
        if (state.panelState != RestoreSettings)
        {
            // Normal progression
            state.panelState = (PanelState)(1+state.panelState);
        }
    }

    if (state.panelState == GetNoiseProfile)
    {
        // fake the noise reading
        noiseMax = 10;

        // prepare the touch pseudo level
        setProposal.pseudoUpperThr = 55;
        basicSetupLog->Write2LogF("NoiseSample Max: %d => PseudoThreshold = %d",
                                                    noiseMax, setProposal.pseudoUpperThr);

        // move on
        state.panelState = (PanelState)(1+state.panelState);
    }

    if (state.panelState == FirstTouchMeasureW)
        state.panelState = EqualizeSensor;
}


/**
 */
int SetupSensDialog_110::getStateTO(void)
{
    int retVal = 1;
    switch (state.panelState)
    {
        case RestoreDefaults:
        case RestoreSettings:
            retVal = 30 * TICKS_PER_SECOND;   // see tick() for escape when done
            break;

        case Confirm:
        case NotifyChgSens100:
            retVal = 2 * TICKS_PER_SECOND;
            break;

        case GetTouch:
            retVal = TICKS_PER_SECOND / 2;
            break;

        case Failed_NoTouch:
            retVal = TOUCH_ON_WAIT * TICKS_PER_SECOND;
            break;

        case ReleaseTouch:
        case Failed_NoRelease:
            retVal = TOUCH_OFF_WAIT * TICKS_PER_SECOND;
            break;

        case Finished:
            retVal = DONE_WAIT * TICKS_PER_SECOND;
            break;

        case EqualizeSensor:
        case ChangeSens100:
        default:
            retVal = 3 * TICKS_PER_SECOND;
    }
    return retVal;
}


/**
 * when a state's period is completed, just before the transition into a new
 * state, data may need to be taken from the touch controller. These fuctions
 * know what data to take at these moments for the connected controller.
 *
 * If the return value is 1, then the changeState function that called here
 * should return with no further processing !
 */
int SetupSensDialog_110::storeStateData(void)
{
    switch (state.panelState)
    {
        case Failed_NoTouch:
        case Failed_NoRelease:
        case Failed_CommsError:
        case Failed_Noise:
            zxy100Data->enableRawDataCapture(false);
            break;

        case Finished:
            zxy100Data->enableRawDataCapture(false);
            return 1;
            break;  // redundant

        case RestoreDefaults:

            zul_inhibitFlashWrites(true);

            // grab default values for some config items
            GET_CONFIG_PARAM( ZXY110_CI_DYNAMIC_EQUALISE_SCANS, zxy110initState.cfg_DynEqScans );
            GET_CONFIG_PARAM( ZXY110_CI_FTPM_TIMER,             zxy110initState.cfg_FtpmTimer );

            GET_STATUS_VAL  ( ZXY110_SI_NUM_TOUCH_SINCE,        zxy110initState.numTouchSinceLast );
            //GET_STATUS_VAL( ZXY110_SI_NUM_EQUALIZATIONS,      zxy110initState.numEqualizations );
            GET_STATUS_VAL  ( ZXY110_SI_NUM_FTM_ACTIVATIONS,    zxy110initState.numFtmActivations );
            GET_STATUS_VAL  ( ZXY110_SI_NUM_FREQ_HOPPED,        zxy110initState.numFreqHopped );

            // ZXY110 MUST be in single touch mode for reliable raw-values with high thresholds (as used in basic-setup)
            SET_CONFIG_PARAM( ZXY110_CI_DEVICE_MODE,            ZXY100_MODE_SINGLE);
            SET_CONFIG_PARAM( ZXY110_CI_GLASS_THICKNESS,        setProposal.glassThickness );

            SET_CONFIG_PARAM( ZXY110_CI_UPPER_THRESHOLD,        100);
            SET_CONFIG_PARAM( ZXY110_CI_LOWER_THRESHOLD,        99);

            SET_CONFIG_PARAM( ZXY110_CI_DYNAMIC_EQUALISE_SCANS, 0);      //turn off the dynamic equalizer
            SET_CONFIG_PARAM( ZXY110_CI_FTPM_TIMER,             10);

            //Set these to OFF - cannot always rely on "Restore Defaults" with some customized firmware
            SET_CONFIG_PARAM( ZXY110_CI_INVERT_X,               0);
            SET_CONFIG_PARAM( ZXY110_CI_INVERT_Y,               0);
            SET_CONFIG_PARAM( ZXY110_CI_SWAP_XY,                0);

            GET_CONFIG_PARAM( ZXY110_CI_FTPM_TIMER, firstTouchModeTimeout );

            firstTouchModeTimeout       = (firstTouchModeTimeout * 3 + 5);
            firstTouchModeTimer         = 0;

            zxy110initState.scanFreqKHz = 0;
            touchData.numAboveThresh    = 0;
            touchData.numBelowThresh    = 0;

            zul_inhibitFlashWrites(false);

            break;

        case GetTouch:

            // with 20 ticks per seconds, touchStateCount increases twice a second
            state.touchStateCount++;

            basicSetupLog->Write2LogF(" --- %s [%d]\t\t-- Z1_TSC:%d",
                    getStateCStr(), state.panelState, state.touchStateCount);

            {
                int minOfMaxs = zxy100Data->getRawDataMinOfMaxs();
                state.timeout = getStateTO();

                if (minOfMaxs < zxy100Data->MIN_LOWER_THR_SETTING)
                {
                    // After 7 seconds, give up on this glass thickness (or coarse sensitivity)
                    // User may not have touched sensor within time-limit
                    if (state.touchStateCount/2 >= 7 )
                    {
                        setProposal.glassThickness++;
                        if (setProposal.glassThickness > ZXY100_GLASS_EXTRA_THICK)
                        {
                            state.panelState = Failed_NoTouch;
                            state.timeout = 3 * TICKS_PER_SECOND;
                        }
                        else
                        {
                            state.panelState = ChangeSens100;  //Restart with a new glass thickness.
                        }
                    }
                }
                else
                {
                    if (state.touchStateCount/2 >= 3)   // after 3 seconds
                    {
                        if ((touchData.wasPseudoTouched == true) && (touchData.isPseudoTouched == true))
                        {
                            touchData.wasTouchedCounter = REQD_ON_SAMPLES + 1;
                        }

                        if ((touchData.wasPseudoTouched != true))
                        {
                            // accelerator for large separation
                            if ( ( (setProposal.pseudoUpperThr - zxy100Data->DeBounce) > minOfMaxs) &&
                                 ( minOfMaxs > zxy100Data->MIN_LOWER_THR_SETTING )
                               )
                            {
                                setProposal.pseudoUpperThr = minOfMaxs; // - THRESHOLD_ADJUSTMENT);
                                touchData.numBelowThresh = 0;
                                basicSetupLog->Write2LogF(" NEW PROPOSED UT %d", setProposal.pseudoUpperThr);
                            }
                        }
                    }

                    if (state.touchStateCount/2 >= 1)   // after 1 second
                    {
                        if ((touchData.wasPseudoTouched == true) && (touchData.isPseudoTouched == false))
                        {
                            setProposal.pseudoUpperThr -= zxy100Data->BS_ThresholdAdjustment;
                            touchData.numBelowThresh = 0;
                            if ( ( setProposal.pseudoUpperThr - zxy100Data->DeBounce ) < zxy100Data->MIN_LOWER_THR_SETTING)
                            {
                                setProposal.glassThickness++;

                                if (setProposal.glassThickness > ZXY100_GLASS_EXTRA_THICK)
                                {
                                    state.panelState = Failed_NoTouch;
                                    state.timeout = 3 * TICKS_PER_SECOND;
                                }
                                else
                                {
                                    state.panelState = ChangeSens100;  //Restart with a new glass thickness.
                                }
                            }
                        }
                    }
                }
            }

            // Ok - we have data for a good touch - store the touch parameters for this target.
            if (touchData.wasTouchedCounter > REQD_ON_SAMPLES)
            {
                processPseudoTouch();
            }
            else
            {
                return 1;
            }

            break;

        case ReleaseTouch:
            state.touchStateCount = 0;

            if (touchData.numBelowThresh < REQD_OFF_SAMPLES)
            {
                state.panelState = Failed_NoRelease;
                state.timeout = 3 * TICKS_PER_SECOND;
                update();
                return 1;   // try again, or fail
            }

            break;

        case RestoreSettings:
        case LastState:
            reject();       // auto exit back to main GUI
            break;

        // valid states which have no data collection duties

        case SaveSettings:
        case EqualizeSensor:
        case Confirm:
        case ChangeSens100:
        case NotifyChgSens100:
            break;

        default:
            basicSetupLog->Write2LogF(  "%s UNEXPECTED STATE [%d] %s ##### \n",
                                        __FUNCTION__, state.panelState, getStateCStr() );
    }
    return 0;
}



/**
 * when a state's period is starting, just after the transition into a new
 * state, actions may be taken on the local data stores, and the device.
 * These fuctions determine the actions required for the set of valid states.
 *
 * If the return value is 1, then the changeState function operation may be
 * altered. Value is TBD; this facility echos the return value provided (and
 * required) by pf_storeStateData();
 */
void SetupSensDialog_110::prepNewState(void)
{
    switch (state.panelState)
    {
        case RestoreDefaults:
            GET_CONFIG_PARAM( ZXY110_CI_DEVICE_MODE, zxy110initState.zxy100DevMode );
            GET_STATUS_VAL(ZXY110_SI_SCAN_FREQ,      zxy110initState.scanFreqKHz);

            setProposal.touchCountLimit = 1;
            if (zxy110initState.zxy100DevMode > 1)
            {
                setProposal.touchCountLimit = zxy110initState.zxy100DevMode;
            }

            // ZXY110 is a special case because it takes much longer to return from restore
            // defaults because it is running SearchAllDigitalPotSteps.

            partialRestoreFactorySettings();

            break;

        case RestoreSettings:
            partialRestoreFactorySettings();
            break;

        case NotifyChgSens100:
            state.touchSeqLoc = 0;
            state.currentPointIndex = TouchSequence[state.touchSeqLoc];
            break;

        case EqualizeSensor:
            // turn off touch events for this process
            setProposal.pseudoUpperThr = 55;       // Magic

            zul_inhibitFlashWrites(true);
            SET_CONFIG_PARAM(ZXY110_CI_GLASS_THICKNESS, setProposal.glassThickness);
            {
                // set to 50 to test Failed_Noise handling, and over-press at GT=2
                // release setting is 100!
                int threshold = 100 - DebugText * 50;
                SET_CONFIG_PARAM(ZXY110_CI_UPPER_THRESHOLD, threshold    );
                SET_CONFIG_PARAM(ZXY110_CI_LOWER_THRESHOLD, threshold - 1);
            }

            zul_inhibitFlashWrites(false);

            if (zxy110initState.scanFreqKHz == 0)
            {
                GET_STATUS_VAL(ZXY110_SI_SCAN_FREQ, zxy110initState.scanFreqKHz);
                GET_STATUS_VAL(ZXY110_SI_DIGITAL_POT_VALUE, zxy110initState.digitalPotValue);
                basicSetupLog->Write2LogF(  "%s Freq %dkHz @ %d",  __FUNCTION__,
                                zxy110initState.scanFreqKHz, zxy110initState.digitalPotValue);
            }

            touchData.numAboveThresh = 0;
            touchData.numBelowThresh = 0;

            zul_forceEqualisation();

            /* ToDo: Also, we need to deal with the possibility that controller is in FirstTouchMode
             * which makes the time to run SearchAllDigitalPotSteps even longer .... discuss.
             */

            wipeTouchSamples();
            state.touchStateCount = 0;

            break;

        case GetTouch:
            state.touchSeqLoc++;
            wipeTouchSamples();

            /* This handler will be reset with zul_setRawDataHandler() when done.
             * Reset required for touch-to-exit, rawview, etc.
             */
            zul_SetSpecialHandler( RAW_DATA, handle_IN_rawdata_110_Clipped );
            zxy100Data->enableRawDataCapture(true);
            break;

        case ReleaseTouch:
            wipeTouchSamples();
            touchData.numAboveThresh = 0;
            touchData.numBelowThresh = 0;
            break;

        case Confirm:
            // NOT USED !!
            break;

        case Finished:
            applySettings();
            zul_forceEqualisation();
            break;

        case Failed_NoTouch:
        case Failed_NoRelease:
        case Failed_CommsError:
        case Failed_Noise:
            break;

        case LastState:
            // halt state progression
            basicSetupLog->Write2LogF("BS TickStop");
            fastTick->stop();
            break;

        default:
            basicSetupLog->Write2LogF(  "%s UNEXPECTED STATE [%d] %s ##### \n",
                                        __FUNCTION__, state.panelState, getStateCStr() );
    }
}


/**
 * The ZXY110 is one odd controller:
 */
void SetupSensDialog_110::changeStateWhenRestoreDone(void)
{
    // start checking for FTM status 3 seconds into this state
    if (state.timeout < (getStateTO() - 3*TICKS_PER_SECOND))
    {
        // the process takes a variable time ... so we look for a stable state
        GET_STATUS_VAL( ZXY110_SI_FTM_STATUS, controllerFirstTouchModeStatus );

        // ZXY110 only moves out of factoryDefault state when stable

        // (controllerFirstTouchModeStatus == 0) might be preferred - DISCUSS.
        if (controllerFirstTouchModeStatus != 1)
        {
            changeState(scNormal);
        }
        else
        {
            if (state.timeout < 30)
            {
                state.panelState = Failed_Noise;
                state.timeout = 3 * TICKS_PER_SECOND;
            }
        }
    }
}

/**
 *
 */
int SetupSensDialog_110::getSignalLevel(void)
{
    zxy100Data->getNewRawData();

    return zxy100Data->getRawDataMinOfMaxs();
}
void SetupSensDialog_110::getSignalLocation(uint16_t *tp_x, uint16_t *tp_y)
{
    *tp_x = zxy100Data->getXIndexforRawMax();
    *tp_y = zxy100Data->getYIndexforRawMax();
}

/**
 */
void SetupSensDialog_110::haltRawData()
{
    if (zxy100Data) zxy100Data->enableRawDataCapture(false);
}

/**
 * long running process fired by timer -- ZXY110 specific
 * this activity is processed in a isolated thread - so GUI continues as it should
 */
void SetupSensDialog_110::zxy110RestoreDefault()
{
    int numTch = zxy110initState.zxy100DevMode;

    if (zxy110IsRestoringToDefaults) return;
    zxy110IsRestoringToDefaults = true;
    basicSetupLog->Write2LogF( "%s -- %s", __FUNCTION__, "START");
    zul_restoreDefaults();  // ... takes a LONG time ...
    basicSetupLog->Write2LogF( "%s -- %s", __FUNCTION__, "DONE!" );
    zxy110IsRestoringToDefaults = false;

    if (( numTch >= 0) && (numTch < 3)) // overkill?
    {
        SET_CONFIG_PARAM( ZXY110_CI_DEVICE_MODE, numTch );
    }

    disconnect(zxy110RestoreDefaultTimer, 0,0,0 );
    delete zxy110RestoreDefaultTimer;
    zxy110RestoreDefaultTimer = NULL;
}

/**
 * protect a MaxTouches setting when users run "Basic Config"
 */
void SetupSensDialog_110::partialRestoreFactorySettings()
{
    basicSetupLog->Write2Log( __FUNCTION__ );

        // Discussion needed with firmware team:
        //  "Also, we need to deal with the possibility that controller is in FirstTouchMode
        //   which makes the time to run SearchAllDigitalPotSteps even longer"

        // Firmware should reply to the restore to defaults when that process is complete - like the other devices!!
        // if there is a following activity, 'SearchAllDigitalPotSteps' it should be visible through a status flag/bit.

    // create the ZXY110 restore default timer
    if (zxy110RestoreDefaultTimer == NULL)
    {
        zxy110RestoreDefaultTimer = new QTimer(this);
    }
    else
    {
        disconnect(zxy110RestoreDefaultTimer, 0,0,0 );
    }

    zxy110RestoreDefaultTimer->setSingleShot(true);
    connect(zxy110RestoreDefaultTimer, SIGNAL(timeout()), this, SLOT(zxy110RestoreDefault()));

    // start when there are no more events to process
    zxy110RestoreDefaultTimer->start(50);
}

bool SetupSensDialog_110::errorEventsOccurred(void)
{
    uint16_t    controllerValue;
    bool        errorOccurred = false;

    // If any of the following detected the process is deemed to have failed => Exit reporting noise
    //      see windows BasicSetup_ZXY110, checkstate() ~ line 170:
    //      if ((eState >= States.CHANGING_GLASS_THICKNESS) && (eState < States.UPDATING_CONTROLLER)) {}

    switch (state.panelState)
    {
        default:
            return false;

        case GetTouch:
        case ReleaseTouch:
        case EqualizeSensor:
            break;
    }

    if ((state.panelState == EqualizeSensor) && (controllerFirstTouchModeStatus == 1))
    {
        // statusValue = touchController.GetStatusValue((byte)ZXY110.StatusValueIds.STATUS_VALUE_ID__SCAN_FREQ);
        // decimal scanFrequency = statusValue.Value;
        // scanFrequency /= 1000;
        // scanFrequency = Decimal.Round(scanFrequency, 2);
        // vShowGuidanceString("Testing scan frequency: " + scanFrequency.ToString() + "MHz\n\n\nDO NOT TOUCH THE SENSOR\nTimeout in " + TimeLeft.ToString(), Color.Red);

        firstTouchModeTimer++;
        if ( firstTouchModeTimer > firstTouchModeTimeout )
        {
            errorOccurred = true;
        }

        return errorOccurred;
    }

    // these per second fetches are too verbose for logging with GET_STATUS_VAL()

    zul_getStatusByID ( ZXY110_SI_NUM_TOUCH_SINCE,      &controllerValue );
    if (controllerValue > 0)
    {
        basicSetupLog->Write2Log( "___ TOUCH Error Detected ___ Halting Process ___" );
        errorOccurred = true;
    }

    zul_getStatusByID ( ZXY110_SI_NUM_FTM_ACTIVATIONS,  &controllerValue );
    if (controllerValue > 0)
    {
        basicSetupLog->Write2Log( "___ FTM Error Detected ___ Halting Process ___" );
        errorOccurred = true;
    }

    zul_getStatusByID ( ZXY110_SI_NUM_FREQ_HOPPED,      &controllerValue );
    if (controllerValue > 0)
    {
        basicSetupLog->Write2Log( "___ FREQ Error Detected ___ Halting Process ___" );
        errorOccurred = true;
    }

    zul_getStatusByID ( ZXY110_SI_FTM_STATUS,           &controllerValue );
    if (controllerValue > 0)
    {
        basicSetupLog->Write2Log( "___ FTM STATE Detected ___ Halting Process ___" );
        errorOccurred = true;
    }

    return errorOccurred;
}
