/*
 *      Widget to display the wirelevels from the controller as collected
 *      when the controller is in raw mode.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <QtWidgets>
#include "WireLevelDisplay.h"
#include "ZytMath.h"

//defines used for scaling the widget
#define MAX_VAL     (255)
#define WIRE_WIDTH  (2)

WireLevelDisplay::WireLevelDisplay(QWidget *parent) : QFrame(parent)
{
    m_parent = parent;
    setFrameShape(QFrame::StyledPanel);
    setBackgroundRole(QPalette::Button);

    //Set a reasonable minimum size
    setMinimumWidth(WLD_MIN_WIDTH);
    setMinimumHeight(WLD_MIN_WIDTH*2/3);

    //set widget to prefer to be square
    QSizePolicy square = QSizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
    setSizePolicy(square);

    setDefaults();

    // set threshold flag initial values
    upperThresholdBroken = false;
    lowerThresholdBroken = true;
    toggleThresholdBolding = true;
    clearMovingAvgs();
}

void WireLevelDisplay::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    QPen upperThreshPen,lowerThreshPen;
    QPen wirePen = QPen(QColor(255, 128, 0));
    int width = size().width();
    int height = size().height();

    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::white);
    painter.drawRect(0, 0, width, height);

    painter.setBrush(Qt::NoBrush);

    //scale widget so we can use values provided from controller without
    //having to manipulate them
    painter.scale((float)width / MAX_VAL, (float)height / MAX_VAL);

    int maxWireLevelX = 0, maxWireLevelY = 0;

    float xWireSpacing = findSpacing(xWires);
    wirePen.setWidth(min(WIRE_WIDTH, round(xWireSpacing)));
    painter.setPen(wirePen);

    for(int i = 0; i < xWires.size(); i++)
    {
        if(maxWireLevelX < xWires[i])
        {
            maxWireLevelX = xWires[i];
        }

        if (xWires[i]>0)
        {
            int linePos = findLinePosition(i, xWireSpacing);
            painter.drawLine(linePos, 0, linePos, xWires[i]);
        }
    }

    float yWireSpacing = findSpacing(yWires);
    wirePen.setWidth(min(WIRE_WIDTH,(round(yWireSpacing))));
    painter.setPen(wirePen);

    for(int i = 0; i < yWires.size(); i++)
    {
        if(maxWireLevelY < yWires[i])
        {
            maxWireLevelY = yWires[i];
        }

        if (yWires[i]>0)
        {
            int linePos = findLinePosition(i, yWireSpacing);
            painter.drawLine(0, linePos, yWires[i], linePos);
        }
    }

    updateMovingAvgs(maxWireLevelX, maxWireLevelY);

    // Do the thresholds
    if ( (maxWireLevelX > upperThreshold) && (maxWireLevelY > upperThreshold) )
    {
        upperThresholdBroken = true;
        lowerThresholdBroken = false;
    }

    if ( (maxWireLevelX < lowerThreshold) ||  (maxWireLevelY < lowerThreshold) )
    {
        lowerThresholdBroken = true;
        upperThresholdBroken = false;
    }

    // If we have a threshold set, draw it
    if ((lowerThreshold + upperThreshold) > 0)
    {
        // See if we need to switch pen styles due to the threshold state
        if (upperThresholdBroken)
        {
            upperThreshPen = QPen(Qt::red);
            upperThreshPen.setStyle(Qt::DashLine);

            lowerThreshPen = QPen(Qt::blue);
            lowerThreshPen.setStyle(Qt::SolidLine);
        }
        else
        {
            upperThreshPen = QPen(Qt::blue);
            upperThreshPen.setStyle(Qt::SolidLine);

            lowerThreshPen = QPen(Qt::red);
            lowerThreshPen.setStyle(Qt::DashLine);
        }

        painter.setPen(upperThreshPen);
        painter.drawLine(1, upperThreshold, MAX_VAL-1, upperThreshold);
        painter.drawLine(upperThreshold, 1, upperThreshold, MAX_VAL-1);

        painter.setPen(lowerThreshPen);
        painter.drawLine(1, lowerThreshold, MAX_VAL-1, lowerThreshold);
        painter.drawLine(lowerThreshold, 1, lowerThreshold, MAX_VAL-1);
    }

    QFont myFont = painter.font();
    myFont.setPointSizeF(3.0);
    myFont.setWeight(QFont::Light);
    painter.setFont(myFont);
    lowerThreshPen.setStyle(Qt::SolidLine);
    painter.setPen(lowerThreshPen);

    QString s1, s2, s3, s4, n1, n2, n3, n4;
    s1 = QString("The red line represents the Activation Threshold (%1)").arg(upperThreshold);
    s2 = QString("The blue line represents the Deactivation Threshold (%1)").arg(lowerThreshold);
    s3.sprintf("X signal maximum = %03d; Y signal maximum = %03d", maxWireLevelX, maxWireLevelY );
    s4.sprintf("X-Max average = %03d;  Y-Max average = %03d", getMovingAvgX(), getMovingAvgY());

    const int boxLeft = 134;
    painter.drawText ( boxLeft+3, 228, s1);
    painter.drawText ( boxLeft+3, 236, s2);
    painter.drawText ( boxLeft+3, 244, s3);
    painter.drawText ( boxLeft+3, 252, s4);

    lowerThreshPen.setColor(Qt::black);
    painter.setPen(lowerThreshPen);
    painter.drawRect ( boxLeft, 220, 255-boxLeft-1, 255-221);

    // QFrame::paintEvent(event);
}


void WireLevelDisplay::setDefaults()
{
    upperThreshold = 00;
    lowerThreshold = 00;
}


int WireLevelDisplay::findLinePosition(const int index, const float spacing)
{
    return round(((index + 1) * 2 * spacing) - (spacing / 2));
}


float WireLevelDisplay::findSpacing(const QVector<int> wires)
{
    return ((float)MAX_VAL / ((wires.size() * 2) + 1));
}

void WireLevelDisplay::setWireLevels(const QVector<int> xWireLevels, const QVector<int> yWireLevels)
{
    xWires = xWireLevels;
    yWires = yWireLevels;
    update();
}

void WireLevelDisplay::setThresholds(const int upper, const int lower)
{
    upperThreshold = upper;
    lowerThreshold = lower;
    update();
}

void WireLevelDisplay::clearMovingAvgs(void)
{
    int i;
    movingAvgLoc = 0;
    xMovingSum = 0;
    yMovingSum = 0;
    for (i=0; i<MOVING_AVG_LEN; i++)
    {
        xMaxValues[i] = yMaxValues[i] = 0;
    }
}

void WireLevelDisplay::updateMovingAvgs(int a, int b)
{
    xMovingSum -= xMaxValues[movingAvgLoc];
    yMovingSum -= yMaxValues[movingAvgLoc];

    xMaxValues[movingAvgLoc] = a;
    yMaxValues[movingAvgLoc] = b;

    xMovingSum += a;
    yMovingSum += b;

    movingAvgLoc++;
    movingAvgLoc %= MOVING_AVG_LEN;
}

int WireLevelDisplay::getMovingAvgX(void)
{
    return xMovingSum / MOVING_AVG_LEN;
}

int WireLevelDisplay::getMovingAvgY(void)
{
    return yMovingSum / MOVING_AVG_LEN;
}
