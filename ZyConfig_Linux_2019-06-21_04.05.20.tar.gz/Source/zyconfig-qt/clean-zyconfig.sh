#!/bin/bash
rm -rf Makefile
rm -rf tmpObj
rm -rf moc_*
rm -rf *~
rm -rf ZyConfig
rm -rf TouchTest
if [ "$1" == "zys" ]; then
    yes | rm -f *.zys
    yes | rm -f *.txt
fi
