/*
 *      Present the ZXY100 wire values. This implementation replaces
 *      the WireLevelDisplay class.  (started Feb 2015 - CFM)
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


/*  Z1_RawImageWindow
    ================

  This class provides a real-time graphic of the data detected by the sensor,
  which is used to feed the touch detection algorithms.
*/

#define MARK_PACKETS            (0)     // diagnostic aid
#define COPY_TO_FILE            (0)     // diagnostic aid
#define USE_QIMAGE_PAINT        (0)     // alternative repaint method
#define FRAME_PERIOD_MS         (100)   // TBC


// set to true to observe some status/progress messages on stderr
static const int    DebugText  = 0;

#include <stdio.h>
#include <unistd.h>
#include <QtWidgets>
#include <QScreen>
#include <QClipboard>

#include "dbg2console.h"
#include "zytypes.h"
//#include "comms.h"
#include "zxy100.h"
#include "zxy110.h"
#include "services.h"
#include "debug.h"

#include "Z1_RawImageWindow.h"
#include <time.h>
#include <sys/timeb.h>

/**
 * Constructor
 */
Z1_RawImageWindow::Z1_RawImageWindow(QWidget *parent) :
    QDialog(parent)
{
    Title       = QString(tr("Test Sensor"));
    exitStr     = QString(tr("Press any key to exit"));

    xAxisTitle = new QLabel("X-Axis Wires");
    xAxisTitle->setStyleSheet("QLabel { color : blue; }");
    yAxisTitle = new QLabel("Y-Axis Wires");
    yAxisTitle->setStyleSheet("QLabel { color : blue; }");

    numXWires   = 0;
    numYWires   = 0;
    cellCount   = 0;
    running     = false;
    drawResize  = false;

    // Create Widgets
    wireLevelDis = new WireLevelDisplay(this);
    wireLevelXLabels = new WireLevelXLabels(this);
    wireLevelYLabels = new WireLevelYLabels(this);

    dumpFile    = NULL;
    modeBitField= 0;
    msToRun     = 600000;   // 10 minute maximum runtime

#if (COPY_TO_FILE)
    dumpFile    = fopen("./dump.bin", "w");
#else
    dumpFile    = NULL;
#endif

    //create raw data polling timer
    frameTimer = new QTimer(this);
    QObject::connect(frameTimer,SIGNAL(timeout()), this,SLOT(monitor()));

    setLayout(createLayout());
}

QLayout * Z1_RawImageWindow::createLayout()
{
    QHBoxLayout *mainLayout = new QHBoxLayout;

    mainLayout->addSpacing(50);
    mainLayout->addLayout(createLeftLayout());
    mainLayout->addSpacing(50);

    return mainLayout;
}

QGridLayout * Z1_RawImageWindow::createLeftLayout()
{
    QGridLayout *leftLayout = new QGridLayout();

    leftLayout->addWidget(xAxisTitle, 0, 2);
    leftLayout->addWidget(wireLevelXLabels, 1, 2);
    leftLayout->addWidget(wireLevelYLabels, 2, 1);
    leftLayout->addWidget(yAxisTitle, 2, 0);
    leftLayout->setAlignment(yAxisTitle, Qt::AlignTop);
    leftLayout->addWidget(wireLevelDis, 2, 2);
    leftLayout->setSpacing(0);

    // wireLevelDis->setVisible(false);

    return leftLayout;
}



/**
 * Key Handlers
 */
void Z1_RawImageWindow::keyPressEvent(QKeyEvent *event)
{
    if ((event->key() != Qt::Key_Escape))
    {
        //if (DebugText) fprintf(stderr, "\tStopTick\n");
        frameTimer->stop();

        accept();
    }

    if ((event->key() == Qt::Key_Escape))
    {
        if (DebugText)
        {
            fprintf(stderr, "Process cancelled, esc pressed\n");
            fprintf(stderr, "\tStopTick\n");
        }
        frameTimer->stop();

        reject();
    }
}
void Z1_RawImageWindow::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        if (DebugText) fprintf(stderr, "YouReleasedEsc");
    }
}

/**
 *
 */
void Z1_RawImageWindow::dumpToFile(void)
{
    if (dumpFile == NULL) return;
}

/**
 *
 */
void Z1_RawImageWindow::setDimensions(uint16_t pid,
                                            uint16_t width, uint16_t heigth)
{
    if (!running)
    {
        numXWires = width;
        numYWires = heigth;
        cellCount = numXWires * numYWires;
    }
    devPID = pid;
    switch (devPID)
    {
        case ZXY100_PRODUCT_ID:
            Title       = QString(tr("Test Sensor - ZXY100"));
            break;
        case ZXY110_PRODUCT_ID:
            Title       = QString(tr("Test Sensor - ZXY110"));
            break;
    }
}


/**
 *  *
 *   */
void Z1_RawImageWindow::setMsToRun(long msTimeout)
{
        msToRun = msTimeout;
}

/**
 *
 */
void Z1_RawImageWindow::readThresholds()
{
    uint16_t upperThresh = 21;
    uint16_t lowerThresh = 19;

    if (devPID == ZXY100_PRODUCT_ID)
    {
        zul_getConfigParamByID(ZXY100_CI_UPPER_THRESHOLD, &upperThresh);
        zul_getConfigParamByID(ZXY100_CI_LOWER_THRESHOLD, &lowerThresh);
        xFlip = yFlip = xySwap = false;
    }
    else
    {
        zul_getConfigParamByID(ZXY110_CI_INVERT_X, &lowerThresh);
        xFlip = (lowerThresh > 0);
        zul_getConfigParamByID(ZXY110_CI_INVERT_Y, &lowerThresh);
        yFlip = (lowerThresh > 0);
        zul_getConfigParamByID(ZXY110_CI_SWAP_XY,  &lowerThresh);
        xySwap = (lowerThresh > 0);

        zul_getConfigParamByID(ZXY110_CI_UPPER_THRESHOLD, &upperThresh);
        zul_getConfigParamByID(ZXY110_CI_LOWER_THRESHOLD, &lowerThresh);
    }

    wireLevelDis->setThresholds(upperThresh, lowerThresh);
}


/**
 *
 */
void Z1_RawImageWindow::setAdvancedMode(int bitField)
{
    modeBitField = bitField;
}


/**
 * allow for per-second stats calculations
 */
void Z1_RawImageWindow::monitor()
{
    struct timeb now;
    ftime(&now);
    long msTimePassed = ( now.time - startTime.time ) * 1000;
    msTimePassed += ( now.millitm - startTime.millitm );
    long lastPacketAgeMS = zul_getRawInAgeMS();

    if (lastPacketAgeMS > 500)
    {
        fprintf(stderr, "Raw data stream has been lost [%ldms]\n", lastPacketAgeMS );
        QApplication::postEvent(this , new QKeyEvent(QEvent::KeyPress, Qt::Key_Escape, Qt::NoModifier));
    }

    if (msTimePassed > msToRun)
    {
        fprintf(stderr, "Requested time has elapsed\n");
        QApplication::postEvent(this , new QKeyEvent(QEvent::KeyPress, Qt::Key_Escape, Qt::NoModifier));
    }

    if (!running)
    {
        fprintf(stderr, "Z1_RawImageWindow - data transfers NOT RUNNING !!!! \n ");
        return;
    }

    // use the latest packets from the controller
    updateView();

    if (dumpFile != NULL) dumpToFile();

    zul_logf(3-TIMING_DEBUG, "%d:Frame %04d\n",     // DebugText
                USE_QIMAGE_PAINT, frameIndex);
}


void Z1_RawImageWindow::updateView()
{
    static int callCount = 0;
    unsigned int i;
    QVector<int> xValues;
    QVector<int> yValues;

    switch ( devPID )
    {
        case ZXY100_PRODUCT_ID:

            for(i = 0; i < numXWires; i++)
            {
                // All ZXY100s have the same number of X and Y wires.
                xValues.append(rawImage100.wireSig[i]);
                yValues.append(rawImage100.wireSig[i + numXWires]);
            }


            break;
        case ZXY110_PRODUCT_ID:

            for(i = 0; i < numXWires; i++)
            {
                // All ZXY110s have the same number of X and Y wires.
                if (xySwap)
                {
//                    yValues.append(rawImage110.wireSig[i]);
//                    xValues.append(rawImage110.wireSig[i + numXWires]);


                    if (xFlip)
                    {
                        xValues.append(rawImage110.wireSig[numXWires * 2 - 1 - i]);
                    }
                    else
                    {
                        xValues.append(rawImage110.wireSig[i + numXWires]);
                    }
                    if (yFlip)
                    {
                        yValues.append(rawImage110.wireSig[numXWires - 1 - i]);
                    }
                    else
                    {
                        yValues.append(rawImage110.wireSig[i]);
                    }
                }
                else
                {
                    if (xFlip)
                    {
                        xValues.append(rawImage110.wireSig[numXWires - 1 - i]);
                    }
                    else
                    {
                        xValues.append(rawImage110.wireSig[i]);
                    }
                    if (yFlip)
                    {
                        yValues.append(rawImage110.wireSig[numXWires * 2 - 1 - i]);
                    }
                    else
                    {
                        yValues.append(rawImage110.wireSig[i + numXWires]);
                    }
                }
            }

            break;
        default:
            //error
            break;
    }

    wireLevelDis->setWireLevels(xValues, yValues);
    wireLevelXLabels->setWireLevels(xValues);
    wireLevelYLabels->setWireLevels(yValues);

    // refresh the display
    update();
    frameIndex++;

    if (callCount++ % 40)
    {
        readThresholds();
    }
}


void Z1_RawImageWindow::resizeEvent(QResizeEvent* event)
{
    drawResize = true;

    if (DebugText)
    {
        fprintf(stderr, "NewSize %d,%d\n", event->size().width(), event->size().height() );
    }
}

/**
 *  Test drawing at 800x600 and 1280x1024, ... and ... ?
 */
void Z1_RawImageWindow::paintEvent(QPaintEvent*)
{
    QPainter                painter(this);

    if (drawResize == true)
    {
        drawResize = false;

        if (modeBitField & Z1_RawImageWindow::FlagBrightBackground)
        {
            painter.fillRect(rect(), Qt::white);  // light grey
        }
        else
        {
            painter.fillRect(rect(), QColor ( 30, 30, 30 ));  // dark grey
        }
    }
}

/**
 *  Launch point for Dialog
 */
int Z1_RawImageWindow::exec()
{
    int  ret = QDialog::Accepted;
    ftime(&startTime);

    if (cellCount == 0)
    {
        // signal some fault - user must call setDimensions()
        fprintf(stderr, "User must call setDimensions() before running ...\n");
        return QDialog::Rejected;
    }

    drawResize      = true;
    frameIndex      = 0;

    readThresholds();       // update the wireLevel thresholds

    setWindowTitle(Title + " - " + tr("Press 'ESC' to exit"));
    setModal(true);
    raise();
    activateWindow();
    showMaximized();

    wireLevelDis->clearMovingAvgs();

    // these two calls remove the auto-clear service of normal update()
    //setAttribute(Qt::WA_OpaquePaintEvent);
    //setAttribute(Qt::WA_NoSystemBackground);

    this->setModal(true);

    frameTimer->setInterval(FRAME_PERIOD_MS);
    frameTimer->start();

    switch ( devPID )
    {
        case ZXY100_PRODUCT_ID:
            rawImage100.sensorSz.xWires = numXWires;
            rawImage100.sensorSz.yWires = numYWires;
            zul_SetRawDataBuffer( &rawImage100 );
            break;
        case ZXY110_PRODUCT_ID:
            rawImage110.sensorSz.xWires = numXWires;
            rawImage110.sensorSz.yWires = numYWires;
            zul_SetRawDataBuffer( &rawImage110 );
            break;
        default:
            //error
            break;
    }

    zul_SetRawMode(true);
    {
        running = true;
        update();

        // Let the animation run ... escape key exits
        QDialog::exec();
    }
    zul_SetRawMode(false);

    if (dumpFile != NULL)
    {
        fclose(dumpFile);
        dumpFile = NULL;
    }

    ret = QDialog::Accepted;
    frameTimer->stop();
    running = false;

    return ret;
}
