/*
 *      Provide the initial 4 button wizard page
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "InstallWizard.h"
#include "ConfigSaveDialog.h"
#include "ConfigLoadDialog.h"

#include "dbg2console.h"
#include "usb.h"
#include "configfile.h"
#include "sysdata.h"
#include "debug.h"

#define FONT_SIZE   (11)
#define LARGE_FONT  (14)

QTime InstallWizard::buttonPressHoldoff;

InstallWizard::InstallWizard(QWidget *parent) :
    ZytContentFrame(parent)
{
    zul_getDevicePID(&devPID);
    createWidgets();
    setLayout(createLayout());
    buttonPressHoldoff = QTime::currentTime();
    createConnections();
    inhibitLEDPolling = NULL;
}



void InstallWizard::createWidgets()
{
    // items for use if nothing is connected

    connectedLabel = new QLabel("Touchscreen Device Configuration", this);
    connectedLabel->setWordWrap(true);
    connectedLabel->setMinimumHeight ( 30 );
    connectedLabel->setMinimumWidth(STD_LABEL_WIDTH*2);
    connectedLabel->setAlignment(Qt::AlignHCenter);
    QFont font = connectedLabel->font();
    font.setPointSize(FONT_SIZE);
    connectedLabel->setFont(font);

    arrowImage = new QLabel(this);
    arrowPixMap = QPixmap(":/images/prog_arrow.png");
    QSize arrowSz = arrowPixMap.size();
    arrowImage->setMinimumWidth(arrowSz.width ());
    arrowImage->setMinimumHeight(arrowSz.height());
    arrowImage->setAlignment(Qt::AlignHCenter);
    arrowImage->setPixmap(arrowPixMap);
    arrowImage->setMask(arrowPixMap.mask());

    prompt0    = new QLabel(tr("-"));
    QFont fontPmpt = prompt0->font();
    fontPmpt.setPointSize(LARGE_FONT);
    fontPmpt.setWeight(QFont::DemiBold);

    prompt0->setText("1.");
    prompt0->setFont(fontPmpt);

    step0 = new QPushButton(tr("&1. Integration Tests"),this);
    step0->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    step0Label = new QLabel(    tr("Run Integration Tests to verify the\n"
                                "sensor and controller integration."));

    step0Label->setWordWrap(true);
    step0Label->setMinimumWidth(STD_LABEL_WIDTH);

    // ---

    prompt1    = new QLabel(tr("2."));
    prompt1->setFont(fontPmpt);
    step1      = new QPushButton(tr("&2. Basic Setup"),this);
    step1->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    step1Label = new QLabel(    tr("Run Basic Setup and follow the onscreen "
                                "instructions to configure sensitivity "
                                "and sensor orientation."));

    step1Label->setWordWrap(true);
    step1Label->setMinimumWidth(STD_LABEL_WIDTH);

    // ---

    prompt2    = new QLabel(tr("3."));
    prompt2->setFont(fontPmpt);
    step2 = new QPushButton(tr("&3. Calibrate"),this);
    step2->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    step2Label = new QLabel(    tr("Run Calibrate and follow the onscreen "
                                "instructions to calibrate the sensor to "
                                "the display."));
    step2Label->setWordWrap(true);
    step2Label->setMinimumWidth(STD_LABEL_WIDTH);

    // ---

    prompt3    = new QLabel(tr("4."));
    prompt3->setFont(fontPmpt);

    step3      = new QPushButton(tr("&4. Touch Test"),this);
    step3->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    step3Label = new QLabel(    tr("Touch Test to verify the\n"
                                "sensor and controller integration."));
    step3Label->setWordWrap(true);
    step3Label->setMinimumWidth(STD_LABEL_WIDTH);

    enableButtons(true);

}

/**
 * accept the LED polling control boolean, so that this class can then stop polling
 * the controller for LED status values.
 * The benefit is to reduce the comms when basic-setup and integration tests are
 * running (full screen => no need for LED updates).
 */
void InstallWizard::setLEDPoll(bool *inhibit)
{
    // remember the address of the flag
    inhibitLEDPolling = inhibit;
}

/** These strings are used in the generation of the Integration Test
 * clip-board report
 */
void InstallWizard::setAppVersionStrs(QString &appVerStr)
{
    z2integTests.setAppVersionStrs(appVerStr);
    // localCopyAVI = appVerStr;
}

/**
 * Accept the app's zxy100Data instance for re-use by
 * Integration-Test and Basic-Setup
 */
void InstallWizard::setZXY100Data(Zxy100Data *dd)
{
    zxy100Data = dd;        // remember for setupSens100 & setupSens100 created later
    z2integTests.setZXY100Data(dd);
}

QLayout * InstallWizard::createLayout()
{
    const int pSpace = 30;
    QHBoxLayout *arrowLayout = new QHBoxLayout;

    QVBoxLayout *mainLayout = new QVBoxLayout;

    QVBoxLayout *connLayout = new QVBoxLayout;
    QHBoxLayout *step0Layout = new QHBoxLayout;
    QHBoxLayout *step1Layout = new QHBoxLayout;
    QHBoxLayout *step2Layout = new QHBoxLayout;
    QHBoxLayout *step3Layout = new QHBoxLayout;

    connLayout->addWidget(connectedLabel);
    connLayout->setAlignment(connectedLabel, Qt::AlignCenter);

    step0Layout->addStretch();
    step0Layout->addWidget(prompt0);
    step0Layout->setAlignment(prompt0, Qt::AlignTop);
    step0Layout->addSpacing(pSpace);
    step0Layout->addWidget(step0Label);
    step0Layout->setAlignment(step0Label, Qt::AlignTop);
    step0Layout->addSpacing(pSpace);
    step0Layout->addWidget(step0);
    step0Layout->addStretch();

//    step1Layout->setAlignment(Qt::AlignTop);
    step1Layout->addStretch();
    step1Layout->addWidget(prompt1);
    step1Layout->setAlignment(prompt1, Qt::AlignTop);
    step1Layout->addSpacing(pSpace);
    step1Layout->addWidget(step1Label);
    step1Layout->setAlignment(step1Label, Qt::AlignTop);
    step1Layout->addSpacing(pSpace);
    step1Layout->addWidget(step1);
    step1Layout->addStretch();

//    step2Layout->setAlignment(Qt::AlignTop);
    step2Layout->addStretch();
    step2Layout->addWidget(prompt2);
    step2Layout->setAlignment(prompt2, Qt::AlignTop);
    step2Layout->addSpacing(pSpace);
    step2Layout->addWidget(step2Label);
    step2Layout->setAlignment(step2Label, Qt::AlignTop);
    step2Layout->addSpacing(pSpace);
    step2Layout->addWidget(step2);
    step2Layout->addStretch();

//    step3Layout->setAlignment(Qt::AlignTop);
    step3Layout->addStretch();
    step3Layout->addWidget(prompt3);
    step3Layout->setAlignment(prompt3, Qt::AlignTop);
    step3Layout->addSpacing(pSpace);
    step3Layout->addWidget(step3Label);
    step3Layout->setAlignment(step3Label, Qt::AlignTop);
    step3Layout->addSpacing(pSpace);
    step3Layout->addWidget(step3);
    step3Layout->addStretch();

    mainLayout->addStretch();
    mainLayout->addLayout(connLayout);
    mainLayout->addStretch();
    mainLayout->addLayout(step0Layout);
    mainLayout->addStretch();
    mainLayout->addLayout(step1Layout);
    mainLayout->addStretch();
    mainLayout->addLayout(step2Layout);
    mainLayout->addStretch();
    mainLayout->addLayout(step3Layout);
    mainLayout->addStretch();

    arrowLayout->addStretch();
    arrowLayout->addLayout(mainLayout);
    arrowLayout->addWidget(arrowImage);
    arrowLayout->setAlignment(arrowImage, Qt::AlignVCenter);
    arrowLayout->addStretch();

    return arrowLayout;
}

void InstallWizard::execIntegTestDialog()
{
    if (buttonPressHoldoff.addMSecs(100) < QTime::currentTime()) // stop double clicks
    {
        Monitor selected;

        buttonPressHoldoff = QTime::currentTime();   // TN00031
        enableButtons(false);

        // copy advanced output setting thru' from ZytContentFrame
        z2integTests.setAdvancedMode(getAdvancedMode());

        QString mName = caliDialog.getMonitorForDevice();
        if (mName != NULL)
        {
            monitorSelector.selectByName(mName);
            monitorSelector.getSelectedMonitor ( &selected );
        }

        if (!selected.isValid())
        {
            if (QDialog::Accepted == monitorSelector.exec())
            {
                monitorSelector.getSelectedMonitor(&selected);
                caliDialog.setMonitorForDevice(selected.getName(false));
            }
            else
            {
                // if user cancelled, do nothing
                enableButtons(true);
                buttonPressHoldoff = QTime::currentTime();

                return;
            }
        }

        // fprintf(stderr, "MON:%s\n", selected.getName(false));
        z2integTests.setMonitor(&selected);
        if (NULL != inhibitLEDPolling) *inhibitLEDPolling = true;
        z2integTests.exec();
        if (NULL != inhibitLEDPolling) *inhibitLEDPolling = false;

        enableButtons(true);

        buttonPressHoldoff = QTime::currentTime();
    }
}


void InstallWizard::execSenseDialog()
{
    if (buttonPressHoldoff.addMSecs(100) < QTime::currentTime()) // stop double clicks
    {
        Monitor selected;

        buttonPressHoldoff = QTime::currentTime();   // TN00031
        enableButtons(false);

        QMessageBox infoBox;
        infoBox.setWindowTitle(tr("Basic Setup"));
        QString infoText = QString(
                QObject::tr("This process will instruct you to touch a set of 5 targets at various locations on the sensor.\n\n") +
                QObject::tr("At any point the 'ESC' key will exit the process.\n\n") +

                QObject::tr("There are times in the process when no fingers should be in contact with the sensor, these instructions are indicated with RED text.\n\n") +

                QObject::tr("When you are instructed to touch the sensor, initially place a single finger on the sensor in the centre of target 1 displayed on the screen.") +
                QObject::tr("For the remaining 4 targets slide your finger along the displayed arrows on the screen towards the numbered target and hold on the target "
                   "until instructed to release the touch from the screen.\n\n") );

        if (zxy100Data)
        {
            infoText += QObject::tr("On exit, the touch sensitivity and sensor orientation should be correct.\n\n");
        }
        else
        {
            infoText += QObject::tr("On exit, the touch sensitivity, palm rejection sensitivity and sensor orientation should be correct.\n\n");
        }

        infoText +=
                QObject::tr("All current settings will be lost during this process.");

        infoBox.setText(infoText);
        infoBox.setIcon(QMessageBox::Information);
        infoBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
        infoBox.setModal(true);
        //remove the close button from the dialog if there is one
        Qt::WindowFlags wFlags = infoBox.windowFlags();
        if(Qt::WindowCloseButtonHint == (wFlags & Qt::WindowCloseButtonHint))
        {
            wFlags = wFlags ^ Qt::WindowCloseButtonHint;
            infoBox.setWindowFlags(wFlags);
        }
        infoBox.setDefaultButton(QMessageBox::Ok);

        if(QMessageBox::Ok == infoBox.exec())
        {

            QString mName = caliDialog.getMonitorForDevice();
            if (mName != NULL)
            {
                monitorSelector.selectByName(mName);
                monitorSelector.getSelectedMonitor ( &selected );
            }

            if (!selected.isValid())
            {
                if (QDialog::Accepted == monitorSelector.exec())
                {
                    monitorSelector.getSelectedMonitor(&selected);
                    caliDialog.setMonitorForDevice(selected.getName(false));
                }
                else
                {
                    // if user cancelled, do nothing
                    enableButtons(true);
                    buttonPressHoldoff = QTime::currentTime();

                    return;
                }
            }

            if(selected.getOrientation() != xmo_Normal)
            {
                QMessageBox warningBox;
                warningBox.setWindowTitle(tr("Warning"));
                QString warningText = QString(tr("This feature is only available when the Screen Orientation is 'Landscape'"));
                warningBox.setText(warningText);
                warningBox.setIcon(QMessageBox::Warning);
                warningBox.setStandardButtons(QMessageBox::Ok);
                warningBox.setModal(true);
                warningBox.exec();

                enableButtons(true);
                buttonPressHoldoff = QTime::currentTime();
                return;
            }

            if (NULL != inhibitLEDPolling) *inhibitLEDPolling = true;

            switch (devPID)
            {
                case ZXY100_PRODUCT_ID:
                    setupSensDialog = new SetupSensDialog_100(this);
                    ((SetupSensDialog_100*)setupSensDialog)->setZXY100Data(zxy100Data);
                    setupSensDialog->setMonitor(&selected);
                    setupSensDialog->exec();
                    delete setupSensDialog;
                    break;
                case ZXY110_PRODUCT_ID:
                    setupSensDialog = new SetupSensDialog_110(this);
                    ((SetupSensDialog_110*)setupSensDialog)->setZXY100Data(zxy100Data);
                    setupSensDialog->setMonitor(&selected);
                    setupSensDialog->exec();
                    delete setupSensDialog;
                    break;
                default:        // any MT device
                    setupSensDialog = new SetupSensDialog_MT(this);
                    setupSensDialog->setMonitor(&selected);
                    setupSensDialog->exec();
                    delete setupSensDialog;
                    break;
            }

            if (NULL != inhibitLEDPolling) *inhibitLEDPolling = false;
        }

        zul_log(3, "reReadThresholds @ InstallWizard");
        emit reReadThresholds();
        emit APIResult(ZytAPIResult::Success);

        enableButtons(true);

        buttonPressHoldoff = QTime::currentTime();
    }
}

void InstallWizard::execCaliDialog()
{
    if (buttonPressHoldoff.addMSecs(100) < QTime::currentTime()) // stop double clicks
    {
        buttonPressHoldoff = QTime::currentTime();
        enableButtons(false);

        QString mName = caliDialog.getMonitorForDevice();
        if (mName != NULL)
        {
            monitorSelector.setPreferred(mName);
        }
        if (QDialog::Accepted == monitorSelector.exec())
        {
            Monitor selected;
            monitorSelector.getSelectedMonitor(&selected);
            caliDialog.setMonitor(&selected);

            if(selected.getOrientation() != xmo_Normal)
            {
                QMessageBox warningBox;
                warningBox.setWindowTitle(tr("Warning"));
                QString warningText = QString(tr("This feature is only available when the Screen Orientation is 'Landscape'"));
                warningBox.setText(warningText);
                warningBox.setIcon(QMessageBox::Warning);
                warningBox.setStandardButtons(QMessageBox::Ok);
                warningBox.setModal(true);
                warningBox.exec();

                enableButtons(true);
                buttonPressHoldoff = QTime::currentTime();
                return;
            }

            caliDialog.exec();

            emit reReadAxesReq();
        }

        enableButtons(true);
        buttonPressHoldoff = QTime::currentTime();
    }
}


/**
 * return NULL if device cannot be found
 */
char *InstallWizard::getDevPath(char const * cpuID)
{
    static char devStr[40 + 1];
    int         index = getTouchEventPathIndex(cpuID);

    if (index < 0)
    {
        QMessageBox errorBox;
        errorBox.setWindowTitle( QObject::tr("Find Device") );
        errorBox.setText( QObject::tr("Can't find a Zytronic touchscreen device\n") );
        errorBox.setIcon(QMessageBox::Critical);
        errorBox.setStandardButtons(QMessageBox::Ok);
        errorBox.setModal(true);
        errorBox.exec();
        return NULL;
    }
    else
    {
        sprintf(devStr, "/dev/input/event%d", index);
    }

    if (TOUCH_DEBUG) fprintf(stderr, ">>> %s\n", devStr);
    return devStr;
}


/**
 * Launch the touch test drawing app
 */
bool InstallWizard::getMonName(const char *key, char *monitorName, int len)
{
    // retrieve the controller-monitor binding

    bool retVal = false;
    ZyConfFile *zcf = new ZyConfFile(NULL);
    zcf->ReadFile();
    retVal = zcf->GetString(key, monitorName, len);
    delete zcf;
    return retVal;
}


/**
 * Launch the touch test drawing app
 */
void InstallWizard::execTestDialog()
{
    const char  testApp1[] = "/usr/bin/TouchTest";
    const char  testApp2[] = "./TouchTest";
    char const *testApp = testApp2;
    int         returnValue;

    if (buttonPressHoldoff.addMSecs(100) < QTime::currentTime()) // stop double clicks
    {
        struct stat statBuf;
        char cmd[200+1];

        buttonPressHoldoff = QTime::currentTime();   // TN00031
        enableButtons(false);

        {
            struct stat statBuf;
            if ( stat(testApp, &statBuf) == -1 )
            {
                // if there is no local version, try to use /usr/bin/TouchTest instead
                testApp = testApp1;
            }
        }

        if (NULL != inhibitLEDPolling)
        {
            *inhibitLEDPolling = true;
        }
        emit pauseConnectionCheck(true);
        // disconnect from device so the desktop can generate touch events
        returnValue = zul_closeDevice();
        if (returnValue != 0)
        {
            fprintf(stderr, "%s DEVICE CLOSE error %d\n", __FUNCTION__, returnValue);
        }
        zy_msleep(700);     // allow OS to reconnect and create /dev/input/eventNN

        if ( stat(testApp, &statBuf) == -1 )
        {
            // if there is no /usr/bin/TouchTest, display an error box
            QMessageBox errorBox;
            errorBox.setWindowTitle(tr("Missing File"));
            QString errorText = QString(tr("The application 'TouchTest' could not be found in either of the following locations:\n"));
            errorText += "\n\t";
            errorText += testApp2;
            errorText += "\n\t";
            errorText += testApp1;
            errorText += "\n";
            errorBox.setText(errorText);
            errorBox.setIcon(QMessageBox::Critical);
            errorBox.setStandardButtons(QMessageBox::Ok);
            errorBox.setModal(true);
            errorBox.exec();
        }
        else
        {
            if (TOUCH_DEBUG) fprintf(stderr, "  > %s\n", cmd); // debug aid only

            int exitCode = system(testApp);
            if (exitCode < 0)
            {
                fprintf(stderr, ">>> Touch Test Error : exit code %d\n", exitCode);
                QMessageBox errorBox;
                errorBox.setWindowTitle(tr("Touch Test"));
                errorBox.setText(tr("Error running the test application as root\n"));
                errorBox.setIcon(QMessageBox::Critical);
                errorBox.setStandardButtons(QMessageBox::Ok);
                errorBox.setModal(true);
                errorBox.exec();
            }
        }

        // zy_msleep(500);
        returnValue = zul_reOpenLastDevice();
        if (returnValue != 0)
        {
            fprintf(stderr, "%s DEVICE REOPEN error %d\n", __FUNCTION__, returnValue);
        }
        else
        {
            emit pauseConnectionCheck(false);
            if (NULL != inhibitLEDPolling)
            {
                *inhibitLEDPolling = false;
            }
            enableButtons(true);
        }

        buttonPressHoldoff = QTime::currentTime();
    }
}

void InstallWizard::enableButtons(bool enable)
{
    bool s0 = false, s1 = false;

    switch (devPID)
    {
        default:
            printf("default -- Error in %s", __FUNCTION__ );
            break;

        case ZXY100_PRODUCT_ID:
        case ZXY110_PRODUCT_ID:
            s0=enable;
            s1=enable;
            break;
//        case ZXY110_PRODUCT_ID:
//            s0=enable;
//            s1=false;
//            break;
        case ZXY150_PRODUCT_ID:
        case ZXY200_PRODUCT_ID:
        case ZXY300_PRODUCT_ID:
        case ZXY500_PRODUCT_ID:
        case ZXY500_PRODUCT_ID_ALT1:
            s0=enable;
            s1=enable;
            {
                // if ZXY500 in FAILSAFE - do not allow these services
                uint16_t ledStatus;
                zul_getStatusByID(ZXYMT_SI_STATUS_LEDS, &ledStatus);
                if ( (ledStatus & 0x0400) > 0 )
                {
                    s0=false;
                    s1=false;
                    enable = false;
                }
            }
            break;
    }

    step0->setEnabled(s0);
    step1->setEnabled(s1);
    step2->setEnabled(enable);
    step3->setEnabled(enable);
}


void InstallWizard::createConnections()
{
    /* All connections made here must be broken in reReadValues() ?
     */
    QObject::connect(step0, SIGNAL(clicked()),
                     this, SLOT(execIntegTestDialog()));

    QObject::connect(step1, SIGNAL(clicked()),
                     this, SLOT(execSenseDialog()));

    QObject::connect(step2, SIGNAL(clicked()),
                     this, SLOT(execCaliDialog()));

    QObject::connect(&caliDialog, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                     this, SIGNAL(APIResult(ZytAPIResult::ResultState)));

    QObject::connect(step3, SIGNAL(clicked()),
                     this, SLOT(execTestDialog()));
}
