/*
 *      Generic widget to act as container for pages of the configuration
 *      application. Each page is expected to have a content frame and
 *      a title.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "ZytConfigPage.h"

ZytConfigPage::ZytConfigPage(const QString title, ZytContentFrame *content, QWidget *parent) :
    QWidget(parent)
{
    createWidgets(title);
    contentFrame = content;

    content->setParent(this);

    setLayout(createLayout());
}

ZytConfigPage::ZytConfigPage(QWidget *parent) :
    QWidget(parent)
{
    createWidgets("");
}

void ZytConfigPage::createWidgets(const QString /*unused: title*/)
{
    //titleFrame = new PageTitleFrame(title, this);
}

QLayout * ZytConfigPage::createLayout()
{
    QVBoxLayout *mainLayout = new QVBoxLayout;
    //mainLayout->addWidget(titleFrame);
    mainLayout->addWidget(contentFrame);

    mainLayout->setSpacing(0);
    mainLayout->setMargin(0);

    return mainLayout;
}

void ZytConfigPage::reReadValues()
{
    contentFrame->reReadValues();
}
