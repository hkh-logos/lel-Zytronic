/*
 *      Integration Test class: This code is intended to hold all the
 *      presentation elements of a test, to simplify the test management
 *      in the test execution code.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */



#ifndef INTEGRATIONTEST_H
#define INTEGRATIONTEST_H

#include <QtGui>
#include <QGroupBox>
#include <QLabel>


class IntegrationTest
{
private:    // instance attributes
    int                     yLocation;
    bool                    separator;
    QGroupBox              *gb_Panel;
    QLabel                 *name, *pass, *comment;

    QString                 debugDetail;
    QColor                  textColor;

    QGroupBox               testWidget;


public:
    IntegrationTest(const QString &name, QWidget *parent = 0);
    ~IntegrationTest();

    QString             getName(void);
    void                setLargeFonts(bool large);
    void                setTextLocations(void);
    void                setDebugDetail(const QString &s);
    void                addDebugDetail(const QString &s);
    QString             getDebugDetail(void);

    void                setTestPass(const QString &s);
    void                setTestComment(const QString &s);
    void                setLocation(QPoint topLeft);

    QString             getReportText(void);
    void                appendDebugDetail2Comment(void);
    void                clearDebugDetail(void);
    void                appendDebugDetail(QString s);

protected:


private:    // Class consts
    static const int    Y_INIT         = 50;
    static const int    fieldHeight    = 36;


private:    // Class attributes
    static int          testCount;
    static int          yBase;

private:    // attributes
    QString             fontSz1;
    QString             fontSz2;

};

#endif // INTEGRATIONTEST_H
