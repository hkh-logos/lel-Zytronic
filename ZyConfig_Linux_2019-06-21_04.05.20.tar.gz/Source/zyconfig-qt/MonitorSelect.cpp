/*
 *      Monitor Selection Widget. Select a monitor from the set associated
 *      with (Xorg) screen 0.  This is used when calibrating one of many
 *      Zytronic touchscreens to one of many monitors.
 */

/*
 * Copyright 2019 Zytronic Displays Limited, UK.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


#include <QtWidgets>
#include <QScreen>
#include "MonitorSelect.h"

#include "services.h"
#include "sysdata.h"

MonitorSelect::MonitorSelect(QWidget *parent) : QDialog(parent)
{
    preferred = "notAmonitor";
    monitors.clear();
    Size2d size = {0,0};
    Location location = {0,0};
    XMonitorOrientation orientation = xmo_invalid;
    Screen = new Monitor ("UNDEF", location, size, orientation);

    vLayout = new QVBoxLayout( this );
    hLayout = new QHBoxLayout;

    monitorBox = new QGroupBox( tr("Available Monitors:"), this );
    monitorBGrp = new QButtonGroup( monitorBox );
    bGrpLayout = new QVBoxLayout;

    bGrpLayout ->addStretch(1);     // this item remains, not deleted during UpdateMonitorList
    monitorBox->setLayout(bGrpLayout);
    hLayout->addWidget( monitorBox );

    buttonLayout = new QHBoxLayout;
    selectButton = new QPushButton("Select");
    cancelButton = new QPushButton("Cancel");

    selectButton->setAutoDefault(true);
    selectButton->setDefault(true);
    cancelButton->setAutoDefault(false);
    cancelButton->setDefault(false);

    primaryMsg = new QLabel("'*' indicates primary", this);
    primaryMsg->setIndent(6);

    buttonLayout->addWidget(primaryMsg);
    buttonLayout->addStretch(1);
    buttonLayout->addWidget(selectButton);
    buttonLayout->addWidget(cancelButton);

    vLayout->addLayout(hLayout);
    vLayout->addLayout(buttonLayout);
    // setMinimumSize(400, 200);
    setModal(true);

    this->connect( selectButton, SIGNAL( clicked() ), this, SLOT( accept() ) );
    this->connect( cancelButton, SIGNAL( clicked() ), this, SLOT( reject() ) );

    this->connect( monitorBGrp, SIGNAL( buttonClicked(QAbstractButton *) ),
            this, SLOT( updateDesktop(QAbstractButton *) ) );

    desktopImage = new DesktopImage();
    hLayout->addWidget( desktopImage );

    selected = NULL;
}

void MonitorSelect::updateDesktop(QAbstractButton *b)
{
    // find the monitor that has been selected
    Monitor *mPtr;
    foreach ( mPtr, monitors )
    {
        if ( b->text().contains ( mPtr->getName(false) ) )
        {
            // update the desktopImage with the new selection
            desktopImage->setSelected( mPtr );
            selected = mPtr;
        }
    }
    update();
}

void MonitorSelect::UpdateMonitorList(void)
{
    Monitor *mPtr;
    char primaryMonName[12] = "";
    QRadioButton *button, *first = NULL;

    // clean up monitor list
    foreach ( mPtr, monitors )
    {
        delete mPtr;
    }
    monitors.clear();
    mPtr = NULL;

    // clean up QRadioButtons
    QList<QRadioButton*> rbList = this->findChildren<QRadioButton*>();
    foreach ( button, rbList )
    {
        monitorBGrp->removeButton(button);
        bGrpLayout->removeWidget(button);
        delete button;
    }

    // -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

    int numScrns = getNumberOfScreens();
    if (numScrns < 1)
    {
        return;
    }
    strncpy( primaryMonName, getPrimaryMonitor(0), 12 );
    primaryMonName[11] = '\0';

    Location TopLeft = {0,0};
    Size2d sizeS0 = getScreenSize(0);
    XMonitorOrientation mOrientation = getMonitorOrientation(0, 0);

    // fprintf(stderr, "Screen Size: %d, %d\nOrientation: %d\n", sizeS0.x, sizeS0.y, mOrientation);
    if (Screen != NULL) delete Screen;
    Screen = new Monitor ( "Screen0", TopLeft, sizeS0, mOrientation );
    desktopImage->setOutline( Screen );

    int numMonitors = getNumberOfMonitors(0);
    // fprintf(stderr, "CURRENT preference %s\n", preferred.toLatin1().data() );

    for ( int index=0; index<numMonitors; index++ )
    {
        char mName [14];
        strncpy (mName , getMonitorName(0, index), 12 );

        mName [11] = '\0';
        Location mLocation = getMonitorLocation( 0, index );
        Size2d mSize = getMonitorSize( 0, index );
        mOrientation = getMonitorOrientation( 0, index );
        Monitor *m = new Monitor ( mName, mLocation, mSize, mOrientation );
        if ( 0 == strcmp ( primaryMonName, mName ) )
        {
            m->setPrimary();
            // maintain a pointer to the primary monitor
            Primary = m;
        }
        monitors.append(m);

        button = new QRadioButton( m->getName(true), this );
        monitorBGrp->addButton(button);

        // insert the new buttons just before the permanent 'stretch' item
        bGrpLayout->insertWidget(bGrpLayout->count()-1, button);
        //bGrpLayout->addWidget(button);

        if (first == NULL)
        {
            first = button;
            mPtr = m;
        }
        QString shortName = m->getName(false);
        if (!shortName.compare(preferred))
        {
            // fprintf(stderr, "FOUND preference %s\n", preferred.toLatin1().data() );
            first = button;
            mPtr = m;
        }
    }

    desktopImage->addMonitors( &monitors );
    if (first != NULL)
    {
        first->setChecked( true );
        desktopImage->setSelected( mPtr );
        selected = mPtr;
    }

    update();
}

void MonitorSelect::setPreferred(QString name)
{
    preferred = name;
}

bool MonitorSelect::selectByName(QString name)
{
    UpdateMonitorList();
    // set the selected monitor
    foreach ( Monitor *m, monitors )
    {
        QString  mName = QString (m->getName(false));
        if (mName.contains(name))
        {
            selected = m;
            return true;
        }
    }

    selected = NULL;
    return false;
}

// --- Result Access ---------------------------------------

void MonitorSelect::getSelectedMonitor(Monitor *m)
{
    if ((m != NULL) && (selected != NULL))
    {
        // copy out the data
        *m = *selected;
    }
}

void MonitorSelect::getMonitorListAsRegExp(QRegExp *rExp)
{
    QString str = "(";

    UpdateMonitorList();

    foreach(Monitor *m, monitors)
    {
        str.append(m->getName(false));
        str.append("|");
    }
    str.chop(1);
    str.append(")");

    rExp->setPattern(str);
}
// ---------------------------------------------------------

int MonitorSelect::exec()
{
    int ret = QDialog::Rejected;
    char portStr[10];
    setWindowTitle(tr("Select Monitor for Touchscreeen"));
    if ( SUCCESS == zul_getAddrStr(portStr))
    {
        setWindowTitle(tr("Select Monitor for Touchscreeen at USB address ") + QString(portStr));
    }

    UpdateMonitorList();

    if (monitors.size() == 1)
    {
        // fprintf(stderr, "ONE MONITOR - SKIP\n");
        accept();       // don't delay if there is one monitor!
        ret = QDialog::Accepted;
    }
    else
    {
        activateWindow();
        //cancelButton->setFocus();
        selectButton->setFocus();
        update();

        ret = QDialog::exec();
    }
    // clear preference
    preferred = "notAmonitor";

    // see 'selected' monitor for users choice
    return ret;
}
