/*
 *      Content of the axes controls tab
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef AXISOPTIONSFRAME_H
#define AXISOPTIONSFRAME_H

#include <QtWidgets>
//#include "CustRadioButton.h"
//#include "CustCheckBox.h"
#include "ZytContentFrame.h"
#include "zytypes.h"

class AxisOptionsFrame : public ZytContentFrame
{
    Q_OBJECT

public:
    AxisOptionsFrame                    (QWidget *parent = 0);

    void            reReadValues        (void);
    void            showOverlay         (void);
    void            hideOverlay         (void);

protected:
    virtual bool    event               (QEvent *event);

private slots:
    void            controlYXaxis       (void);
    void            crossCouple         (void);
    void            swapXYaxes          (void);

private:
    void            createWidgets       (void);
    void            readFromController  (void);
    void            createConnections   (void);

    QLayout         *createLayout       (void);

    QPushButton     *swapXY;
    QPushButton     *invertX;
    QPushButton     *invertY;

    QCheckBox       *swapXYind;
    QCheckBox       *invXind;
    QCheckBox       *invYind;

    QLabel          *xFlipLabel;
    QLabel          *yFlipLabel;
    QLabel          *xySwapLabel;

    int16_t         devPID;

    uint8_t         FX;
    uint8_t         FY;
    uint8_t         SXY;

/*
    QLabel *xOverlay;
    QLabel *yOverlay;
    QLabel *xyOverlay;  */
};

#endif
