/*
 *      Load the Configuration Parameters from a ZYS file to the controller.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <QtWidgets>
#include "ConfigLoadDialog.h"
#include "SysInfoDisplay.h"
#include "ZytContentFrame.h"

//#include "comms.h"
#include "debug.h"
#include "services.h"
#include "protocol.h"
#include "zytypes.h"

ConfigLoadDialog::ConfigLoadDialog(QWidget *parent) :
    QDialog(parent)
{
    setMinimumWidth(500);
    fileName = "";
    forceLoad = false;
    createWidgets();
}

void ConfigLoadDialog::setLocation(QPoint loc)
{
    location = loc;
}


void ConfigLoadDialog::setForce(const QString *name)
{
    if ( ! name->compare("force", Qt::CaseInsensitive))
    {
        forceLoad = true;
    }
}

void ConfigLoadDialog::setFileName(const QString *name)
{
    fileName = *name;
}


void ConfigLoadDialog::createWidgets(void)
{
    this->setWindowTitle(tr("Load Configuration"));

    textLabel = new  QLabel(this);
    textLabel->setText(tr("Loading configuration file: ..."));
    textLabel->setMinimumWidth(480);

    progressBar = new QProgressBar(this);
    progressBar->setRange(0, 100);
    progressBar->setFixedWidth(280);

    this->setLayout(createLayout());
}


QLayout * ConfigLoadDialog::createLayout()
{
    QVBoxLayout *mainLayout = new QVBoxLayout;

    mainLayout->addStretch();
    mainLayout->addWidget(progressBar);
    mainLayout->setAlignment(progressBar, Qt::AlignCenter);
    mainLayout->addStretch();
    mainLayout->addWidget(textLabel);
    mainLayout->addStretch();

    return mainLayout;
}


int ConfigLoadDialog::exec()
{
    QString     selectedFileName;
    QFileDialog getFileNameDialog(this, tr("Select File to send to controller"));

    getFileNameDialog.setNameFilter(tr("ZYS Zytronic Settings Files (*.zys)"));
    getFileNameDialog.setDirectory(QDir::currentPath());
    QSize dSize = getFileNameDialog.sizeHint();
    QRect r = QRect (location + QPoint(10, 40), dSize);
    getFileNameDialog.setGeometry( r );

    progressBar->setValue(0);

    if (fileName.length() == 0)
    {

        if ( getFileNameDialog.exec() )
        {
            selectedFileName = getFileNameDialog.selectedFiles().at(0);
        }
        else
        {
            return QDialog::Rejected;
        }

    }
    else
    {
        selectedFileName = fileName;
    }

    {
        QStringList commands;
        char deviceNameInFile[40+1] = "";
        int x;
        bool loadData = true;
        emit APIResult(ZytAPIResult::Progress);

        showNormal();
        raise();
        activateWindow();

        textLabel->setText(tr("Reading from ") + selectedFileName);
        this->setModal(true);

        zy_msleep(100);

        zul_logf(3, "LOAD TEST\n");

        const char* cName = ZytContentFrame::toCString(&selectedFileName);
        FILE *fp = fopen( cName, "r");

        if (fp!=NULL)
        {
            QByteArray crcIn("");
            char lineBuffer[180+1];
            char crcFromFile[5] = "", calculatedCRC[5] = "";

            while (fgets(lineBuffer, 180, fp))
            {
                if (!strncmp(lineBuffer, "# Validation", 10))
                {

                    char *p = strrchr(lineBuffer, ' ');
                    if (p!=NULL) strncpy(crcFromFile, p+1, 4 );
                    crcFromFile[4] = '\0';
                    zul_logf(3, "CRC found in file : %s\t\t:%sn", crcFromFile, lineBuffer);
                }

                if ( strstr(lineBuffer, "VERSION") ||
                     strstr(lineBuffer,  "STATUS") ||
                     strstr(lineBuffer,  "#ARVAL") ||
                     strstr(lineBuffer,  "CONFIG") )
                {
                    lineBuffer[180] = '\0';
                    int len = strlen ( lineBuffer );
                    lineBuffer[len-1] = '\0';                   // crop "\n"
                    char c = lineBuffer[len-2];
                    if ( strchr ( "\r\n", c ) )
                    {
                        lineBuffer[len-2] = '\0';               // crop "\r"
                    }
                    crcIn.append(lineBuffer);

                    if (strstr(lineBuffer, "CONFIG"))
                        commands.append(QString(lineBuffer));

                    if (strstr(lineBuffer, "VERSION 02"))
                    {
                        strncpy(deviceNameInFile, lineBuffer+11, 40);
                        deviceNameInFile[40] = '\0';
                        zul_logf(3, "DEVICE NAME: %s\n", deviceNameInFile);
                    }
                    else if (strstr(lineBuffer, "VERSIONS 02")) // zys files saved before version 04.05.10
                    {
                        strncpy(deviceNameInFile, lineBuffer+12, 40);
                        deviceNameInFile[40] = '\0';
                        zul_logf(3, "DEVICE NAME: %s\n", deviceNameInFile);
                    }
                }
            }

            int crc16 = zul_getCRC((unsigned char *)crcIn.constData(), crcIn.length() );
            zul_logf(3, "CRC is based on %d bytes and is %04X", crcIn.length(), crc16 );
            zul_logf(3, "CRC is based on the following string\n%s", crcIn.constData() );

            sprintf( calculatedCRC, "%04X", crc16 );

            zul_logf(3, "\tCRC CHECK\t%s\t%s\n", crcFromFile, calculatedCRC );

            if (! forceLoad)    // if force-load set, do not seek permission to continue
            {
                if ( crcFromFile[0] == '\0' )
                {
                    QMessageBox noCRCLine;
                    noCRCLine.setText(tr("Missing validation check. Do you wish continue?"));
                    noCRCLine.setIcon(QMessageBox::Warning);
                    noCRCLine.setStandardButtons (QMessageBox::Ok | QMessageBox::Cancel);
                    noCRCLine.setDefaultButton (QMessageBox::Cancel);
                    if (noCRCLine.exec() == QMessageBox::Cancel)
                        loadData = false;
                }
                else
                {
                    if ( strcmp(crcFromFile, calculatedCRC) )
                    {
                        QMessageBox badCRC;
                        badCRC.setText(tr("Validation check failed. Do you wish to proceed?"));
                        badCRC.setIcon(QMessageBox::Warning);
                        badCRC.setStandardButtons (QMessageBox::Ok | QMessageBox::Cancel);
                        badCRC.setDefaultButton (QMessageBox::Cancel);
                        if (badCRC.exec() == QMessageBox::Cancel) loadData = false;
                    }
                }
            }

            fclose(fp);
        }
        else
        {
            emit APIResult(ZytAPIResult::Failure);
            accept();
            // should warn user file not found ... etc

            return QDialog::Rejected;
        }

        if (strlen(deviceNameInFile) > 0)
        {
            int16_t pid;
            const char *connectedDevName;

            zul_getDevicePID(&pid);
            connectedDevName = zul_getDevStrByPID(pid);
            zul_logf(3, "Connected Device: %s\n", connectedDevName);

            if ( NULL == strstr(deviceNameInFile, connectedDevName) )
            {
                // ZYS file does not match the connected device.
                // Seek approval to continue ...
                QMessageBox misMatchedDevice;
                misMatchedDevice.setText(tr("ZYS file was taken from a different device. Do you wish continue?"));
                misMatchedDevice.setIcon(QMessageBox::Warning);
                misMatchedDevice.setStandardButtons (QMessageBox::Ok | QMessageBox::Cancel);
                if (misMatchedDevice.exec() == QMessageBox::Cancel)
                    loadData = false;
            }
        }

        if (loadData)
        {
            bool connectionOK = true;
            zul_inhibitFlashWrites(true);

            // iterate through command list to program the target
            for (x = 0; x<commands.length() && connectionOK; x++)
            {
                int percentDone = 100 * x / commands.length();
                int retVal = FAILURE;
                bool ok;
                int index, value;

                QStringList tokens = commands[x].split(QRegExp("\\s+"));
                index = tokens[1].toInt(&ok, 16);
                value = tokens[2].toInt(&ok, 16);
                zul_logf (3, "## %s ::: Index:%03d Value:%05d (0x%04x)\n",
                        ZytContentFrame::toCString( &(commands[x]) ),
                        index, value, value );

                retVal = zul_setConfigParamByID( index, value );
                if (retVal == SUCCESS)
                {
                    progressBar->setValue(percentDone);
                    QApplication::processEvents();
                    emit APIResult(ZytAPIResult::Success);
                }
                else
                {
                    connectionOK = false;
                }
            }
            zul_inhibitFlashWrites(false);
            progressBar->setValue(100);
            QApplication::processEvents();
            zy_msleep(200);
        }
        else
        {
            // do nothing - and exit
            zul_logf(3, "Load Finished\n" );
            zy_msleep(200);
        }
    }

    accept();
    return QDialog::Accepted;
}
