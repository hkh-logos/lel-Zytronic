/*
 *      Widget to contain title for pages within tabs. Keeps conformity amongst
 *      all tabs.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <QtWidgets>
#include "PageTitleFrame.h"
#include "ZytMath.h"

#define FONT_SIZE       (14)
#define BANNER_HEIGHT   (40)

PageTitleFrame::PageTitleFrame(const QString titleString, QWidget *parent)
       : QFrame(parent)
{
    m_parent = parent;

    createWidgets(titleString, NULL);

    setLayout(createLayout());
    setFixedHeight(BANNER_HEIGHT);
}

PageTitleFrame::PageTitleFrame(const QString titleString, const QString stageString, QWidget *parent)
        : QFrame(parent)
{
    m_parent = parent;

    createWidgets(titleString, stageString);

    setLayout(createLayout());
    setFixedHeight(BANNER_HEIGHT);
}

void PageTitleFrame::createWidgets(const QString titleString, const QString stageString)
{
    title = new QLabel(titleString,this);
    QFont font = title->font();
    font.setPointSize(FONT_SIZE);
    title->setFont(font);

    if(NULL != stageString)
    {
        stage = new QLabel(stageString,this);

    }
    else
    {
        stage = new QLabel("",this);
    }

    stage->setFont(font);
}

QLayout * PageTitleFrame::createLayout()
{
    QHBoxLayout *mainLayout = new QHBoxLayout;
    mainLayout->addWidget(title);
    mainLayout->addStretch();
    mainLayout->addWidget(stage);

    return mainLayout;
}

void PageTitleFrame::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.fillRect(rect(), QColor(240,240,240));

    QFrame::paintEvent(event);
}

void PageTitleFrame::setTitle(const QString titleString)
{
    title->setText(titleString);
    stage->setText("");
}

void PageTitleFrame::setTitle(const QString titleString, const QString stageString)
{
    title->setText(titleString);
    stage->setText(stageString);
}
