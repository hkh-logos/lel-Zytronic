/*
 *      Content of the Touch Options tab in the Configuration tab.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


/*
#include <Zxy100/contComms.h>
#include <Zxy100/contBasSet.h>
#include <Zxy100/contAdvSet.h>
#include <Zxy100/contConnect.h>
#include <Zxy100/drvInf.h>
#include <Zxy100/contAdvSet.h>
*/

#include "zytypes.h"
#include "protocol.h"
#include "debug.h"
#include "comms.h"
#include "zxymt.h"
#include "zxy100.h"
#include "zxy110.h"
#include "services.h"

#include "ControllerOptionsFrame.h"

QTime ControllerOptionsFrame::buttonPressHoldoff;

ControllerOptionsFrame::ControllerOptionsFrame(QWidget *parent) :
    ZytContentFrame(parent)
{
    int16_t PID;
    bool deviceOpened = zul_getDevicePID(&PID);
    devPID = PID;

    zxy100Interface = (devPID == ZXY100_PRODUCT_ID) || (devPID == ZXY110_PRODUCT_ID);

    createWidgets();
    if (deviceOpened && (!zul_isBLDevicePID(devPID)))
    {
        readFromController();
    }
    createConnections();
    setLayout(createLayout());

    buttonPressHoldoff = QTime::currentTime();
}

QTime ControllerOptionsFrame::getbuttonPressHoldoff(void)
{
    return buttonPressHoldoff;
}

void ControllerOptionsFrame::showOverlay()
{
    int restCalY = restoreButton->geometry().bottomLeft().y() - 18;
    int restoreX = restoreButton->geometry().bottomLeft().x() + 5;

    restOverlay->setGeometry(QRect(restoreX, restCalY, 10, 15));

    restOverlay->show();
    calOverlay->show();
    numTouchSlider->showOverlay();
}

void ControllerOptionsFrame::hideOverlay()
{
    discOverlay->hide();
    restOverlay->hide();
    calOverlay->hide();
    numTouchSlider->hideOverlay();
}


void ControllerOptionsFrame::createWidgets()
{
    QString style = QString(" QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; padding: 1px; } "
                        " QGroupBox { border-style: inset; border: 1px solid lightgray; border-radius: 4px;}" );

    f0 = new QGroupBox(tr("Touch Options"));
    f1 = new QGroupBox(tr("Calibration Options"));
    f2 = new QGroupBox(tr("Controller Options"));
    f3 = new QGroupBox(tr("ZYS Files"));

    f0->setStyleSheet(style);
    f1->setStyleSheet(style);
    f2->setStyleSheet(style);
    f3->setStyleSheet(style);

    //f2->setContentsMargins(4,4,3,3); //f3->setContentsMargins(5,5,3,3);

    restoreButton = new QPushButton(tr("&Restore Factory\nDefaults"),this);
    restoreButton->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    customCalButton = new QPushButton(tr("Custom &Onboard\nCalibration"), this);
    customCalButton->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    deleteCalButton = new QPushButton(tr("&Delete Calibration"),this);
    deleteCalButton->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    forceEqButton = new QPushButton(tr("&Force Equalization"),this);
    forceEqButton->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    saveButton = new QPushButton(tr("&Save Configuration"),this);
    saveButton->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);
    loadButton = new QPushButton(tr("&Load Configuration"),this);
    loadButton->setMinimumSize(STD_BUTT_WIDTH,STD_BUTT_HEIGHT);

    // Overlay labels
    restOverlay = new QLabel("r", this, 0);
    restOverlay->setStyleSheet("background-color: rgb(250, 200, 100)");
    restOverlay->hide();

    calOverlay = new QLabel("v", this, 0);
    calOverlay->setStyleSheet("background-color: rgb(250, 200, 100)");
    calOverlay->hide();

    forceEqOverlay = new QLabel("f", this, 0);
    forceEqOverlay->setStyleSheet("background-color: rgb(250, 200, 100)");
    forceEqOverlay->hide();

    discOverlay = new QLabel("d", this, 0);
    discOverlay->setStyleSheet("background-color: rgb(250, 200, 100)");
    discOverlay->hide();

    int min=1, max=ZXYMT_MAX_TOUCH;

    if ( zul_isZXY500AppPID(&devPID) )
    {
        max = ZXY500_MAX_TOUCH;
    }

    if (zxy100Interface)
    {
        mouseModeChkBox = new QCheckBox("&Mouse Mode", this);
        mouseModeChkBox->setLayoutDirection(Qt::RightToLeft);
        pointClickChkBox = new QCheckBox("Point Clic&k Mode", this);
        pointClickChkBox->setLayoutDirection(Qt::RightToLeft);
        max=2;
    }

    numTouchSlider = new BigLabeledSlider(tr("Number of Touches"), min, max, 5, "&+", "&-",
                                          new QKeySequence("+"), new QKeySequence("-"), NULL, this);
    numTouchSlider->enableReading(false);
}


QLayout * ControllerOptionsFrame::createLayout()
{
    QVBoxLayout *mainLayout = new QVBoxLayout;
    QHBoxLayout *numTouchLayout = new QHBoxLayout;
    QVBoxLayout *touchModLayout = new QVBoxLayout;
    QHBoxLayout *calButtLayout = new QHBoxLayout;
    QHBoxLayout *pushButtLayout = new QHBoxLayout;
    QHBoxLayout *fileButtLayout = new QHBoxLayout;

    numTouchLayout->addStretch();
    numTouchLayout->addWidget(numTouchSlider);
    numTouchLayout->addStretch();
    if (zxy100Interface)
    {
        touchModLayout->addStretch();

#ifdef __APPLE__  // no mouse mode service on OSX
        mouseModeChkBox->setHidden(true);
#else
        touchModLayout->addWidget(mouseModeChkBox);
#endif

        touchModLayout->addWidget(pointClickChkBox);
        touchModLayout->addStretch();
    }
    numTouchLayout->addLayout(touchModLayout);

    f0->setLayout(numTouchLayout);

    calButtLayout->addStretch();
    calButtLayout->addWidget(customCalButton);
    calButtLayout->addStretch();
    calButtLayout->addWidget(deleteCalButton);
    calButtLayout->addStretch();

    f1->setLayout(calButtLayout);

    pushButtLayout->addStretch();
    pushButtLayout->addWidget(restoreButton);
    pushButtLayout->addStretch();
    pushButtLayout->addWidget(forceEqButton);
    pushButtLayout->addStretch();

    f2->setLayout(pushButtLayout);

    fileButtLayout->addStretch();
    fileButtLayout->addWidget(saveButton);
    fileButtLayout->addStretch();
    fileButtLayout->addWidget(loadButton);
    fileButtLayout->addStretch();

    f3->setLayout(fileButtLayout);

    mainLayout->addStretch();
    mainLayout->addWidget(f0);

    mainLayout->addStretch();
    mainLayout->addWidget(f1);
    mainLayout->addStretch();
    mainLayout->addWidget(f2);
    mainLayout->addStretch();
    mainLayout->addWidget(f3);
    mainLayout->addStretch();

    return mainLayout;
}

void ControllerOptionsFrame::deleteCalibration()
{
    zul_clearOnBoardCal();

    // currently, this process does NOT alter the axes flips/swaps
    // update the view indicating the axes flips/swap
    // if (z2AxesFrame) z2AxesFrame->reReadValues();

    emit APIResult(ZytAPIResult::Success);
}

void ControllerOptionsFrame::customCalibration()
{
    if (buttonPressHoldoff.addMSecs(100) < QTime::currentTime()) // stop double clicks
    {
        buttonPressHoldoff = QTime::currentTime();

        customCalButton->setEnabled(false);

        QString mName = caliDialog.getMonitorForDevice();
        if (mName != NULL)
        {
            monitorSelector.setPreferred(mName);
        }


        if (QDialog::Accepted == monitorSelector.exec())
        {
            Monitor selected;
            monitorSelector.getSelectedMonitor(&selected);
            caliDialog.setMonitor(&selected);

            if(selected.getOrientation() != xmo_Normal)
            {
                QMessageBox warningBox;
                warningBox.setWindowTitle(tr("Warning"));
                QString warningText = QString(tr("This feature is only available when the Screen Orientation is 'Landscape'"));
                warningBox.setText(warningText);
                warningBox.setIcon(QMessageBox::Warning);
                warningBox.setStandardButtons(QMessageBox::Ok);
                warningBox.setModal(true);
                warningBox.exec();

                customCalButton->setEnabled(true);
                buttonPressHoldoff = QTime::currentTime();
                return;
            }

            if (QDialog::Accepted == marginSelector.exec())
            {
                int top, bottom, left, right;
                marginSelector.getMargins(&top, &bottom, &left, &right);
                caliDialog.setCustomMargins(top, bottom, left, right);

                caliDialog.exec();

                // update the view indicating the axes flips/swap
                emit reReadAxesReq();
            }
        }

        customCalButton->setEnabled(true);
        buttonPressHoldoff = QTime::currentTime();
    }
}

void ControllerOptionsFrame::forceEqualization()
{
    emit APIResult(ZytAPIResult::Progress);
    zul_forceEqualisation();
    emit APIResult(ZytAPIResult::Success);

}

void ControllerOptionsFrame::restoreDefaults()
{
    QMessageBox confirmBox;
    confirmBox.setWindowTitle(tr("Factory Defaults"));
    confirmBox.setText( tr("Restore Controller to Factory Defaults?")
                        + "\n"
                        + tr("This may take a few seconds.") );
    confirmBox.setIcon(QMessageBox::Warning);
    confirmBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);

    //remove the close button from the dialog if there is one
    Qt::WindowFlags wFlags = confirmBox.windowFlags();
    if(Qt::WindowCloseButtonHint == (wFlags & Qt::WindowCloseButtonHint))
    {
        wFlags = wFlags ^ Qt::WindowCloseButtonHint;
        confirmBox.setWindowFlags(wFlags);
    }

    int result = confirmBox.exec();
    if(QMessageBox::Yes == result)
    {
        int delay = 3000;
        emit APIResult(ZytAPIResult::Progress);

        // indicate busy period ...
        QApplication::setOverrideCursor(Qt::WaitCursor);
        QApplication::processEvents();

        zul_log(3, "zul_restoreDefaults Start ... ");
        zul_restoreDefaults();      // ZXY110 - long running process ...
        zul_log(3, "zul_restoreDefaults DONE");

        zy_msleep(delay);
        // trigger the other frames to update their displayed state
        emit reReadRequired();
        emit APIResult(ZytAPIResult::Success);
        QApplication::restoreOverrideCursor();
    }
    else
    {
        QApplication::setActiveWindow((QMainWindow *) this->parent());
        //do nothing
    }
}

void ControllerOptionsFrame::createConnections()
{
    /* All connections made here must be broken in reReadValues()
     */

    QObject::connect(restoreButton, SIGNAL(clicked()),
                     this, SLOT(restoreDefaults()));

    QObject::connect(forceEqButton, SIGNAL(clicked()),
                     this, SLOT(forceEqualization()));

    QObject::connect(customCalButton, SIGNAL(clicked()),
                     this, SLOT(customCalibration()));

    QObject::connect(&caliDialog, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                     this, SIGNAL(APIResult(ZytAPIResult::ResultState)));

    QObject::connect(deleteCalButton, SIGNAL(clicked()),
                     this, SLOT(deleteCalibration()));

    QObject::connect(saveButton, SIGNAL(clicked()),
                     this, SLOT(startSaveConfig()));

    QObject::connect(loadButton, SIGNAL(clicked()),
                     this, SLOT(startLoadConfig()));


    QObject::connect(&configSaveDialog, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                     this, SIGNAL(APIResult(ZytAPIResult::ResultState)));
    QObject::connect(&configLoadDialog, SIGNAL(APIResult(ZytAPIResult::ResultState)),
                     this, SIGNAL(APIResult(ZytAPIResult::ResultState)));

    if (zxy100Interface)
    {
        QObject::connect(mouseModeChkBox, SIGNAL(clicked()), this, SLOT(changeMouseMode()) );
        QObject::connect(pointClickChkBox, SIGNAL(clicked()), this, SLOT(changePointClick()) );
    }

    QObject::connect(numTouchSlider, SIGNAL(valueChanged(int)),
                     this, SLOT(changeNumTouches()));
}

void ControllerOptionsFrame::changeNumTouches()
{
    int sliderNumTouches = numTouchSlider->getValue();

    if (zxy100Interface)
    {
        if (mouseModeChkBox->isChecked())
        {
            return;
        }
        switch (sliderNumTouches)
        {
            case 1:
                // ZXY110_CI_DEVICE_MODE == ZXY100_CI_DEVICE_MODE (!)
                zul_setConfigParamByID(ZXY100_CI_DEVICE_MODE, 1);
                break;
            case 2:
                 // ZXY110_CI_DEVICE_MODE == ZXY100_CI_DEVICE_MODE (!)
                zul_setConfigParamByID(ZXY100_CI_DEVICE_MODE, 2);
                break;
        }
    }
    else
    {
        uint16_t value = (uint16_t)sliderNumTouches;
        zul_setConfigParamByID(ZXYMT_CI_MAX_TOUCHES, value);

        if (sliderNumTouches > 10)
        {
            // we find it's best to remove palm-recognition when users want high touch counts
            zul_setConfigParamByID(ZXYMT_CI_PALM_REJECT_WEIGHT_LIMIT, 0);
        }
    }
}

void ControllerOptionsFrame::changeMouseMode()
{
    bool isChecked = mouseModeChkBox->isChecked();

    if (isChecked)
    {
        numTouchSlider->setValue(1);

        // ZXY110_CI_DEVICE_MODE == ZXY100_CI_DEVICE_MODE (!)
        zul_setConfigParamByID(ZXY100_CI_DEVICE_MODE, 0); //SetDeviceMode(MODE_MOUSE);
    }
    else
    {
        numTouchSlider->setValue(1);


        zul_setConfigParamByID(ZXY100_CI_DEVICE_MODE, 1);  // single touch mode
    }

    numTouchSlider->setEnabled(!isChecked);
}

void ControllerOptionsFrame::changePointClick()
{
    bool isChecked = pointClickChkBox->isChecked();
    zul_setConfigParamByID(PointClickParam, isChecked);
}


void ControllerOptionsFrame::readFromController()
{
    uint16_t devMode;
    uint16_t pointClickChkBoxMode;

    if (zxy100Interface)
    {
        // ZXY110_CI_DEVICE_MODE == ZXY100_CI_DEVICE_MODE (!)
        zul_getConfigParamByID(ZXY100_CI_DEVICE_MODE, &devMode);
        switch (devMode)
        {
            case ZXY100_MODE_MOUSE:
                numTouchSlider->setValue(1);
                numTouchSlider->setEnabled(false);
                mouseModeChkBox->setChecked(true);
                break;
            case ZXY100_MODE_SINGLE:
                numTouchSlider->setValue(1);
                numTouchSlider->setEnabled(true);
                mouseModeChkBox->setChecked(false);
                break;
            case ZXY100_MODE_DUAL:
                numTouchSlider->setValue(2);
                numTouchSlider->setEnabled(true);
                mouseModeChkBox->setChecked(false);
                break;
        }

        PointClickParam = (devPID == ZXY100_PRODUCT_ID) ? ZXY100_CI_POINT_CLICK_STATE : ZXY110_CI_POINT_CLICK_ENABLED;

        zul_getConfigParamByID(PointClickParam, &pointClickChkBoxMode);
        pointClickChkBox->setChecked(pointClickChkBoxMode);
    }
    else
    {
        // ZXY150, 200, 300 |  MT style
        uint16_t value;
        zul_getConfigParamByID(ZXYMT_CI_MAX_TOUCHES, &value);

        if (value < 1) value = 1;

        int mtMaxTouch;
        if ( zul_isZXY500AppPID(&devPID) )
        {
            mtMaxTouch = ZXY500_MAX_TOUCH;
        }
        else
        {
            mtMaxTouch = ZXYMT_MAX_TOUCH;
        }

        if (value > mtMaxTouch)
        {
            value = mtMaxTouch;
        }

        numTouchSlider->setValue(value);
        numTouchSlider->setEnabled(true);
    }
}



void ControllerOptionsFrame::reReadValues()
{
    /* Prevent writing back to controller when changing
     * GUI widget values by disconnecting all slots
     * from this object */

    if (zxy100Interface)
    {
        mouseModeChkBox->disconnect(this);
        pointClickChkBox->disconnect(this);
    }
    numTouchSlider->disconnect(this);

    restoreButton->disconnect(this);
    forceEqButton->disconnect(this);

    customCalButton->disconnect(this);
    caliDialog.disconnect(this);

    deleteCalButton->disconnect(this);

    saveButton->disconnect(this);
    loadButton->disconnect(this);

    configSaveDialog.disconnect(this);
    configLoadDialog.disconnect(this);

    readFromController();

    /* re create all the connections */
    createConnections();
}

void ControllerOptionsFrame::startSaveConfig()
{
    if (buttonPressHoldoff.addMSecs(100) < QTime::currentTime()) // stop double clicks
    {
        buttonPressHoldoff = QTime::currentTime();   // TN00031

        saveButton->setEnabled(false);
        loadButton->setEnabled(false);

        QPoint p = QWidget::mapToGlobal(customCalButton->geometry().topLeft());
        configSaveDialog.setLocation(p);
        configSaveDialog.exec();

        saveButton->setEnabled(true);
        loadButton->setEnabled(true);

        buttonPressHoldoff = QTime::currentTime();
    }
}

void ControllerOptionsFrame::startLoadConfig()
{
    if (buttonPressHoldoff.addMSecs(100) < QTime::currentTime()) // stop double clicks
    {
        buttonPressHoldoff = QTime::currentTime();   // TN00031

        saveButton->setEnabled(false);
        loadButton->setEnabled(false);

        QPoint p = QWidget::mapToGlobal(customCalButton->geometry().topLeft());
        configLoadDialog.setLocation(p);
        configLoadDialog.exec();

        // trigger the other frames to update their displayed state
        emit reReadRequired();

        saveButton->setEnabled(true);
        loadButton->setEnabled(true);

        buttonPressHoldoff = QTime::currentTime();
    }
}
