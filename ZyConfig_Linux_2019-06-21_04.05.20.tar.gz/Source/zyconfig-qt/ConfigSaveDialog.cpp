/*
 *      Save device configuration from controller to a file.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */



/*
  ConfigSaveDialog
 */

#include <QtWidgets>

#include <unistd.h>

#include "comms.h"
#include "services.h"
#include "services_sc.h"
#include "protocol.h"
#include "zytypes.h"
#include "sysdata.h"

#include "ConfigSaveDialog.h"
#include "SysInfoDisplay.h"
#include "ZytContentFrame.h"
#include "version.h"

#define SAVE_DGB    (0)

ConfigSaveDialog::ConfigSaveDialog(QWidget *parent) :
    QDialog(parent)
{
    setMinimumWidth(500);
    fileName = "";
    createWidgets();
    location = QPoint(0,0);
}

void ConfigSaveDialog::setLocation(QPoint loc)
{
    location = loc;
}

void ConfigSaveDialog::setFileName(const QString *name)
{
    fileName = *name;
    if (! fileName.endsWith(".zys", Qt::CaseInsensitive))
    {
        fileName.append(".zys");
    }
}


void ConfigSaveDialog::autoFileName()
{
    QDate today = QDate::currentDate ();
    QTime now   = QTime::currentTime ();
    char hwType[8];
    char nameSuggestion[200];

    QString selectedFileName;
    zul_Hardware(hwType, 8);
    hwType[6]='\0';
    sprintf(nameSuggestion, "%s__%04d_%02d_%02d-%02d_%02d_%02d.zys",
            hwType,
            today.year(), today.month(), today.day(),
            now.hour(), now.minute(), now.second() );

    fileName = QString(nameSuggestion);
}


void ConfigSaveDialog::createWidgets(void)
{
    this->setWindowTitle(tr("Save Configuration"));

    textLabel = new  QLabel(this);
    textLabel->setText(tr("Saving the configuration data to file: ..."));
    textLabel->setMinimumWidth(480);
    textLabel->setAlignment(Qt::AlignHCenter);

    progressBar = new QProgressBar(this);
    progressBar->setRange(0, 100);
    progressBar->setFixedWidth(280);

    this->setLayout(createLayout());
}


QLayout * ConfigSaveDialog::createLayout()
{
    QVBoxLayout *mainLayout = new QVBoxLayout;

    mainLayout->addWidget(progressBar);
    mainLayout->setAlignment(progressBar, Qt::AlignCenter);
    mainLayout->addWidget(textLabel);

    return mainLayout;
}


#if defined(Q_OS_DARWIN)
const char osStr[12] = "Darwin";
#else
const char osStr[12] = "Linux";
#endif

int ConfigSaveDialog::exec()
{
    QDate       today           = QDate::currentDate ();
    QTime       now             = QTime::currentTime ();
    QString     dayName         = QDate::longDayName(today.dayOfWeek());
    QString     selectedFileName;

    bool        connectionOK    = true;
    int         numSpiDevices   = 0;
    char        versionString[60];


    if (fileName.length() == 0)
    {
        autoFileName();
        QFileDialog getFileNameDialog(this, tr("Select filename and location "));
        getFileNameDialog.setDirectory(QDir::currentPath());
        getFileNameDialog.setAcceptMode(QFileDialog::AcceptSave);
        getFileNameDialog.setNameFilter(tr("ZYS Zytronic Settings Files (*.zys)"));
        getFileNameDialog.selectFile(fileName);

        QSize dSize = getFileNameDialog.sizeHint();
        QRect r = QRect (location + QPoint(10, 40), dSize);
        getFileNameDialog.setGeometry( r );

        textLabel->setText("File: ...");

        if ( getFileNameDialog.exec() )
        {
            selectedFileName = getFileNameDialog.selectedFiles().at(0);
        }
        else
        {
            return QDialog::Rejected;
        }

        if ( ! selectedFileName.endsWith(".zys") )
            selectedFileName += ".zys";

    }
    else
    {
        fprintf(stderr, "Path: %s\n", QDir::currentPath().toLatin1().data());
        selectedFileName = fileName;            // see setFileName
    }

    showNormal();
    raise();
    activateWindow();

    progressBar->setValue(0);

    if (selectedFileName.length() < 45)
    {
        textLabel->setText(tr("Save config to ") + selectedFileName);
    }
    else
    {
        textLabel->setText( "... " + selectedFileName.right(55) );
    }

    this->setModal(true);
    update();
    repaint();

    zy_msleep(100);

    const char* cName = ZytContentFrame::toCString(&selectedFileName);
    FILE *fp = fopen( cName, "w");

    if (fp!=NULL)
    {
        fileName = "";      // get new name next time
        QByteArray  crcIn("");
        char        lineBuffer[80];
        uint16_t    statMaxPub, statNumPrivate, configMaxPub, configNumPrivate;
        uint16_t    currentFetchCount = 0;
        int16_t     pid;
        char        verStr[10+1];
        char        hName[60];

        zul_getVersion(verStr, 10);
        verStr[9] = '\0';

        fprintf(fp, "# This information collected by %s ZyConfig (App: %s)\n", osStr, verStr);
        fprintf(fp, "# Date %02d/%02d/%04d (%s)\r\n",
                today.day(), today.month(), today.year(),
                ZytContentFrame::toCString( &dayName ) );
        fprintf(fp, "# Time %02d:%02d:%02d\r\n",
                now.hour(), now.minute(), now.second() );

        fprintf(fp, "# System Information\r\n");

        fprintf( fp, "#\tOS Name and Version: ");
        fprintf( fp, "%s",  getOSinfo() );

        gethostname(hName, 60);
        hName[59] = '\0';
        fprintf( fp, "#\tMachine Name:        %s\r\n",  hName);

        fprintf( fp, "#\tMAC Addresses:       %s\r\n", getMACs() );

        fprintf( fp, "#\tSystem UpTime:       %s\r\n", getUpTime() );

        if(SUCCESS != zul_Bootloader(versionString, 60))
        {
            strcpy(versionString, "failure");
            connectionOK = false;
        }
        sprintf(lineBuffer, "VERSION 00 %s", versionString);
        fprintf( fp, "%s\r\n", lineBuffer );
        crcIn.append(lineBuffer);
        progressBar->setValue(1);   update();

        if(SUCCESS != zul_Firmware(versionString, 60))
        {
            strcpy(versionString, "failure");
            connectionOK = false;
        }
        sprintf(lineBuffer, "VERSION 01 %s", versionString);
        fprintf( fp, "%s\r\n", lineBuffer );
        crcIn.append(lineBuffer);
        progressBar->setValue(2);   update();

        if(SUCCESS != zul_Hardware(versionString, 60))
        {
            strcpy(versionString, "failure");
            connectionOK = false;
        }
        // keep a copy of the HW string
        strcpy( hName, versionString );

        sprintf(lineBuffer, "VERSION 02 %s", versionString);
        fprintf( fp, "%s\r\n", lineBuffer );
        crcIn.append(lineBuffer);
        progressBar->setValue(3);   update();

        if(SUCCESS != zul_Customization(versionString, 60))
        {
            strcpy(versionString, "failure");
            connectionOK = false;
        }
        sprintf(lineBuffer, "VERSION 03 %s", versionString);
        fprintf( fp, "%s\r\n", lineBuffer );
        crcIn.append(lineBuffer);
        progressBar->setValue(4);
        update();

        if ( (!zul_getDevicePID(&pid)) || (!connectionOK))
        {
            fclose( fp );
            fprintf(stderr, "##### Save ZYS - Connection fault\n");
            accept();
            return QDialog::Rejected;   // failed to detect the device type
        }


        switch (pid)
        {
            case ZXY100_PRODUCT_ID:
                configMaxPub        = zul_getZxy100ConfigCount();
                statMaxPub          = zul_getZxy100StatusCount();
                configNumPrivate    = 0;
                statNumPrivate      = 0;
                progressBar->setValue(2);
                update();
                QApplication::processEvents();
                break;

            case ZXY110_PRODUCT_ID:
                zul_setCommsEndurance(COM_ENDUR_MEDIUM);

                if (FAILURE == zul_getStatusByID( ZXY110_SI_NUM_CONFIG_PARAMS, &configMaxPub))
                    connectionOK = false;
                if (FAILURE == zul_getStatusByID( ZXY110_SI_NUM_STATUS_VALUES, &statMaxPub))
                    connectionOK = false;
                configNumPrivate    = 0;
                statNumPrivate      = 0;
                progressBar->setValue(2);
                update();
                QApplication::processEvents();
                break;

            case ZXY500_PRODUCT_ID:
            case ZXY500_PRODUCT_ID_ALT1:

                numSpiDevices  = 1;
                if (strstr(hName, "-128-") != NULL)
                {
                    numSpiDevices = 2;
                }
                if (strstr(hName, "-256-") != NULL)
                {
                    numSpiDevices = 4;
                }
                [[gnu::fallthrough]];

            case ZXY150_PRODUCT_ID:
            case ZXY200_PRODUCT_ID:
            case ZXY300_PRODUCT_ID:

                statMaxPub = 0;
                if (FAILURE == zul_getStatusByID( ZXYMT_SI_NUM_STATUS_VALUES,          &statMaxPub))
                    connectionOK = false;
                statNumPrivate = 0;
                if (FAILURE == zul_getStatusByID( ZXYMT_SI_NUM_PRIVATE_STATUS_VALUES,  &statNumPrivate))
                    connectionOK = false;
                configMaxPub = 0;
                if (FAILURE == zul_getStatusByID( ZXYMT_SI_NUM_CONFIG_PARAMS,          &configMaxPub))
                    connectionOK = false;
                configNumPrivate = 0;
                if (FAILURE == zul_getStatusByID( ZXYMT_SI_NUM_PRIVATE_CONFIG_PARAMS,  &configNumPrivate))
                    connectionOK = false;
                progressBar->setValue(8);
                update();
                QApplication::processEvents();
                break;

            default:
                // this should never happen!
                connectionOK = false;
                fprintf(stderr, "##### Save ZYS - Unknown PID \n");
        }
        if ( ! connectionOK )
        {
            fprintf(stderr, "##### Total - %d 0x%04x\n", 0, 0);
            accept();
            return QDialog::Rejected;   // failed to detect the device type
        }

        const uint16_t totalFetchCount = statMaxPub + statNumPrivate + configMaxPub + configNumPrivate + numSpiDevices * 6;

        if (SAVE_DGB) fprintf(stderr, "##### Total - %d 0x%04x\n", totalFetchCount, totalFetchCount);

        for (int statusID = 0; statusID<statMaxPub && connectionOK ; statusID++)
        {
            uint16_t status;
            //fprintf(stderr, "##^## Status %d\n", statusID );
            if (zul_getStatusByID(statusID, &status) == SUCCESS)
            {
                sprintf(lineBuffer, "STATUS %02X %04X", statusID, status);
                fprintf( fp, "%s\r\n", lineBuffer );
                crcIn.append(lineBuffer);
            }
            else
            {
                connectionOK = false;
            }
            currentFetchCount++;
            progressBar->setValue(92*currentFetchCount/totalFetchCount + 8);
            if (SAVE_DGB) fprintf(stderr, "..... ..... - %03d %s\n", statusID, lineBuffer );
            QApplication::processEvents();
        }

        for (int statusID = 0x100-statNumPrivate; statusID<=0xFF && connectionOK; statusID++)
        {
            //fprintf(stderr, "##v## Status %d\n", statusID );
            uint16_t status;
            if (zul_getStatusByID(statusID, &status) == SUCCESS)
            {
                sprintf(lineBuffer, "STATUS %02X %04X", statusID, status);
                fprintf( fp, "%s\r\n", lineBuffer );
                crcIn.append(lineBuffer);
            }
            else
            {
                connectionOK = false;
            }
            currentFetchCount++;
            progressBar->setValue(92*currentFetchCount/totalFetchCount + 8);
            if (SAVE_DGB) fprintf(stderr, "..... ..... - %03d %s\n", statusID, lineBuffer );
            QApplication::processEvents();
        }

        if (numSpiDevices > 0)
        {
            strcpy (lineBuffer, "#ARVAL CR Reg");
            fprintf( fp, "%s\r\n", lineBuffer );
            crcIn.append(lineBuffer);
        }

        // next - any ARVALs from ZXY500s
        for (int spiDevIndex=0; spiDevIndex<numSpiDevices && connectionOK; spiDevIndex++)
        {
            uint8_t reg;
            for (reg = 0; reg < 6; reg++)
            {
                uint16_t value, address;
                if ( SUCCESS == zul_getSpiRegister( spiDevIndex, reg, &value ))
                {
                    address = (spiDevIndex << 4) + (reg);
                    sprintf(lineBuffer, "#ARVAL %02X %04X", address, value );
                    fprintf( fp, "%s\r\n", lineBuffer );
                    crcIn.append(lineBuffer);
                }
                else
                {
                    connectionOK = false;
                }
                currentFetchCount++;
                progressBar->setValue(92*currentFetchCount/totalFetchCount + 8);
                if (SAVE_DGB) fprintf(stderr, "..... ...AR - %03d %s\n", address, lineBuffer );
                QApplication::processEvents();
            }
        }

        for (int configID = 0x00; configID<configMaxPub && connectionOK ; configID++)
        {
            uint16_t setting;
            //fprintf(stderr, "##^## Config %d\n", configID );
            if (zul_getConfigParamByID(configID, &setting) == SUCCESS)
            {
                sprintf(lineBuffer, "CONFIG %02X %04X", configID, setting);
                fprintf( fp, "%s\r\n", lineBuffer );
                crcIn.append(lineBuffer);
            }
            else
            {
                connectionOK = false;
            }
            currentFetchCount++;
            progressBar->setValue(92*currentFetchCount/totalFetchCount + 8);
            if (SAVE_DGB) fprintf(stderr, "..... ..... - %03d %s\n", configID, lineBuffer );
            QApplication::processEvents();
        }

        for (int configID = 0x100-configNumPrivate; configID<=0xFF && connectionOK ; configID++)
        {
            uint16_t setting;
            //fprintf(stderr, "##v## Config %d\n", configID );
            if (zul_getConfigParamByID(configID, &setting) == SUCCESS)
            {
                sprintf(lineBuffer, "CONFIG %02X %04X", configID, setting);
                fprintf( fp, "%s\r\n", lineBuffer );
                crcIn.append(lineBuffer);
            }
            else
            {
                connectionOK = false;
            }
            currentFetchCount++;
            progressBar->setValue(92*currentFetchCount/totalFetchCount + 8);
            if (SAVE_DGB) fprintf(stderr, "..... ..... - %03d %s\n", configID, lineBuffer );
            QApplication::processEvents();
        }

        progressBar->setValue(100);     // always report completion
        textLabel->setText(tr("Closing ") + selectedFileName);
        update();
        repaint();

        if (0)
            fprintf( stderr, "\n## %s\n## Chars      %d\n", crcIn.constData(), crcIn.length() );

        fprintf( fp, "\n# Validation %04X\r\n",
                    zul_getCRC((unsigned char *)crcIn.constData(), crcIn.length() ) );

        fclose(fp);
    }

    update();
    repaint();
    QApplication::processEvents();
    zul_setCommsEndurance(COM_ENDUR_NORM);
    zy_msleep(300); // allow time for user to see it's completed

    // emit APIResult(ZytAPIResult::StatusSaved);
    accept();
    return QDialog::Accepted;
}
