/*
 *      Threshold Setting Base Widget.
 *      Displays a number of points on the screen in order to evaluate touch
 *      sensitivity data and then write it to the controller.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef SETUPSENSDIALOG_BASE_H
#define SETUPSENSDIALOG_BASE_H

#include <QtWidgets>

#include "services.h"
#include "logfile.h"

#include "ZytAPIResult.h"
#include "Monitor.h"


// --- logging macros ----------------------------------
#define GET_STATUS_VAL( A, B )                         \
    zul_getStatusByID( (A), &(B) );                    \
    basicSetupLog->Write2LogF("Get %-31s %d", #A, (B) );

#define SET_CONFIG_PARAM( A, B )                       \
    zul_setConfigParamByID( (A), (B) );                \
    basicSetupLog->Write2LogF("SET %-31s %d", #A, (B) );

#define GET_CONFIG_PARAM( A, B )                       \
    zul_getConfigParamByID( (A), &(B) );               \
    basicSetupLog->Write2LogF("GET %-31s %d", #A, (B) );
// -----------------------------------------------------


#define CALP_LEFT_TOP       (0)     //Sensitivity Test Point Locations - originally from calibration process
#define CALP_LEFT_MIDDLE    (1)     // +---------+
#define CALP_LEFT_BOTTOM    (2)     // | 0  7  6 |
#define CALP_MIDDLE_BOTTOM  (3)     // | 1  8  5 |      TestPoint Sequence:
#define CALP_RIGHT_BOTTOM   (4)     // | 2  3  4 |      +---------+
#define CALP_RIGHT_MIDDLE   (5)     // +---------+      | 2     5 |
#define CALP_RIGHT_TOP      (6)     //                  |    1    |
#define CALP_MIDDLE_TOP     (7)     //                  | 3     4 |
#define CALP_MIDDLE_MIDDLE  (8)     //                  +---------+

#define NUM_POINTS          (9)
#define NUM_TSEQ_POINTS     (5)

#define MAX_X_BINS          (160)
#define MAX_Y_BINS          (96)

/* number of samples over pseudo threshold required to characterise
 * the signal level of each of the test touches */
#define REQD_ON_SAMPLES     (30)
#define REQD_OFF_SAMPLES    (4)

// state-machine ticks are 1/20th of a second apart (50ms)
#define TICKS_PER_SECOND    (20)

// state Durations (in seconds)
#define TOUCH_ON_WAIT       (4)
#define TOUCH_OFF_WAIT      (10)
#define NOISE_WAIT          (2)
#define DONE_WAIT           (120)   // ie two minutes


class SetupSensDialog_BASE : public QDialog
{
    Q_OBJECT

public slots:
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
    int exec();

signals:
    void            APIResult(ZytAPIResult::ResultState state);

private slots:
        void tick();

public:

    enum StateChange
    {
        scNormal,           // normal progress
        scExit,             // close window
        scCancel,           // abandon the process, restore previous settings
    };

    enum PanelState
    {
        SaveSettings,       // so that that the process can be abandonded
        RestoreDefaults,    // so that there are no flips/thresholds etc.

        FirstTouchMeasureW, // determine the values associated with First Touch Mode
        FirstTouchMeasureB, // determine the values associated with First Touch Mode
        EqualizeSensor,     // allow for Force Equalization to complete

        GetNoiseProfile,    // N seconds blank display, no touch please
        GetTouch,           // touch 1, 2, 3, 4, 5 to get touch "MAX-PRESSURE" reading profile at touch location
        ReleaseTouch,       // keep in sync with user, gather more noise data
        Confirm,            // present the data (no longer used)
        Finished,           // final screen awaiting user to exit with 'Esc'

        Failed_NoTouch,     // report touch failure to user
        Failed_NoRelease,   // report release failure to user
        Failed_CommsError,  // report comms failure to user
        Failed_Noise,       // report comms failure to user

        RestoreSettings,    // typically this is not used, but can be jumped to if user presses "escape"
        ChangeSens100,      // ZXY100 change sensitivity (glass thickness) state
        NotifyChgSens100,   // state to display the sensitivity change notice

        LastState           // Unused sentinel
    };

    /* datatype to hold the core state-machine data
     */
    struct bsState_t
    {
        PanelState  panelState;
        int         timeout;
        int         touchStateCount;

        int         touchSeqLoc;
        int         currentPointIndex;
        QPoint      currentPoint;

        bool        firstTick;

        int         touchMargin;
        int         touchMinimum;
    };
    typedef struct bsState_t BasicSetupState;

    /* Provide a struct to gather the values that are to be applied to
     * the controller on a valid completion of the process.
     */
    struct setProposal_t
    {
        uint8_t     pseudoUpperThr;
        bool        invertXaxis,   invertYaxis;
        bool        swapAxes;

        uint16_t    touchCountLimit;

        // ZXY100 Only
        uint8_t     flexiLocation;      // => landscape/portrait
        uint8_t     glassThickness;

        // MT Only - First Touch Mode
        uint16_t    palmThresh;
        uint16_t    ftm_OnThreshold, ftm_OffThreshold;
        uint16_t    interpolatorBias;
    };
    typedef struct setProposal_t ProposedSettings;      // ToDo extract to class

    // Holder for pseudo touch sample data
    struct touchDat_s
    {
        int sumAtX[MAX_X_BINS], minAtX[MAX_X_BINS], numAtX[MAX_X_BINS];
        int sumAtY[MAX_Y_BINS], minAtY[MAX_Y_BINS], numAtY[MAX_Y_BINS];
        int numAboveThresh, numBelowThresh;

        int xLoc, yLoc;             // wire/cell index
        int xPressMax, yPressMax;

        bool isPseudoTouched;
        bool wasPseudoTouched;
        int  wasTouchedCounter;
    };
    typedef struct touchDat_s TouchData;                // ToDo extract to class

    // holder for the touch signal data for each of the 5 test sequence points
    struct testPtData_s
    {
        int signal;     // signal level measured
        int xLoc;       // measurement X location, wire/cell index
        int yLoc;
    };
    typedef struct testPtData_s TestPointData;

// --------------------------------------------------------

    static const int    DebugText;
    static const int    TouchSequence[];
    int                 noiseMax;

    // the core state-machine state-transition data
    BasicSetupState     state;
    ProposedSettings    setProposal;
    TouchData           touchData;
    TestPointData       testPtData[NUM_TSEQ_POINTS+1];

    ZyLogFile       *   basicSetupLog;
    QTimer          *   fastTick;
    int16_t             devPID;
    ZXY_sensorSize      szSensor;
    Monitor         *   pAssignedMonitor;
    QRect               monitorRect;
    QRect               infoBox, dataBox;
    int                 border;

// --------------------------------------------------------

    SetupSensDialog_BASE(QWidget *parent = 0);

    virtual         ~SetupSensDialog_BASE();

    bool            initData            (void);
    virtual bool    initData2           (void) = 0;

    virtual void    updateSetProposal   (void) = 0;
    void            processData         (void);
    void            processPseudoTouch  (void);

    virtual int     getPseudoTouchSignal(void) = 0;
    virtual int     getSignalLevel      (void) = 0;
    virtual void    getSignalLocation   (uint16_t *tp_x, uint16_t *tp_y) = 0;
    bool            isTouched           (void);

    virtual int     storeStateData(void) = 0;
    virtual void    getNextState(void) = 0;
    virtual int     getStateTO(void) = 0;
    virtual void    prepNewState(void) = 0;
    void            changeState         (StateChange transition);
    virtual void    changeStateWhenRestoreDone (void) = 0;      // ZXY110 ONLY!

    void            paintEvent          (QPaintEvent*);
    virtual void    applySettings       (void) = 0;
    void            initProposal        (void);
    void            wipeTouchSamples    (void);
    void            setMonitor          (Monitor *m);

    float           getTimeLeft         (void);
    QString         getTimeLeft         (int precision);

    QString         getStateName        (void);
    QString         getStateName2       (void);
    char const *    getStateCStr        (void);

    virtual void    partialRestoreFactorySettings() = 0;
    virtual bool    errorEventsOccurred (void) = 0;
    virtual void    haltRawData         () = 0;

    void            drawTarget          (QPoint centre, int radius, QPainter *painter,
                                            int cx, int cy);
    void            setCalibrationPoint (int width, int height, int border, int index);

    void            positionInfoBox     (int width, int height, int cBorder,
                                            QPoint *topLeft, QPoint *bottomRight);

    void            orientationTestFunc (void);
};

#endif // SETUPSENSDIALOG_BASE_H
