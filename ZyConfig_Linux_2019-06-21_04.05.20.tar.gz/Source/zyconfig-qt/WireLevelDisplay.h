/*
 *      Widget to display the wirelevels from the controller as collected
 *      when the controller is on raw mode.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef WIRELEVELDISPLAY_H
#define WIRELEVELDISPLAY_H

#include <QWidget>
#include <QtWidgets>

#define MAX_WIRELEVEL	(255)
#define MIN_WIRELEVEL	(0)
#define WLD_MIN_WIDTH	(450)

#define MOVING_AVG_LEN  (20)

class WireLevelDisplay : public QFrame
{
    Q_OBJECT

public:
    WireLevelDisplay(QWidget *parent = 0);
    void setThresholds(const int upper, const int lower);
    void setWireLevels(const QVector<int> xWires, const QVector<int> yWires);
    void clearMovingAvgs(void);

protected:
    void paintEvent(QPaintEvent *event);

private:
    QWidget *m_parent;

    void setDefaults();
    int findLinePosition(const int index, const float spacing);
    float findSpacing(const QVector<int> wires);

    void updateMovingAvgs(int a, int b);
    int getMovingAvgX(void);
    int getMovingAvgY(void);

    QVector<int> xWires;
    QVector<int> yWires;

    int upperThreshold;
    int lowerThreshold;

    bool upperThresholdBroken;
    bool lowerThresholdBroken;
    bool toggleThresholdBolding;

    int  xMaxValues[MOVING_AVG_LEN];
    int  yMaxValues[MOVING_AVG_LEN];
    int  movingAvgLoc, xMovingSum, yMovingSum;
};

#endif
