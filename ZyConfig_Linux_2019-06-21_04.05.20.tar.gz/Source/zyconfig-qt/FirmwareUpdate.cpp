/*
 *      Content of the Firmware Update Tab in the config app
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */



#include "FirmwareUpdate.h"
#include "dbg2console.h"
#include "services.h"
#include "usb.h"
#include "debug.h"

static bool uploadRunning;
static int  ZYC_DEBUG = 3;

FirmwareUpdate::FirmwareUpdate(QWidget *parent) :
    ZytContentFrame(parent)
{
    uploadRunning = false;

    createWidgets();

    createConnections();

    setLayout(createLayout());
}

bool FirmwareUpdate::fwXfrActive(void)
{
    return uploadRunning;
}

void FirmwareUpdate::createWidgets()
{
    QString descriptionText = QString(
        tr("Controller firmware updates may be provided to you directly from Zytronic. "));
    descriptionText.append(tr("Firmware update files all have the \".zyf\" extension."));

    descriptionLabel = new QLabel(descriptionText, this);
    descriptionLabel->setWordWrap(true);

    methodLabel = new QLabel(
            tr("To update the controller firmware, please follow the steps below:\n\n") +
            tr("    1.  Click the 'Browse' button.\n") +
            tr("    2.  Navigate to the folder containing the required \".zyf\" firmware update file.\n") +
            tr("    3.  Double click on the \".zyf\" file.\n") +
            tr("    4.  The firmware update will then start automatically with progress shown onscreen.\n") +
            tr("    5.  If any faults occur, please repeat the above procedure."),   this);
    methodLabel->setMargin(20);
    methodLabel->setIndent(60);

    importantLabel = new QLabel(tr("WARNING:"), this);
    importantLabel->setStyleSheet("QLabel { background-color : white; color : red; }");
    importantLabel->setAlignment(Qt::AlignTop);
    warningLabel   = new QLabel(tr("During the update process DO NOT unplug the controller ") +
                                tr("or navigate away from this page until the process is complete."), this);
    warningLabel->setWordWrap(true);
    warningLabel->setMinimumWidth(580);

    progressBar = new QProgressBar(this);
    progressBar->setMinimumWidth(400);

    statusLabel = new QLabel(tr("Status:"), this);
    statusLabel->setWordWrap(true);

    updateButton = new QPushButton(tr("&Browse"), this);
    updateButton->setMinimumWidth(100);
    updateButton->setMinimumHeight(50);

    progressTimer = new QTimer();
    progressTimer->setSingleShot(false);
    progressTimer->setInterval(200);

    QString noteText = QString("");
    /* Note: If you experience issues with your screen after a firmware update,
     * please restart your computer.  */

    noteLabel = new QLabel(noteText, this);
    noteLabel->setWordWrap(true);

    uploader = new UploadFirmwareThread(this);
}

void FirmwareUpdate::createConnections()
{
    QObject::connect(updateButton, SIGNAL(clicked()),
                     this, SLOT(startUpdate()));

    QObject::connect(progressTimer, SIGNAL(timeout()),
                     this, SLOT(checkProgress()));

    QObject::connect(uploader, SIGNAL(reReadRequired()),
                     this, SIGNAL(reReadRequired()));

    QObject::connect(uploader, SIGNAL(pauseConnectionCheck(bool)),
                     this, SIGNAL(pauseConnectionCheck(bool)));
}

QLayout * FirmwareUpdate::createLayout()
{
    QVBoxLayout *mainLayout = new QVBoxLayout;
    QVBoxLayout *progressLayout = new QVBoxLayout;
    QVBoxLayout *buttonLayout = new QVBoxLayout;
    QHBoxLayout *centralLayout = new QHBoxLayout;
    QHBoxLayout *warningLayout = new QHBoxLayout;

    progressLayout->addWidget(progressBar);
    progressLayout->addWidget(statusLabel);
    progressLayout->addStretch();

    buttonLayout->addWidget(updateButton);
    buttonLayout->addStretch();

    centralLayout->addStretch();
    centralLayout->addLayout(progressLayout);
    centralLayout->addLayout(buttonLayout);
    centralLayout->addStretch();

    warningLayout->addWidget(importantLabel);
    warningLayout->addWidget(warningLabel);
    warningLayout->addStretch();

    mainLayout->addWidget(descriptionLabel);
    mainLayout->addStretch();
    mainLayout->addWidget(methodLabel);
    mainLayout->addStretch();
    mainLayout->addLayout(warningLayout);
    mainLayout->addStretch();
    mainLayout->addLayout(centralLayout);
    mainLayout->addStretch();
    mainLayout->addWidget(noteLabel);

    mainLayout->setMargin(20);

    return mainLayout;
}

void FirmwareUpdate::clearProgress()
{
    uploadRunning = false;
    statusLabel->setText(tr("Status:"));
    progressBar->setValue(0);
    updateButton->setEnabled(true);
}

void FirmwareUpdate::checkProgress()
{
    QString status = QString(tr("Status:"));
    uint32_t size, remain, done;
    static int i = 0;

    UploadFirmwareThread::UploadState uploadState = uploader->getState();

    switch(uploadState)
    {
        case UploadFirmwareThread::CheckingFile:
            status.append(tr("Checking file ... "));
            progressBar->setValue(0);
            break;
        case UploadFirmwareThread::BAD_CRC:
            status.append(tr("ZYF file has failed the CRC check. Either it is not") +
                tr(" in correct format or it has become corrupted."));
            progressBar->setValue(0);
            emit APIResult(tr("FAILED to update firmware"), ZytAPIResult::Failure);
            progressTimer->stop();
            updateButton->setEnabled(true);
            signalFwXfrState(false);
            uploadRunning = false;
            break;
        case UploadFirmwareThread::SwitchingToBootloader:
            uploadRunning = true;
            i = 0;
            status.append(tr("Switching to Bootloader mode"));
            progressBar->setValue(0);
            break;
        case UploadFirmwareThread::Uploading:
            status.append("Sending data ... ");
            if(SUCCESS == zul_transferFirmwareStatus(&size, &remain))
            {
                done = size - remain;
                progressBar->setRange(0, size);
                progressBar->setValue(done);
                status.append(QString::number(done));
                status.append(" / ");
                status.append(QString::number(size));
            }
            break;
        case UploadFirmwareThread::SwitchingToApplication:
            progressBar->setRange(0, 100);
            progressBar->setValue(100);
            status.append(tr("Switching to Application mode"));
            break;
        case UploadFirmwareThread::FAILED:
            if(SUCCESS == zul_transferFirmwareStatus(&size, &remain))
            {
                done = size - remain;
                progressBar->setRange(0, size);
                progressBar->setValue(done);
            }
            status.append(tr("FAILED!"));
            emit APIResult(tr("FAILED to update firmware"), ZytAPIResult::Failure);
            progressTimer->stop();
            updateButton->setEnabled(true);
            signalFwXfrState(false);
            uploadRunning = false;
            break;
        case UploadFirmwareThread::Done:
            progressBar->setRange(0, 100);
            progressBar->setValue(100);
            status.append(tr("Firmware Update Complete"));
            uploadRunning = false;
            progressTimer->stop();
            updateButton->setEnabled(true);
            signalFwXfrState(false);
            break;
    }

    zul_logf( ZYC_DEBUG, "%05d %s --update -- ", i++, status.toLatin1().data() );

    statusLabel->setText(status);
}

void FirmwareUpdate::startUpdate()
{
    QFileDialog openFWDialog(this, tr("Select Firmware File to Upload"));

    QString prefix = QString ( zul_getZYFFilter() );
    zul_logf ( 3, "%s Filter:%s\n", __FUNCTION__, prefix.toLatin1().data() );

    openFWDialog.setNameFilter(tr("ZYF Zytronic Firmware files") + prefix);
    if(openFWDialog.exec())
    {
        progressTimer->start();
        updateButton->setEnabled(false);
        uploader->setFName(openFWDialog.selectedFiles().at(0));
        uploader->resetState();

        signalFwXfrState(true);
        uploader->start();
        checkProgress();
    }
}

void FirmwareUpdate::showEvent(QShowEvent *Event)
{
    if(QEvent::Show == Event->type())
    {
        // remove previous update status
        clearProgress();
    }

    ZytContentFrame::showEvent(Event);
}
