/*
 *      Content of the sensitivity and thresholds tab in the configuration
 *      tab (ZXY100).
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */

#include "zytypes.h"
#include "protocol.h"
//#include "comms.h"
#include "zxymt.h"
#include "zxy100.h"
#include "zxy110.h"
#include "services.h"

#include "SenseAndThreshFrame.h"

#define MAX_THRESHOLD   (100)
#define MIN_THRESHOLD   (10)

SenseAndThreshFrame::SenseAndThreshFrame(QWidget *parent) :
        ZytContentFrame(parent)
{
    int16_t PID;
    zul_getDevicePID(&PID);

    devPID = PID;

    createWidgets();
    if ((ZXY100_PRODUCT_ID == devPID) || (ZXY110_PRODUCT_ID == devPID) )
    {
        readFromController();
    }
    createConnections();
    setLayout(createLayout());

    zxy100Dat = NULL;
}

void SenseAndThreshFrame::passZxy100Data(Zxy100Data * z100d)
{
    zxy100Dat = z100d;
}

void SenseAndThreshFrame::showOverlay()
{
    senseSlider->showOverlay();
    actSlider->showOverlay();
    deactSlider->showOverlay();
}

void SenseAndThreshFrame::hideOverlay()
{
    senseSlider->hideOverlay();
    actSlider->hideOverlay();
    deactSlider->hideOverlay();
}

void SenseAndThreshFrame::createWidgets()
{
    senseLabel = new QLabel(
        "This page provides a manual control for the Touch Sensitivity, to optimize\r\n"
        "systems where the default settings do not achieve the required operation."
    );
    /*  Android Text:
        This page provides a manual control for the Touch Sensitivity, to optimize
        systems where the default settings do not achieve the required operation.

        Original Windows Text:
        "This page provides a manual override for the touch sensitivity, to cater for\r\n"
        "systems where the Basic Setup has not achieved the required operation."
    */

    senseLabel->setWordWrap(true);
    senseLabel->setMinimumWidth(460);
    senseLabel->setAlignment(Qt::AlignHCenter);
    threshLabel = new QLabel("");
    // new QLabel("Use the sliders below to configure the level that a touch should be detected and released.");
    threshLabel->setWordWrap(true);

    guide = new QPushButton(tr("&Suggested\nSettings"), this);

    //decrease font size
    QFont font = senseLabel->font();
    font.setPointSize( font.pointSize() - 1 );
    senseLabel->setFont(font);
    threshLabel->setFont(font);

    senseSlider = new BigLabeledSlider("Coarse Sensitivity", ZXY100_GLASS_THIN, ZXY100_GLASS_EXTRA_THICK, 1, "+", "-",
                                       0, 0, NULL, this);

    senseSlider->enableReading(false);
    actSlider = new BigLabeledSlider("Activation Threshold", MIN_THRESHOLD, MAX_THRESHOLD, 10, "&+", "&-",
                                     new QKeySequence("+"), new QKeySequence("-"), NULL, this);
    actSlider->enableReading(ZXY100_PRODUCT_ID == devPID);

    deactSlider = new BigLabeledSlider("Deactivation Threshold", MIN_THRESHOLD, MAX_THRESHOLD, 10, "+", "-",
                                       0, 0, NULL, this);
    deactSlider->enableReading(false);

    //create timer to poll for touch every N milli-seconds
    pollingTimer = new QTimer(this);
    pollingTimer->setInterval(250);
    pollingTimer->setSingleShot(false);

    //create buffer timer to prevent constant writes to the controller
    writeThreshChange = new QTimer(this);
    writeThreshChange->setInterval(500);
    writeThreshChange->setSingleShot(true);

    //create buffer timer to prevent constant writes to the controller
    writeSenseChange = new QTimer(this);
    writeSenseChange->setInterval(500);
    writeSenseChange->setSingleShot(true);
}

void SenseAndThreshFrame::readFromController()
{
    uint16_t val;

    if (devPID == ZXY110_PRODUCT_ID)
    {
        CS = ZXY110_CI_GLASS_THICKNESS;
        LT = ZXY110_CI_LOWER_THRESHOLD;
        UT = ZXY110_CI_UPPER_THRESHOLD;
    }
    else
    {
        CS = ZXY100_CI_COARSE_SENSITIVITY;
        LT = ZXY100_CI_LOWER_THRESHOLD;
        UT = ZXY100_CI_UPPER_THRESHOLD;
    }

    if (zul_getConfigParamByID(CS, &val))
    {
        senseSlider->setValue(val);
    }

    if (zul_getConfigParamByID(LT, &val))
    {
        deactSlider->setValue(val);
    }

    if (zul_getConfigParamByID(UT, &val))
    {
        actSlider->setValue(val);
    }
}

void SenseAndThreshFrame::createConnections()
{
    /* All connections made here must be broken in reReadValues()
     */

    /* This could be done in createWidgets(), but is done here
     * in order to have the image updated after values are read
     * or re-read from the controller */
    QObject::connect(senseSlider, SIGNAL(valueChanged(int)),
                     this, SLOT(senseValueChange(void)));

    QObject::connect(actSlider, SIGNAL(valueChanged(int)),
                     this, SLOT(actValueChange(int)));

    QObject::connect(deactSlider, SIGNAL(valueChanged(int)),
                     this, SLOT(deactValueChange(int)));

    QObject::connect(pollingTimer, SIGNAL(timeout()),
                     this, SLOT(pollForTouch()));

    QObject::connect(writeThreshChange, SIGNAL(timeout()),
                     this, SLOT(changeThresholds()));

    QObject::connect(writeSenseChange, SIGNAL(timeout()),
                     this, SLOT(changeSense()));

    QObject::connect(guide, SIGNAL(clicked(void)),
                     this, SLOT(showHelp()));
}

QLayout * SenseAndThreshFrame::createLayout()
{
    QHBoxLayout *frameLayout = new QHBoxLayout;
    QVBoxLayout *mainLayout = new QVBoxLayout;
    QHBoxLayout *senseLayout = new QHBoxLayout;
    QVBoxLayout *threshLayout = new QVBoxLayout;
    QHBoxLayout *threshWrapLayout = new QHBoxLayout;

    senseLayout->addStretch();
    senseLayout->addWidget(senseSlider);
    senseLayout->addStretch();


    threshLayout->addWidget(actSlider);
    threshLayout->addWidget(deactSlider);

    threshWrapLayout->addStretch();
    threshWrapLayout->addLayout(threshLayout);
    threshWrapLayout->addStretch();

    mainLayout->addWidget(senseLabel);
    mainLayout->setAlignment(senseLabel, Qt::AlignHCenter);

    mainLayout->addLayout(senseLayout);
    mainLayout->addWidget(threshLabel);
    mainLayout->addLayout(threshWrapLayout);

    frameLayout->addLayout(mainLayout);
    frameLayout->addWidget(guide);
    frameLayout->setAlignment(guide, Qt::AlignBottom);

    return frameLayout;
}

void SenseAndThreshFrame::senseValueChange(void)
{
    writeSenseChange->start();
}

void SenseAndThreshFrame::actValueChange(int value)
{
    if(value < deactSlider->getValue())
    {
        deactSlider->setValue(value);
    }

    writeThreshChange->start();
}

void SenseAndThreshFrame::deactValueChange(int value)
{
    if(value > actSlider->getValue())
    {
        actSlider->setValue(value);
    }

    writeThreshChange->start();
}

void SenseAndThreshFrame::changeThresholds()
{
    emit APIResult(ZytAPIResult::Progress);

    zul_setConfigParamByID(UT,   actSlider->getValue() );
    zul_setConfigParamByID(LT, deactSlider->getValue() );

    emit APIResult(ZytAPIResult::Success);
    emit thresholdsChanged();
}

void SenseAndThreshFrame::changeSense()
{
    emit APIResult(ZytAPIResult::Progress);
    zul_setConfigParamByID(CS, senseSlider->getValue());
    emit APIResult(ZytAPIResult::Success);
}

void SenseAndThreshFrame::pollForTouch()
{
    uint16_t touchPressure = 17;

    if (zxy100Dat == NULL) return;

    if (SUCCESS != zul_getStatusByID(ZXY100_SI_WIRE_VALUE_MAX, &touchPressure))
    {
        return;
    }

    actSlider->setReading(touchPressure);
}

void SenseAndThreshFrame::reReadValues()
{
    /* Prevent writing back to controller when changing
     * GUI widget values by disconnecting all slots
     * from this object */
    senseSlider->disconnect(this);
    actSlider->disconnect(this);
    deactSlider->disconnect(this);
    pollingTimer->disconnect(this);
    writeThreshChange->disconnect(this);
    guide->disconnect(this);

    readFromController();

    /* re create all the connections */
    createConnections();
}

void SenseAndThreshFrame::showEvent(QShowEvent *Event)
{
    if(QEvent::Show == Event->type())
    {
        pollingTimer->start();
    }

    ZytContentFrame::showEvent(Event);
}

void SenseAndThreshFrame::hideEvent(QHideEvent *Event)
{
    if(QEvent::Hide == Event->type())
    {
        pollingTimer->stop();
    }

    ZytContentFrame::hideEvent(Event);
}


// ==== Z X Y 1 0 0   D A T A =================================================

const QString SenseAndThreshFrame::ZXY100_32_suggestions = QString(
    "<br><center><table cellpadding=\"8\">"

        "<tr>"
        "<th align=\"left\" colspan=\"3\">Coarse Sensitivity</th>"
        "</tr>"

        "<tr>"
        "<th ></th><th> 7\" </th><th> 17\" </th>"
        "</tr>"

        "<tr>"
        "<th>4mm</td><td > 2 </td><td > 2 </td>"
        "</tr>"
        "<tr>"
        "<th>8mm</td><td > 2 </td><td > 2 </td>"
        "</tr>"
        "<tr>"
        "<th>12mm</td><td > 3 </td><td > 3 </td>"
        "</tr>"

        "<tr></tr><tr>"
        "<th align=\"left\" colspan=\"3\">Activation Threshold</th>"
        "</tr>"

        "<tr>"
        "<th ></th><th> 7\" </th><th> 17\" </th>"
        "</tr>"

        "<tr>"
        "<th>4mm</td><td > 26 </td><td > 26 </td>"
        "</tr>"
        "<tr>"
        "<th>8mm</td><td > 17 </td><td > 18 </td>"
        "</tr>"
        "<tr>"
        "<th>12mm</td><td > 25 </td><td > 30 </td>"
        "</tr>"

    "</table></center>"
    );

const QString SenseAndThreshFrame::ZXY100_64_suggestions = QString(
        "<br><center><table cellpadding=\"8\">"

            "<tr>"
            "<th align=\"left\" colspan=\"3\">Coarse Sensitivity</th>"
            "</tr>"

            "<tr>"
            "<th ></th><th> 22\" </th><th> 32\" </th><th> 46\" </th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td > 2 </td><td > 2 </td><td > 2 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td > 3 </td><td > 3 </td><td > 3 </td>"
            "</tr>"
            "<tr>"
            "<th>12mm</td><td > 3 </td><td > 3 </td><td > 3 </td>"
            "</tr>"

            "<tr></tr><tr>"
            "<th align=\"left\" colspan=\"3\">Activation Threshold</th>"
            "</tr>"

            "<tr>"
            "<th ></th><th> 22\" </th><th> 32\" </th><th> 46\" </th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td > 22 </td><td > 23 </td><td > 22 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td > 35 </td><td > 35 </td><td > 33 </td>"
            "</tr>"
            "<tr>"
            "<th>12mm</td><td > 27 </td><td > 29 </td><td > 30 </td>"
            "</tr>"

        "</table></center>"
    );

const QString SenseAndThreshFrame::ZXY100_128_suggestion = QString(
        "<br><center><table cellpadding=\"8\">"

            "<tr>"
            "<th align=\"left\" colspan=\"3\">Coarse Sensitivity</th>"
            "</tr>"

            "<tr>"
            "<th ></th><th> 42\" </th><th> 55\" </th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td > 2 </td><td > 2 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td > 3 </td><td > 3 </td>"
            "</tr>"
            "<tr>"
            "<th>12mm</td><td > 3 </td><td > 3 </td>"
            "</tr>"

            "<tr></tr><tr>"
            "<th align=\"left\"  colspan=\"3\">Activation Threshold</th>"
            "</tr>"

            "<tr>"
            "<th ></th><th> 42\" </th><th> 55\" </th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td > 18 </td><td > 18 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td > 23 </td><td > 27 </td>"
            "</tr>"
            "<tr>"
            "<th>12mm</td><td > 18 </td><td > 24 </td>"
            "</tr>"

        "</table></center>"
    );


// ==== Z X Y 1 1 0   D A T A =================================================
const QString SenseAndThreshFrame::Zxy110_32_suggestions = QString(
        "<br><center><table cellpadding=\"8\">"

            "<tr>"
            "<th align=\"left\" colspan=\"3\" >Coarse Sensitivity</th>"
            "</tr>"

            "<tr>"
            "<th ></th><th> 7\" </th><th> 17\" </th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td > 2 </td><td > 2 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td > 4 </td><td > 4 </td>"
            "</tr>"

            "<tr></tr><tr>"
            "<th align=\"left\" colspan=\"3\" >Activation & Deactivation Thresholds</th>"
            "</tr>"

            "<tr>"
            "<th ></th><th> 7\" </th><th> 17\" </th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td > 21/15 </td><td > 21/15 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td > 21/15 </td><td > 27/20 </td>"
            "</tr>"

        "</table></center>"
    );

const QString SenseAndThreshFrame::Zxy110_64_suggestions = QString( // border=\"1\"
        "<br><center><table cellpadding=\"8\"  >"
            "<tr>"
            "<th align=\"left\" colspan=\"4\">Coarse Sensitivity</th>"
            "</tr>"

            "<tr>"
            "<th></th><th> 22\" </th><th> 32\" </th><th> 42\" </th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td> 2 </td><td > 2 </td><td > 2 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td> 4 </td><td > 4 </td><td > 4 </td>"
            "</tr>"

            "<tr></tr><tr>"
            "<th align=\"left\" colspan=\"4\">Activation & Deactivation Thresholds</th>"
            "</tr>"

            "<tr>"
            "<th ></th><th> 22\" </th><th> 32\" </th><th> 42\" </th>"
            "</tr>"

            "<tr>"
            "<th>4mm</td><td > 21/15 </td><td > 21/15 </td><td > 21/13 </td>"
            "</tr>"
            "<tr>"
            "<th>8mm</td><td > 18/13 </td><td > 26/20 </td><td > 25/18 </td>"
            "</tr>"
        "</table></center>"
    );

const QString SenseAndThreshFrame::Zxy110_128_suggestion = QString(
        "<br><center><table cellpadding=\"8\">"
            "No data available ... "
        "</table></center>"
    );

QString SenseAndThreshFrame::getIntroText(int NumWires)
{
    QString numWireStr = QString(" %1 ").arg(NumWires);
    QString introText = QString("<p>") +
            tr("The table below provides a guide to possible Coarse Sensitivity and Activation Threshold ") +
            tr("settings for various") + numWireStr + tr("wire glass sensors") + "</p><p>" +

            tr("NOTE:  These values are only a guide and may need to be ") +
            tr("optimised to obtain best performance.") + "</p>";
    return introText;
}

QMessageBox *SenseAndThreshFrame::MakeHelpBox(int NumWires, int16_t PID)
{
    QMessageBox *helpBox;
    helpBox = new QMessageBox();

    helpBox->setWindowTitle(tr("Suggested Settings"));
    QString introText = getIntroText(NumWires);

    if (PID == ZXY100_PRODUCT_ID)
    {
        if (NumWires <= 32)
        {
            introText.append( ZXY100_32_suggestions );
        }

        else if (NumWires <= 64)
        {
            introText.append( ZXY100_64_suggestions );
        }

        else if (NumWires <= 128)
        {
            introText.append( ZXY100_128_suggestion );
        }
        else
        {
            introText.append("<b>Wire Count ERROR</b>");
        }
    }

    if (PID == ZXY110_PRODUCT_ID)
    {
        if (NumWires <= 32)
        {
            introText.append( Zxy110_32_suggestions );
        }

        else if (NumWires <= 64)
        {
            introText.append( Zxy110_64_suggestions );
        }

        else if (NumWires <= 128)
        {
           introText.append( Zxy110_128_suggestion );
        }
        else
        {
            introText.append("<b>Wire Count ERROR</b>");
        }
    }

    helpBox->setTextFormat(Qt::RichText);
    helpBox->setText(introText);
    return helpBox;
}

void SenseAndThreshFrame::showHelp()
{
    QMessageBox *helpBox;
    uint16_t    NumWires = 0;

    char hardVers[60] = "";
    int16_t PID;
    bool deviceConnected = zul_getDevicePID(&PID);
    if (!deviceConnected) return ;

    if(SUCCESS != zul_Hardware(hardVers, 60))
    {
        return ;
    }

    {
        ZXY_sensorSize sz;
        if (zul_getSensorSize(&sz))
        {
            NumWires = sz.xWires + sz.yWires;
        }
    }

    helpBox = MakeHelpBox( NumWires, PID);

    helpBox->setIcon(QMessageBox::Information);
    helpBox->setStandardButtons(QMessageBox::Ok);
    helpBox->setModal(true);
    Qt::WindowFlags wFlags = helpBox->windowFlags();

    if(Qt::WindowCloseButtonHint == (wFlags & Qt::WindowCloseButtonHint))
    {
        wFlags = wFlags ^ Qt::WindowCloseButtonHint;
        helpBox->setWindowFlags(wFlags);
    }
    helpBox->setDefaultButton(QMessageBox::Ok);

    helpBox->exec();
    delete helpBox;
}


QString SenseAndThreshFrame::getText(int16_t pid)
{
    QString text;
    QMessageBox *helpBox;

    switch (pid)
    {
        default:
            text = QString("Bad PID; 100/110 only");
            break;
        case ZXY100_PRODUCT_ID:
            text = QString("ZXY100 suggestions:\n");
            helpBox = MakeHelpBox(32, ZXY100_PRODUCT_ID);
            text.append( helpBox->text() + "\n" );
            delete helpBox;
            helpBox = MakeHelpBox(64, ZXY100_PRODUCT_ID);
            text.append( helpBox->text() + "\n" );
            delete helpBox;
            helpBox = MakeHelpBox(128, ZXY100_PRODUCT_ID);
            text.append( helpBox->text() + "\n" );
            delete helpBox;
            break;
        case ZXY110_PRODUCT_ID:
            text = QString("ZXY110 suggestions:\n");
            helpBox = MakeHelpBox(32, ZXY110_PRODUCT_ID);
            text.append( helpBox->text() + "\n" );
            delete helpBox;
            helpBox = MakeHelpBox(64, ZXY110_PRODUCT_ID);
            text.replace("</hr>", "\n");
            text.replace("</tr>", "\n");
            text.append( helpBox->text() + "\n" );
            delete helpBox;
            break;
        case UNKNWN_PRODUCT_ID:
            text = getIntroText(99)+ "\n";
            break;
    }
    text.replace("</hr>", "\n");
    text.replace("</tr>", "\n");
    text.replace("</p>", "\n");
    text.replace(QRegularExpression("<.+?>"), "");
    return text;
}
