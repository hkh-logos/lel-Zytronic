/*
 *      Widget to show information about the controller connected and
 *      the platform the application is running on. This is expected to
 *      be at the bottom of the application window.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <stdio.h>
#include "SysInfoDisplay.h"
#include "services.h"
#include "services_sc.h"
#include "usb.h"

#define SYS_INF_MAX (255)

SysInfoDisplay::SysInfoDisplay(QWidget *parent) :
        QWidget(parent)
{
    createWidgets();

    QPalette pal = palette();
    pal.setColor(QPalette::Foreground, QColor(Qt::darkGreen));
    setPalette(pal);

    setLayout(createLayout());

    setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
}

void SysInfoDisplay::createWidgets()
{
    touchInfo = new QLabel(getTouchInfo(),this);
    systemInfo = new QLabel(getSysInfo(),this);
}

#if ( defined(Q_OS_LINUX) || defined(Q_OS_DARWIN) )

QString SysInfoDisplay::getSysInfo()
{
    FILE *pFile = popen("uname -r", "r");
    QFile file1, file2;

    // Get the first line of output from the command.
    // The second line is empty
#if defined(Q_OS_DARWIN)
    char str[SYS_INF_MAX+1] = "Darwin: ";
#else
    char str[SYS_INF_MAX+1] = "Linux: ";
#endif


    if (!file1.open(pFile, QIODevice::ReadOnly))
    {
        pclose(pFile);
    }
    if (!file1.atEnd())
    {
        file1.readLine(str + strlen(str), SYS_INF_MAX - 10);
    }
    pclose(pFile);

    // remove trailing carriage return as it made the layout look nasty
    if (strlen(str) > 1)
    {
        str[strlen(str) - 1] = '\0';
    }
    strcat(str, " - ");

    pFile = popen("uname -m", "r");
    if (!file2.open(pFile, QIODevice::ReadOnly))
    {
        pclose(pFile);
    }
    if (!file2.atEnd())
    {
        file2.readLine(str + strlen(str), SYS_INF_MAX - 50);
    }
    pclose(pFile);

    // remove trailing carriage return as it made the layout look nasty
    if (strlen(str) > 1)
    {
        str[strlen(str) - 1] = '\0';
    }

    // append the USB address in use
    char usbAddr[21] = "   -  USB Addr=";
    int retVal = zul_getAddrStr(usbAddr+15);
    if (SUCCESS == retVal)
    {
        usbAddr[20] = '\0';
        strcat(str, usbAddr);
    }

    // #### FIXME - translation : use a stringbuilder rather than C string lib funcs

    str[SYS_INF_MAX] = '\0';

    return QString(str);
}

#else

QString SysInfoDisplay::getSysInfo()
{
    return QString(tr("Unable to obtain system information"));
}

#endif

/*
static int hasCustomization(const char *s)
{
    if (! strcmp(s, "-c-")) return 0;  // no customization data available
    return strcmp(s, "1");  // if different, we have some customization
} -- not used as yet -- */


QString getBootLdrInfo(int16_t PID)
{
    QString failureText(QObject::tr("Controller Connected: Not Found."));

    char hardVers[60];
    char bootVers[60];

    if (PID == ZXY100_BOOTLDR_ID)
    {
        zul_old_BLgetVersion();
        zul_BLgetVersionFromResponse(bootVers, 60);
        // printf("HW %s\n", bootVers);
        strcpy( hardVers, "ZXY100");
    }
    else
    {
        // VerIndex::  STR_BL, STR_FW, STR_HW, STR_AFC
        if(SUCCESS != zul_BLgetVersion (hardVers, 60,  STR_HW))
        {
            return failureText;
        }
        // printf("HW %s\n", hardVers);

        if(SUCCESS != zul_BLgetVersion (bootVers, 60, STR_BL))
        {
            strcpy(bootVers, "-b-");
            //return failureText;
        }
        //printf("HW %s\n", bootVers);
    }
    QString contInf(QObject::tr("Bootloader Device Connected: "));
    contInf += QString(hardVers) + ", " + QObject::tr("Version: ") + QString(bootVers);
    return contInf;
}

QString SysInfoDisplay::getTouchInfo()
{
    QString failureText(QObject::tr("Controller Connected: Not Found."));
    QString commTypeText;

    char firmVers[60] = "";
    char hardVers[60] = "";
    char bootVers[60] = "";
    char custVers[60] = "";

    int16_t PID;
    bool deviceConnected = zul_getDevicePID(&PID);

    if (!deviceConnected) return tr("No Device");

    if (zul_isBLDevicePID(PID))
    {
        return getBootLdrInfo(PID);
    }

    if(SUCCESS != zul_Hardware(hardVers, 60))
    {
        strcpy(hardVers, "-h-");
        return failureText;
    }
    if(SUCCESS != zul_Firmware(firmVers, 60))
    {
        strcpy(firmVers, "-f-");
    }
    if(SUCCESS != zul_Customization(custVers, 60))
    {
        strcpy(custVers, "-c-");
    }
    if(SUCCESS != zul_Bootloader(bootVers, 60))
    {
        strcpy(bootVers, "-b-");
    }

    commTypeText = "U-OFF-";

    QString contInf(tr("Controller Connected: "));

    contInf += "" + QString(hardVers) + ", " + tr("Firmware: ") + QString(firmVers) +
            tr(", Bootloader: ") + QString(bootVers);
    //if (hasCustomization(custVers))
    //{
    //    contInf += tr(", Customization: ") + QString(custVers);
    //}

    return contInf;
}

void SysInfoDisplay::clearControllerInfo()
{
    touchInfo->setText(tr("No controller connected \n"));
    systemInfo->setText(getSysInfo());
}


void SysInfoDisplay::refreshTouchInfo()
{
    touchInfo->setText(getTouchInfo());
    systemInfo->setText(getSysInfo());
}

QLayout * SysInfoDisplay::createLayout()
{
    // QHBoxLayout *mainLayout = new QHBoxLayout;
    QVBoxLayout *infoLayout = new QVBoxLayout;
    QHBoxLayout *touchLayout = new QHBoxLayout;
    QHBoxLayout *systemLayout = new QHBoxLayout;

    touchLayout->addStretch();
    touchLayout->addWidget(touchInfo);
    touchLayout->addStretch();

    systemLayout->addStretch();
    systemLayout->addWidget(systemInfo);
    systemLayout->addStretch();

    infoLayout->addLayout(touchLayout);
    infoLayout->addLayout(systemLayout);

    // mainLayout->addLayout(infoLayout);

    // FIXME required ??
    // touchInfo->setText(getTouchInfo());

    return infoLayout;
}
