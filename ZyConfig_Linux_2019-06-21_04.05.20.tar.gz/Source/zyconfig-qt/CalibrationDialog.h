/*
 *      Calibration Widget. Displays a number of points on the screen in order
 *      to calculate calibration data and then write it to the controller
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef CALIBRATIONDIALOG_H
#define CALIBRATIONDIALOG_H

#include <QDialog>
#include <ZytAPIResult.h>

#include "services.h"
//#include "Monitor.h"
#include "MonitorSelect.h"

class CalibrationDialog : public QDialog
{
    Q_OBJECT

public:
    CalibrationDialog           (QWidget *parent = 0);
    void    setMonitor          (Monitor *mon);
    QString getMonitorForDevice (void);
    void    setMonitorForDevice (const char *monName);
    void    setCustomMargins    (int topMargin, int bottomMargin, int leftMargin, int rightMargin);
    void    setDefaultMargins   (void);

    static const QString    screenModeStr;
    static const QString    dualScreenOptions ;

signals:
    void APIResult              (ZytAPIResult::ResultState state);

public slots:
    int  exec                   ();
    void enableInfo             (bool info);
    void setTimeOut             (int timeout);
    void enableConfirm          (bool info);
    int  setScreenMode          (QString);

protected:
    void paintEvent             (QPaintEvent*);
    void touchRelease           (QPoint *actual);

private slots:
    void tick                   ();

private:

    enum ScreenMode {SingleScreen, DualLeft, DualRight, DualTop, DualBottom, MultiScreen};

    void getScreenLoc           (int i, QPoint *p);
    void drawTarget             (QPoint centre, int radius, QPainter *painter);
    void setCalibrationPoint    (int index);
    void positionCancelBox      (int width, int height, int cBorder, int index, QPoint *topLeft, QPoint *bottomRight);
    void storeCalibrationPoint  (QPoint actual);

    void handleDualScreenSetup  (void);
    void handleMultiScreenSetup (void);

    void calibrate();

    void auto_fix_axes          (void);
    void set_axis_options       (bool xy, bool x, bool y);

    void switchXYPoint          (QPoint *in);
    void flipXPoint             (QPoint *in);
    void flipYPoint             (QPoint *in);

    ScreenMode          screenMode;
    QVector <QPoint>    idealPoints;
    QVector <QPoint>    actualPoints;
    QVector <QPoint>    screenPoints;
    QPoint              currentPoint, currentSensorIdeal;
    QSize               desktopSize;
    int                 currentPointIndex;
    int                 targetMarginLeft;
    int                 targetMarginRight;
    int                 targetMarginTop;
    int                 targetMarginBottom;
    int                 timeRemain, activeTimeOut;
    bool                showInfo, askConfirm, mZxy100Data, touchAvailable;
    QTimer             *touchMonitorTick;
    Calibration         calibrationResult;
    QRect               textBox;
    int                 border;

    int16_t             devPID;
    Monitor             selectedMonitor;
    QRect               monitorRect;
    QString             monitorName;
    float               qtScaleFactor;
};

#endif // CALIBRATIONDIALOG_H
