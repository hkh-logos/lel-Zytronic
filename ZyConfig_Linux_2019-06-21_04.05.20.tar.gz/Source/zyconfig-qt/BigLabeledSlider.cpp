/*
 *      A widget containing a slider and two buttons to increase or decrease the value of
 *      the slider. The slider also has a descriptive label showing the current value above
 *      it.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "BigLabeledSlider.h"

#define FONT_SIZE   (10)

BigLabeledSlider::BigLabeledSlider( QString sliderLabelText, int rangeStart, int rangeEnd, int pageStep,
                                    QString inc, QString dec, QKeySequence *incKey, QKeySequence *decKey,
                                    QLabel *imageLabel, QWidget *parent) :
    QWidget(parent)
{
    labelTranslator = NULL;
    labelBase = sliderLabelText;
    mainLabel = imageLabel;
    curReading = NULL;

    createWidgets(rangeStart, rangeEnd, pageStep, inc, dec, incKey, decKey);
    createConnections();
    setLayout(createLayout());
}

void BigLabeledSlider::showOverlay()
{
    int overlayY = down->geometry().bottomLeft().y() - 23;
    int decX = down->geometry().bottomLeft().x() + 5;
    int incX = up->geometry().bottomLeft().x() + 5;

    decOverlay->setGeometry(QRect(decX, overlayY, 12, 20));
    incOverlay->setGeometry(QRect(incX, overlayY, 12, 20));

    decOverlay->show();
    incOverlay->show();
}

void BigLabeledSlider::hideOverlay()
{
    decOverlay->hide();
    incOverlay->hide();
}

void BigLabeledSlider::createWidgets(int rangeStart, int rangeEnd, int pageStep, QString inc,
                                        QString dec, QKeySequence *incKey, QKeySequence *decKey)
{
    down = new QPushButton(dec,this);
    down->setFixedSize(BUTTON_SIZE,BUTTON_SIZE);

    if (0 != incKey)
    {
        shortcut = new QShortcut(*decKey, this->parentWidget());
        QObject::connect(shortcut, SIGNAL(activated()),
                         down, SLOT(animateClick()));
    }

    up = new QPushButton(inc,this);
    up->setFixedSize(BUTTON_SIZE,BUTTON_SIZE);

    if (0 != decKey)
    {
        shortcut = new QShortcut(*incKey, this->parentWidget());
        QObject::connect(shortcut, SIGNAL(activated()),
                         up, SLOT(animateClick()));
    }

    slider = new QSlider(Qt::Horizontal,this);
    slider->setRange(rangeStart, rangeEnd);
    slider->setPageStep(pageStep);
    if( rangeEnd - rangeStart < 25 )
    {
        slider->setTickInterval(1);
    }
    else if( rangeEnd - rangeStart < 125 )
    {
        slider->setTickInterval( 3 );
    }
    else
    {
        slider->setTickInterval( 25 );
    }
    slider->setTickPosition(QSlider::TicksBelow);       //NoTicks ?
    slider->setFixedWidth(SLIDER_WIDTH);
    //slider->setStyleSheet("QSlider::add-page:...");
    //slider->setStyleSheet("QSlider::sub-page:...");

    label = new QLabel(labelBase);
    QFont font = label->font();
    font.setPointSize(FONT_SIZE);
    label->setFont(font);
    label->setStyleSheet("QLabel { color : green; }");
    changeLabel(slider->value());

    curReading = new QProgressBar(this);
    curReading->setRange(0, rangeEnd);
    curReading->setValue(0);
    // magic fix value 12 as sliders are wider than their 'track'
    curReading->setFixedWidth(SLIDER_WIDTH-12);
    curReading->setFixedHeight(READING_HGHT);
    curReading->setVisible(false);
    curReading->setFormat(""); // windows can't do this .."Signal Level: %v"
    /* curReading->setStyleSheet(" QProgressBar::chunk { background: lightgreen; "
        "border-bottom-right-radius: 6px; border-top-right-radius: 6px; "
        "border-bottom-left-radius: 6px; border-top-left-radius: 6px; "
        "border: 1px lightgray; } ");  */

    readingLabel = new QLabel(tr("Signal Level") + ": 0");
    readingLabel->setFont(font);
    readingLabel->setStyleSheet("QLabel { color : green; }");
}

void BigLabeledSlider::createConnections()
{
    QObject::connect(slider, SIGNAL(valueChanged(int)),
                     this,   SLOT(changeLabel(int)));

    QObject::connect(up,     SIGNAL(pressed()),
                     this,   SLOT(upPressed()));

    QObject::connect(down,   SIGNAL(pressed()),
                     this,   SLOT(downPressed()));
}

QLayout * BigLabeledSlider::createLayout()
{
    QVBoxLayout *blsLayout = new QVBoxLayout;
    QHBoxLayout *mainLayout = new QHBoxLayout;
    QHBoxLayout *labelLayout = new QHBoxLayout;
    QVBoxLayout *sliderLayout = new QVBoxLayout;

    labelLayout->addWidget(label);
    labelLayout->setAlignment(label, Qt::AlignHCenter);

    sliderLayout->addLayout(labelLayout);
    sliderLayout->addWidget(slider);
    sliderLayout->addWidget(curReading);
    sliderLayout->addWidget(readingLabel);
    sliderLayout->setSpacing(0);
    sliderLayout->setMargin(0);
    sliderLayout->setAlignment(slider, Qt::AlignHCenter);
    sliderLayout->setAlignment(curReading, Qt::AlignHCenter);
    sliderLayout->setAlignment(readingLabel, Qt::AlignHCenter);

    mainLayout->setAlignment(Qt::AlignVCenter);
    mainLayout->addWidget(down);
    mainLayout->addLayout(sliderLayout);
    mainLayout->addWidget(up);

    //mainLayout->setSizeConstraint(QLayout::SetFixedSize);

    blsLayout->addLayout(mainLayout);
    if(mainLabel != 0)
    {
        blsLayout->addSpacing(SPACER_SIZE);
        blsLayout->addWidget(mainLabel);
        blsLayout->setAlignment(mainLabel, Qt::AlignCenter);
    }

    return blsLayout;
}

int BigLabeledSlider::getValue()
{
    return slider->value();
}

void BigLabeledSlider::setValue(int value)
{
    slider->setValue(value);
    changeLabel(value);
}

void BigLabeledSlider::setEnabled(bool value)
{
    slider->setEnabled(value);
    up->    setEnabled(value);
    down->  setEnabled(value);
}


void BigLabeledSlider::changeLabel(int value)
{
    QString labelText = QString("%1: ").arg(labelBase);

    if (labelTranslator == NULL)
    {
        labelText.append(QString::number(value));
    }
    else
    {
        labelText.append(labelTranslator(value));
    }

    label->setText(labelText);
    emit valueChanged(value);
}

void BigLabeledSlider::upPressed()
{
    slider->setValue(slider->value() + 1);
}

void BigLabeledSlider::downPressed()
{
    slider->setValue(slider->value() - 1);
}

void BigLabeledSlider::LabelValTranslator( char* (*func) (int val) )
{
    labelTranslator = func;
    changeLabel( getValue() );
}

void BigLabeledSlider::enableReading(bool enabled)
{
    curReading->setVisible(enabled);
    readingLabel->setVisible(enabled);
}

void BigLabeledSlider::setReading(int rValue)
{
    curReading->setValue(rValue);
    readingLabel->setText(QString("Signal Level: %1").arg(rValue));
}
