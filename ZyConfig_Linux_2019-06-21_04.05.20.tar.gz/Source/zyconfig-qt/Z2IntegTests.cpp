/*
  Z2IntegTests
  ============

  This class is designed to execute a set of tests on a Zytronic touchscreen
  controller, while connected correctly to an appropriate sensor.  Following
  the test run, a user should be provided with a confirmation of correct
  integration, or some guidance on how to improve the setup.

  This code was written to cover the following devices:
    - ZXY100-U-OFF-*
    - ZXY110-U-OFF-*
    - ZXY150-U-OFF-*, ZXY200-U-OFF-*, ZXY300-U-OFF-*,
    - ZXY50-U-OFF-*

  Items covered are:
    - correct/complete flexi-tail connections
    - sensor plot validity
    - electro-magnetic noise effecting the sensor

  NB: a PASS on these tests should not be taken as evidence that a system is
      fault-free!

      In general, adherence to the guidance available in the touchscreen user
      manual will provide a system that can pass all tests.

  ToDo : How can we separate the 3 statemachines from this module,
         so that they could be loaded into a generic test-runner?
            a) load test definition data files
            b) inheretance - specialisation
            c) load polymorphic test classes into a generic test runner
                    - test factory?
   How do we find generally accepted pattern ?

*/


/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */

// set to true with debug on to observe all tests FAILing - helps reviewing
static const int FailAll        =  0;
static const int DebugMode      =  0;

// --- logging macros --------------------------------
#define GET_STATUS_VAL( A, B )                       \
    zul_getStatusByID( (A), &(B) );                  \
    integTestLog->Write2LogF("Get %-31s %d", #A, (B) );

#define SET_CONFIG_PARAM( A, B )                     \
    zul_setConfigParamByID( (A), (B) );              \
    integTestLog->Write2LogF("SET %-31s %d", #A, (B) );

#define GET_CONFIG_PARAM( A, B )                     \
    zul_getConfigParamByID( (A), &(B) );             \
    integTestLog->Write2LogF("GET %-31s %d", #A, (B) );
// ---------------------------------------------------

#include <stdio.h>
#include <time.h>

#include "debug.h"
#include "Z2IntegTests.h"
#include "SysInfoDisplay.h"

// Self Capacitance raw data capture period:
static const int Z1NoiseCapT    =  5;  //  ToDo:  or 10, or 20;

#define Z1_SAMPLE_MSEC          (25)    // data arrival from controller was measured every 30 ms
#define MeanWireValThreshold    (5.0)   // from c# for ZXY100 tests     -- ToDo use static const float
#define StdDevWireValThreshold  (2.5)   // from c# for ZXY100 tests

/** From Windows ZyConfig -- see zxymt.h
 *  ZXY_Multitouch: bitfields of STATUS_ACTIVE    */
const int STATUS_PALM_REJECT_BIT        = 0x0001;
const int STATUS_INACTIVE_BIT           = 0x0002;
const int STATUS_FIRST_TOUCH_MODE_BIT   = 0x0004;
const int STATUS_INHIBIT_BIT            = 0x0008;
const int STATUS_TOUCH_ACTIVE_BIT       = 0x0010;


static QString integrationHint;

static const Z2IntegTests::IT_StateDefn integTestsRef_MT[] =
{
    //Name                              ITState Enum Ident                   Delay  Visible
    {QObject::tr("InitDelay"),          Z2IntegTests::MT_InitDelay,             1,   false},

    {QObject::tr("Sensor Detected"),    Z2IntegTests::SensorDetect,             3,   true},
    {QObject::tr("Sensor Integrity"),   Z2IntegTests::SensorIntegrity,          1,   true},

    {"pause1",                          Z2IntegTests::TSpause1,                 1,   false},

    {QObject::tr("Noise Detection 1"),  Z2IntegTests::SensorQuiet,              5,   true},

    // These 3 test are for ZXY150, 200 and 300, not ZXY500
    {QObject::tr("Noise Detection 2"),  Z2IntegTests::FirstTouchMode,           5,   true},
    {QObject::tr("Noise Detection 3"),  Z2IntegTests::DetectedNoise,            1,   true},
    {QObject::tr("Noise Rejection"),    Z2IntegTests::NoiseRejection,           1,   true},

    {"pause2",                          Z2IntegTests::TSpause2,                 1,   false},

    {QObject::tr("Frame Rate"),         Z2IntegTests::FrameRate,                1,   true},

    // This test was removed
    // {QObject::tr("Controller Faults"),  Z2IntegTests::Faults,                1,   true},

    {"done",                            Z2IntegTests::MT_Finished,              1,   false},
    {"ERROR",                           Z2IntegTests::LastState,                1,   false},
};

static const Z2IntegTests::IT_StateDefn integTestsRef_ZXY100[] =
{
    //Name                              ITState Enum Ident                   Delay  Visible
    {QObject::tr("Initialise"),         Z2IntegTests::Z100_InitDelay,           3,   false},
    {QObject::tr("Capture Data W"),     Z2IntegTests::Z100_Capture_W,  Z1NoiseCapT,  false},
    {QObject::tr("Capture Data B"),     Z2IntegTests::Z100_Capture_B,  Z1NoiseCapT,  false},

    {QObject::tr("Capture Data Test"),  Z2IntegTests::Z100_Capture_Rslt,        1,   true},

    {"pause1",                          Z2IntegTests::Z100pause1,               1,   false},
    {QObject::tr("70% Threshold"),      Z2IntegTests::Z100_SIG_70PC_THRESHOLD,  1,   true},
    {QObject::tr("50% Threshold"),      Z2IntegTests::Z100_SIG_50PC_THRESHOLD,  1,   true},
    {QObject::tr("30% Threshold"),      Z2IntegTests::Z100_SIG_30PC_THRESHOLD,  1,   true},

    {"pause2",                          Z2IntegTests::Z100pause2,               1,   false},
    {QObject::tr("Signal Mean Test"),   Z2IntegTests::Z100_MEAN_VALUES,         1,   true},
    {QObject::tr("Signal Activity"),    Z2IntegTests::Z100_STDDEV_VALUES,       1,   true},

    {"pause3",                          Z2IntegTests::Z100pause3,               1,   false},
    {QObject::tr("Noise Counters"),     Z2IntegTests::Z100_NOISE_ALGO_COUNTS,   1,   true},
    {QObject::tr("Equalisation Count"), Z2IntegTests::Z100_EQ_COUNTS,           1,   true},
    {QObject::tr("Noise Recoveries"),   Z2IntegTests::Z100_NOISE_FIX_EVENTS,    1,   true},

    {"done",                            Z2IntegTests::Z100_Finished,            1,   false},
    {"ERROR",                           Z2IntegTests::LastState,                1,   false},
};

static const Z2IntegTests::IT_StateDefn integTestsRef_ZXY110[] =
{
    //Name                              ITState Enum Ident                   Delay  Visible

    {QObject::tr("Initialise"),         Z2IntegTests::Z110_InitDelay,           2,   false},

    {QObject::tr("Stable Frequency"),   Z2IntegTests::Z110_STABILIZING_UP,     10,   false},

    {QObject::tr("Stable Eq1"),         Z2IntegTests::Z110_STABILIZING_EQ_1,   30,   false},
    {QObject::tr("Stable FTM"),         Z2IntegTests::Z110_STABILIZING_FTM,     2,   false},
    {QObject::tr("Stable Device"),      Z2IntegTests::Z110_STABILIZING_EQ_2,   30,   true},

    {QObject::tr("Equalise Trigger"),   Z2IntegTests::Z110_EQUALISE,            1,   false},
    {QObject::tr("Equalise"),           Z2IntegTests::Z110_EQUALISE_WAIT,      30,   true},

    {QObject::tr("Capture Data W"),     Z2IntegTests::Z110_Capture_W,  Z1NoiseCapT,  false},
    {QObject::tr("Capture Data B"),     Z2IntegTests::Z110_Capture_B,  Z1NoiseCapT,  false},

    {QObject::tr("Capture Data Test"),  Z2IntegTests::Z110_Capture_Rslt,        1,   true},

    {QObject::tr("70% Threshold"),      Z2IntegTests::Z110_RAW_DATA_70pc_HITS,  1,   true},
    {QObject::tr("50% Threshold"),      Z2IntegTests::Z110_RAW_DATA_50pc_HITS,  1,   true},
    {"pause1",                          Z2IntegTests::Z110pause1,               1,   false},
    {QObject::tr("Signal Mean"),        Z2IntegTests::Z110_RAW_DATA_MEANXY,     1,   true},
    {QObject::tr("Signal Activity"),    Z2IntegTests::Z110_RAW_DATA_StdDevXY,   1,   true},
    {"pause2",                          Z2IntegTests::Z110pause2,               1,   false},

    {"StatusTests",                     Z2IntegTests::Z110_CHECK_STATUS_VALUES, 1,   true},
    {"done",                            Z2IntegTests::Z110_Finished,            1,   false},

    {"ERROR",                           Z2IntegTests::LastState,                1,   false},
};



/**********************************************************
 * Constructor
 **********************************************************/
Z2IntegTests::Z2IntegTests(QWidget *parent) :
    QDialog(parent)
{
    integrationHint =
        QObject::tr("Increase air gap between sensor and display, ") +
        QObject::tr("improve grounding, run Basic Setup. ");

    InitMeasurementData();

    integTestLog = new ZyLogFile("/tmp/IntegrationTest.log");
    integTestLog->WipeFile();
    integTestLog->EnableTimeStamp(true);
    integTestLog->Write2Log("Z2IntegTest - Construction");

    versAppStr.clear();
    border = 0;
    recommendation = QString("");

    // Default setup is MT
    zxy100Data = NULL;

    //create timeout timer
    secondTick = new QTimer(this);
    QObject::connect(secondTick,SIGNAL(timeout()), this,SLOT(changeState()));

    // setup the raw data polling timer
    pollingTimer.setInterval(Z1_SAMPLE_MSEC);
    pollingTimer.setSingleShot(false);
    QObject::connect( &pollingTimer, SIGNAL(timeout()), this, SLOT(collectNewRawData()) );

    advancedMode = false;

    testStateMap = new QMap<ITState, IT_StateRunData*>();

    integTestLog->Write2Log("Integration Tests Created");
    pAssignedMonitor = NULL;
    zxy100DataBlack = NULL;
    zul_logf(3, "NEW Z2IntegTests");
}

// destructor - ToDo.
//  free : IT_StateRunData.IntegrationTest , zxy100DataBlack, ZyLogFile
//  QT handles QMap, QTimer,


void Z2IntegTests::InitMeasurementData(void)
{
    numActiveCells=0;
    xF=0, xL=0, yF=0, yL=0;    // xFirst, .. yLast
    xR=0, yR=0;                // numActiveRows / numActiveColumns

    statusOrSincePrevious=0;
    statusAndSincePrevious=0;
    numLiveRow=0;
    numLiveCol=0;
    numResampled=0;
    frameRate=0;
    firstTouchModeSetting=0;
    firstTouchModeOffThreshold=0;
    firstTouchModeOnThreshold=0;
    failed50pcTest = false;
    ControllerID = QString("000000000000000000000000");

    zxy110initState.uptime = 0;
    zxy110TestState.uptime = 0;
}

void Z2IntegTests::setAdvancedMode(bool mode)
{
    advancedMode = mode;
}

// set display monitor for graphic output
void Z2IntegTests::setMonitor(Monitor *m)
{
    pAssignedMonitor = m;
    pAssignedMonitor->getRect(&monitorRect);
}


/*
 */
int Z2IntegTests::expectedWires(WireID rowORcol)
{
    int wireCount = 0;

    if (rowORcol == Y_WIRES)
    {
        switch (devPID)
        {
            case ZXY150_PRODUCT_ID:
                wireCount = 24;
                break;

            default:
            case ZXY200_PRODUCT_ID:
                wireCount = 24 * 2;
                break;

            case ZXY300_PRODUCT_ID:
                wireCount = 24 * 4;
                break;
        }
    }
    else
    {
        switch (devPID)
        {
            case ZXY150_PRODUCT_ID:
                wireCount = 32;     // not 40 !
                break;

            default:
            case ZXY200_PRODUCT_ID:
                wireCount = 40 * 2;
                break;

            case ZXY300_PRODUCT_ID:
                wireCount = 40 * 4;
                break;
        }
    }
    return wireCount;
}

/**
 *
 */
int Z2IntegTests::desiredFrameRate(void)
{
    switch (devPID)
    {
        case ZXY100_PRODUCT_ID:
        case ZXY110_PRODUCT_ID:
            return 200;

        case ZXY150_PRODUCT_ID:
        case ZXY200_PRODUCT_ID:
        case ZXY300_PRODUCT_ID:
        case ZXY500_PRODUCT_ID:
        case ZXY500_PRODUCT_ID_ALT1:
            return 120;

        default:
            return 50;
    }
    return 50;
}

/**
 * IF testing ZXY100 devices, call 'setZXY100Data()' before this
 * to set the zxy100Data pointer !
 */
void Z2IntegTests::initData(void)
{
    const Z2IntegTests::IT_StateDefn * ref = NULL;
    const Z2IntegTests::IT_StateDefn * refSrc = NULL;

    Title       = QString(QObject::tr("Integration Tests in progress... * DO NOT TOUCH THE SENSOR *"));
    exitStr     = QString("");
    blackScreen = false;

    InitMeasurementData();
    zul_getDevicePID(&devPID);

    // load the reference data into the runtime structures
    switch (devPID)
    {
        case ZXY100_PRODUCT_ID:
            refSrc = ref = integTestsRef_ZXY100;
            currentTest  = Z100_InitDelay;
            break;

        case ZXY110_PRODUCT_ID:
            refSrc = ref = integTestsRef_ZXY110;
            currentTest  = Z110_InitDelay;
            break;

        case ZXY150_PRODUCT_ID:
        case ZXY200_PRODUCT_ID:
        case ZXY300_PRODUCT_ID:
        case ZXY500_PRODUCT_ID:
        case ZXY500_PRODUCT_ID_ALT1:
            refSrc = ref = integTestsRef_MT;
            currentTest  = MT_InitDelay;
            break;
        // ToDo - default ...?
    }

    // clear out any previous data
    QMap<ITState, IT_StateRunData*>::iterator i;
    for (i = testStateMap->begin(); i != testStateMap->end(); ++i)
    {
        IntegrationTest *pTstDspData = i.value()->dispData;

        switch (i.value()->state)
        {
            // for most cases, clean up the display data for the state
            default:
                // proceed to delete
                if (pTstDspData != NULL)
                {
                    delete pTstDspData;  // ToDo set pointer to NULL ?
                }
                [[gnu::fallthrough]];
                // intended fallthrough

            case Z100_InitDelay:
            case Z100_Capture_W:
            case Z100_Capture_B:
                // don't delete the display data more than once,
                // it belongs to Z100_Capture_Rslt
                delete i.value();
                break;

            case Z110_InitDelay:
            case Z110_STABILIZING_UP:
            case Z110_STABILIZING_EQ_1:
            case Z110_STABILIZING_FTM:
            case Z110_EQUALISE:
            case Z110_Capture_W:
            case Z110_Capture_B:
                // don't delete the display data more than once,
                // it belongs to a VISIBLE state
                delete i.value();
                break;
        }
    }
    testStateMap->clear();

    if (ref==NULL) return;  // ToDo - terminate process ?

    // load the test plan with the reference data
    while ( ( ref->state != Z2IntegTests::MT_Finished ) &&
            ( ref->state != Z100_Finished ) &&
            ( ref->state != Z110_Finished )
          )
    {
        integTestLog->Write2LogF("Add %s test-state %d:%s.\n",
                                    (ref->visible) ? "visible" : "hidden ",
                                    ref->state,
                                    ref->name.toLatin1().data() );

        IT_StateRunData *runDat = new IT_StateRunData;

        runDat->elapsedSecs  = 0;
        runDat->state        = ref->state;
        runDat->durationSecs = ref->durationSecs;
        runDat->visible      = ref->visible;
        runDat->dispData     = NULL;

        // ZXY500 drops several traditional ZXY200 tests.
        if ( zul_isZXY500AppPID(&devPID) )
        {
            switch (runDat->state)
            {
                case FirstTouchMode:
                case DetectedNoise:
                case NoiseRejection:
                    runDat->visible = false;
                    break;
                default:
                    break;
            }
        }

        if (runDat->visible)
        {
            IntegrationTest *dspDat = new IntegrationTest(ref->name, this);
            dspDat->setLargeFonts(false);       // updated later if needed
            dspDat->setTestPass(QString("..."));
            dspDat->setTestComment(QString(":::"));
            runDat->dispData = dspDat;
        }

        // record the running datastore state-machine dictionary
        testStateMap->insert(ref->state, runDat);
        ref++;
    }

    // reuse some display instances
    if (refSrc == integTestsRef_ZXY100)
    {
        IT_StateRunData *stateData;

        IT_StateRunData *displayStateData = testStateMap->value(Z100_Capture_Rslt);
        stateData = testStateMap->value(Z100_InitDelay);
        stateData->dispData = displayStateData->dispData;
        stateData = testStateMap->value(Z100_Capture_W);
        stateData->dispData = displayStateData->dispData;
        stateData = testStateMap->value(Z100_Capture_B);
        stateData->dispData = displayStateData->dispData;
    }
    if (refSrc == integTestsRef_ZXY110)
    {
        IT_StateRunData *stateData;

        IT_StateRunData *displayStateData = testStateMap->value(Z110_STABILIZING_EQ_2);
        stateData = testStateMap->value(Z110_InitDelay);
        stateData->dispData = displayStateData->dispData;
        stateData = testStateMap->value(Z110_STABILIZING_UP);
        stateData->dispData = displayStateData->dispData;
        stateData = testStateMap->value(Z110_STABILIZING_EQ_1);
        stateData->dispData = displayStateData->dispData;
        stateData = testStateMap->value(Z110_STABILIZING_FTM);
        stateData->dispData = displayStateData->dispData;

        displayStateData = testStateMap->value(Z110_EQUALISE_WAIT);
        stateData = testStateMap->value(Z110_EQUALISE);
        stateData->dispData = displayStateData->dispData;

        displayStateData = testStateMap->value(Z110_Capture_Rslt);
        stateData = testStateMap->value(Z110_Capture_W);        // ToDo anonymize 'stateData'
        stateData->dispData = displayStateData->dispData;
        stateData = testStateMap->value(Z110_Capture_B);
        stateData->dispData = displayStateData->dispData;
    }

    integTestLog->Write2LogF("Test Sequence loaded.\n");

    // allow for longer equalisation of the ZXY300/500
    IT_StateRunData *stateData = testStateMap->value(Z2IntegTests::SensorDetect);

    if (devPID==ZXY300_PRODUCT_ID)
    {
        stateData->durationSecs += 10;
    }

    if ( zul_isZXY500AppPID(&devPID) )
    {
        stateData->durationSecs += 4;
    }

    recommendation = QString("");
}

/**
 *  debug/logging aid
 */
QString Z2IntegTests::getStateName(int stateNo)
{
    const Z2IntegTests::IT_StateDefn * ref = integTestsRef_MT;
    switch (devPID)
    {
        case ZXY100_PRODUCT_ID:
            ref = integTestsRef_ZXY100;
            break;
        case ZXY110_PRODUCT_ID:
            ref = integTestsRef_ZXY110;
            break;
    }
    int i = 0;
    while (ref[i].state != LastState)
    {
        if (ref[i].state == stateNo)
        {
            return ref[i].name;
        }
        i++;
    }
    return "stateNameNotFound";
}

/**
 *  Test drawing at 800x600 and 1280x1024, ... and ... ?
 */
void Z2IntegTests::setZXY100Data(Zxy100Data *dd)
{

    // set the instance that we use to control the ZXY100 data collection
    // this is also a "ZXY100 test mode" flag, being non-NULL
    zxy100Data = dd;

    if (zxy100Data)
    {
        if (zxy100DataBlack == NULL)
        {
            // create a new instance for the sole purpose of collecting BLACK screen
            // data frames. Don't use it when zxy100Data should be used.
            zxy100DataBlack = new Zxy100Data();
            zxy100DataBlack->refreshInfo();     // must set wire counts - consider a copy constructor
            zul_logf(3, "new BLACK Zxy100Data");
        }
        integTestLog->Write2Log("Integration Tests Set for ZXY100/ZXY110");
    }
    else
    {
        integTestLog->Write2Log("Integration Tests Set for ZXY_MT");
    }

    recommendation = QString("");
    integTestLog->Write2LogF( "IT - NB - Set for %s\n",
                (zxy100Data) ? "ZXY100s" : "MT Devices");
}

void Z2IntegTests::keyPressEvent(QKeyEvent *event)
{
    if ((currentTest == Z2IntegTests::MT_Finished))
    {
        integTestLog->Write2LogF( "\tStopTick\n");
        secondTick->stop();
        integTestLog->Write2Log("Finished & key press");

        accept();
    }
    if ((event->key() == Qt::Key_Escape))
    {
        integTestLog->Write2LogF( "Process cancelled, esc pressed\n");

        integTestLog->Write2LogF( "\tStopTick\n");
        secondTick->stop();
        if (pollingTimer.isActive())
        {
            pollingTimer.stop();
            zxy100Data->enableRawDataCapture(false);
        }
        integTestLog->Write2Log("Esc key pressed.");
        reject();
    }
}

void Z2IntegTests::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        // integTestLog->Write2LogF( "YouReleasedEsc");
    }
}


/**
 *  Test drawing at 800x600 and 1280x1024, ... and ... 4k ?
 */
void Z2IntegTests::paintEvent(QPaintEvent*)
{
    static int      boxWidth, width, height;
    static QPoint   topLeftRef, bottomRightRef;
    QPainter        painter(this);
    IT_StateRunData *stateData = testStateMap->value(currentTest);

    QFont           fontBold=painter.font() ;
    QFont           fontTitle=painter.font() ;

    QColor          bgColor = Qt::white;

    if (pAssignedMonitor == NULL)
    {
        integTestLog->Write2LogF( "Painting IT - no monitor set\n");
        return;
    }

    if ( (currentTest == Z2IntegTests::FirstTouchMode) &&
         (stateData->elapsedSecs == 3)
       )
    {
        bgColor = Qt::black;
    }

    if (blackScreen)        // ToDo - use this for MT case above also
    {
        bgColor = Qt::black;
    }

    painter.fillRect(rect(), bgColor);
    painter.setRenderHint(QPainter::Antialiasing);

    //set size and position of cancel box
    if (border == 0)
    {
        int b1, b2;

        width = this->width();
        height = this->height();

        b1 = ( height - 580 ) / 2;     // 580 is the desired height
        b2 = ( width  - 740 ) / 2;     // 740 is the desired width

        // take the least
        border = (b1 < b2) ? b1 : b2;

        // reduce for very large displays
        if (border > 300) border /= 2;

        positionInfoBox(width, height, border, &topLeftRef, &bottomRightRef);
        boxWidth = bottomRightRef.x()-topLeftRef.x();
    }

    QPoint topLeft = topLeftRef, bottomRight = bottomRightRef;

    infoBox.setTopLeft(topLeft);
    infoBox.setBottomRight(bottomRight);
    painter.setPen(Qt::gray);
    painter.drawRect(infoBox);


    QPoint titleBtmRight = topLeft + QPoint( boxWidth-1, 50 );
    titleBox.setTopLeft(topLeft);
    titleBox.setBottomRight(titleBtmRight);

    exitBox.setTopLeft(topLeft+QPoint(0,580-50));
    exitBox.setSize(QSize(titleBox.width(),titleBox.height()));
    //painter.drawRect(exitBox);

    int dimension = ( width < height ) ? width : height;    // take the smaller
    int fontPointSz = dimension * 8 / 600 ;
    fontTitle.setPointSize( fontPointSz );
    fontTitle.setWeight(QFont::DemiBold);
    fontPointSz -= 2;
    fontBold.setPointSize( fontPointSz );
    fontBold.setWeight(QFont::DemiBold);

    painter.setFont(fontTitle);
    if (Title.contains("complete", Qt::CaseInsensitive))
    {
        painter.setPen(Qt::darkGreen);
    }
    else
    {
        painter.setPen(Qt::red);
    }
    //painter.drawRect(titleBox);
    painter.drawText(titleBox, (Qt::AlignCenter | Qt::TextWordWrap), Title);

    topLeft += QPoint (0, 50);
    titleBtmRight += QPoint (0, 15);
    procBox.setTopLeft(topLeft);
    procBox.setBottomRight(titleBtmRight);
    painter.setFont(fontBold);

    /* painter.drawText(procBox, (Qt::AlignCenter | Qt::TextWordWrap),
     *            tr("Controller ID") + ": " + ControllerID);
     */

    // set the reference point for the test report displays
    topLeft += QPoint (20,20);

    bool someAreDisplayed = false;

    QMap<ITState, IT_StateRunData*>::iterator i;
    for (i = testStateMap->begin(); i != testStateMap->end(); ++i)
    {
        IntegrationTest *pTstDspData = i.value()->dispData;
        bool visible = i.value()->visible;
        if ((pTstDspData != NULL) && (visible))
        {
            pTstDspData->setLocation(topLeft);
            pTstDspData->setLargeFonts(dimension > 1100);
            topLeft += QPoint (0,40);
            someAreDisplayed = true;
        }
        else
        {
            if (someAreDisplayed) topLeft += QPoint (0,10);
        }
    }

    // used for ZXY100 only - as yet.
    if (recommendation.length() != 0)
    {
        topLeft += QPoint (0,20);
        recomendBox.setTopLeft(topLeft);
        QPoint br = QPoint(titleBtmRight.x(), topLeft.y() + 40);
        recomendBox.setBottomRight(br);
        painter.setPen(Qt::red);
        // fontBold.setPointSize( 10 );
        painter.setFont(fontBold);
        painter.drawText(recomendBox, (Qt::AlignCenter | Qt::TextWordWrap), recommendation);
    }

    if (exitStr.length() != 0)
    {
        if (exitStr.contains("failure", Qt::CaseInsensitive))
            painter.setPen(Qt::red);
        else
            painter.setPen(Qt::blue);

        //fontBold.setPointSize( 12 );
        painter.setFont(fontBold);
        painter.drawText(exitBox, (Qt::AlignCenter | Qt::TextWordWrap), exitStr);
    }
}


/**
 * Simple maths to local a reasonable box on small - large screens
 */
void Z2IntegTests::positionInfoBox (
    int width, int height, int border, // int index,
    QPoint *topLeft, QPoint *bottomRight
)
{
    *topLeft = QPoint( border, border );
    *bottomRight = QPoint( width-border, height-border );
}


/**
 *  Called periodically by timer to animate the tests
 */
void Z2IntegTests::changeState()
{
    const QString zxy100Assistance = QObject::tr(
            "Recommendations: Increase air gap between sensor and display, improve grounding,\n"
            "run Basic Setup, increase Touch Threshold and/or reduce Coarse Sensitivity");
    const QString checkFlexiStr = QObject::tr("Check flexible cable connections between sensor and controller");
    const QString noiseOk       = QObject::tr("Detected noise levels are OK");

    static bool writeLogFile;
    static uint16_t ui16Value;
    static QString zxy110StabilityReport;

    char sName[50] = "--";
    IT_StateRunData *stateData = NULL;
    IntegrationTest *dispData  = NULL;
    int secondsLeft = 0;

    QString testing = QString(QObject::tr("Testing ... "));

    if (testStateMap->contains(currentTest))
    {
        stateData = testStateMap->value(currentTest);
        dispData = stateData->dispData;
        strncpy(sName, getStateName(currentTest).toLatin1().data(), 49);
        sName[49] = '\0';
        ++stateData->elapsedSecs;
        secondsLeft = stateData->durationSecs - stateData->elapsedSecs;
    }

    if (stateData != NULL)
    {
        integTestLog->Sync2Disk();
        integTestLog->Write2LogF("Tick: %d | %s", stateData->elapsedSecs, sName);
        if (strstr(sName, "Capture") != NULL)
        {
            integTestLog->Write2LogF("  - white:%d & black:%d",
                                        zxy100Data->getNumFrames(),
                                        zxy100DataBlack->getNumFrames()  );
        }
    }
    else
    {
        if (DebugMode) integTestLog->Write2Log( "Tick: NoState");
    }

    switch (currentTest)
    {
        case Z2IntegTests::MT_InitDelay:
            {
                char id2[40];
                zul_CpuID(id2, 40);
                id2[39] = '\0';
                integTestLog->Write2LogF("Controller : %s", id2);
                ControllerID = QString(id2);
                writeLogFile = true;
            }

            break;

        case Z2IntegTests::SensorDetect:
            if (stateData->elapsedSecs == 1)
            {
                integTestLog->Write2LogF( "\tForce Equalisation\n");
                zul_forceEqualisation();
                integTestLog->Write2Log("Eq Done");
            }

            if (stateData->elapsedSecs == stateData->durationSecs)
            {
                GET_STATUS_VAL(ZXYMT_SI_NUM_ACTIVE_CELLS, numActiveCells);

                GET_STATUS_VAL( ZXYMT_SI_CONNECTED_WIRE_X_FIRST, xF);
                GET_STATUS_VAL( ZXYMT_SI_CONNECTED_WIRE_X_LAST,  xL);

                GET_STATUS_VAL( ZXYMT_SI_CONNECTED_WIRE_Y_FIRST, yF);
                GET_STATUS_VAL( ZXYMT_SI_CONNECTED_WIRE_Y_LAST,  yL);

                xR = xL - xF + 1, yR = yL - yF + 1;

                if (FailAll) numActiveCells = 0;
                if (numActiveCells>0)   // at least one is responding
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment(QObject::tr("Sensor detected ") +
                                        QString("(%1 x %2 wires)").arg(xR).arg(yR));
                }
                else
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(checkFlexiStr);
                    if (!FailAll)
                    {
                        goto stopTests_mt;
                    }
                }

                dispData->setDebugDetail( QString("\n\t#ActiveCells %1 - ").arg(numActiveCells) +
                                                QString("%1 x %2").arg(xR).arg(yR)
                        + QObject::tr(" wire sensor found") );
                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
            }

            {
                // animate the display so users are entertained during ZXY300 equalisation
                QString secondsLeftStr = QString(" .. (%1)").arg(secondsLeft);
                    // (stateData->durationSecs - stateData->elapsedSecs)
                if (secondsLeft > 1)
                {
                    dispData->setTestComment(QObject::tr("Equalizing sensor") + secondsLeftStr);
                }
                else if (1 == secondsLeft)
                {
                    dispData->setTestComment(QObject::tr("Equalizing sensor"));
                }
                // else - don't overwrite the test result !
            }

            break;


        case Z2IntegTests::SensorIntegrity:
            if (stateData->elapsedSecs == stateData->durationSecs)
            {
                bool testPass = false;

                if (FailAll) yR = 46;

                dispData->setDebugDetail( QString("\n\t(X=%1-%2, Y=%3-%4)") .arg(xF).arg(xL).arg(yF).arg(yL) );

                testPass = (xR * yR == numActiveCells);
                if (testPass)
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment( QString("Sensor responding OK") );
                    dispData->addDebugDetail( QString("\n\t(X:%1 Y:%2").arg(xR).arg(yR) );
                }
                else
                {
                    uint16_t numCoreByStat,numCoreActiveFL;
                    GET_STATUS_VAL( ZXYMT_SI_CORE_ACTIVE_CELLS, numCoreByStat);
                    numCoreActiveFL = (xR-2) * (yR-2) ;
                    testPass = ( numCoreByStat == numCoreActiveFL );
                    if (testPass)
                    {
                        dispData->setTestPass(QObject::tr("WARNING"));
                        dispData->setTestComment( QString("Some parts of the sensor are not working.") );
                    }
                    else
                    {
                        dispData->setTestPass(QObject::tr("FAIL"));
                        dispData->addDebugDetail( QString("\n\t#Active cells core: %1 (%2 = %3 x %4)")
                                                .arg(numCoreByStat).arg(numCoreActiveFL).arg(xR-2).arg(yR-2) );
                        dispData->setTestComment( QString("Some parts of the sensor are not working. " ) + checkFlexiStr);
                    }

                    uint16_t numDead;
                    GET_STATUS_VAL( ZXYMT_SI_NUM_DEAD_X_WIRES, numDead);
                    if (numDead > 0)
                    {
                        dispData->setTestPass(QObject::tr("FAIL"));
                        dispData->setTestComment( QString("Some parts of the sensor are not working. " ) + checkFlexiStr);
                        QString wireList = QString("\n\t#%1 dead X wire(s): ").arg(numDead) ;
                        for (int x=0; x < numDead; x++)
                        {
                            uint16_t deadIndex;
                            GET_STATUS_VAL( ZXYMT_SI_NEXT_DEAD_X_WIRE, deadIndex );
                            wireList += QString( "%1 ").arg(deadIndex);
                        }
                        dispData->addDebugDetail( wireList );
                    }
                    GET_STATUS_VAL( ZXYMT_SI_NUM_DEAD_Y_WIRES, numDead);
                    if (numDead > 0)
                    {
                        dispData->setTestPass(QObject::tr("FAIL"));
                        dispData->setTestComment( QString("Some parts of the sensor are not working. " ) + checkFlexiStr);
                        QString wireList = QString("\n\t#%1 dead Y wire(s): ").arg(numDead) ;
                        for (int y=0; y < numDead; y++)
                        {
                            uint16_t deadIndex;
                            GET_STATUS_VAL( ZXYMT_SI_NEXT_DEAD_Y_WIRE, deadIndex );
                            wireList += QString( "%1 ").arg(deadIndex);
                        }
                        dispData->addDebugDetail( wireList );
                    }
                }
            }

            break;

        case Z2IntegTests::SensorQuiet:

            if (stateData->elapsedSecs == 1)
            {
                // read these to clear out any previously seen faults/flags
                GET_STATUS_VAL( ZXYMT_SI_STATUS_OR_SINCE_PREVIOUS, statusOrSincePrevious);
                GET_STATUS_VAL( ZXYMT_SI_STATUS_AND_SINCE_PREVIOUS, statusAndSincePrevious);
                dispData->setTestComment(testing);
            }
            if (stateData->elapsedSecs == stateData->durationSecs)
            {
                int minColCount = expectedWires(X_WIRES) / 10;
                int minRowCount = expectedWires(Y_WIRES) / 10;

                GET_STATUS_VAL( ZXYMT_SI_NUM_LIVE_ROWS,    numLiveRow);
                GET_STATUS_VAL( ZXYMT_SI_NUM_LIVE_COLUMNS, numLiveCol);

                if (FailAll) numLiveRow = 60;

                if ( (numLiveRow < minRowCount) && (numLiveCol < minColCount) )
                {
                    dispData->setTestPass("PASS");
                    dispData->setTestComment(noiseOk);
                }
                else
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment( QObject::tr("Increase air gap between sensor and display, improve grounding, ") +
                                          QObject::tr("run Basic Setup, increase Touch Threshold") );
                }

                dispData->setDebugDetail
                        ( "\r\n\t" + QString(QObject::tr("LiveRows:") + "%1 " +
                          QObject::tr("LiveCols:") + "%2").arg(numLiveRow).arg(numLiveCol) );

                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
            }

            break;

        case Z2IntegTests::FirstTouchMode:
            if (stateData->elapsedSecs == 1)
            {
                // this test will take a few moments - warn the user of this
                dispData->setTestComment( testing );
            }

            if (stateData->elapsedSecs == 2)
            {
                // record AND/OR bits that were set during the noise test
                GET_STATUS_VAL(ZXYMT_SI_STATUS_OR_SINCE_PREVIOUS,  statusOrSincePrevious );
                GET_STATUS_VAL(ZXYMT_SI_STATUS_AND_SINCE_PREVIOUS, statusAndSincePrevious);

                // turn on first touch mode, save current setting first
                GET_CONFIG_PARAM( ZXYMT_CI_FTM_SELECTION, firstTouchModeSetting);
                //DisableFlashWrite();
                SET_CONFIG_PARAM( ZXYMT_CI_FTM_SELECTION, 1);
                //EnableFlashWrite();

                // wait a moment for it to get a measurement
            }

            if (stateData->elapsedSecs == 3)
            {
                GET_CONFIG_PARAM(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, firstTouchModeOffMetricWhite);
                // next screen will be black
            }

            if (stateData->elapsedSecs == 4)
            {
                // screen reverts to default White

                //Get status values and flash param values to decide if we have failed these tests
                GET_STATUS_VAL(ZXYMT_SI_NUM_ZEROS_WARNING_MAX , firstTouchModeOnMetricMaxValue);
                GET_CONFIG_PARAM(ZXYMT_CI_FTM_ON_THRESHOLD, firstTouchModeOnThreshold);
                GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, firstTouchModeOffMetricBlack );
                GET_CONFIG_PARAM(ZXYMT_CI_FTM_OFF_THRESHOLD, firstTouchModeOffThreshold);

                // DisableFlashWrite();
                // revert to programmed first-touch mode
                SET_CONFIG_PARAM(ZXYMT_CI_FTM_SELECTION, firstTouchModeSetting);
                // EnableFlashWrite();

                // Now we have the required data for all of the results.
                // To keep it looking smooth, don't present them all at once.
            }

            if (stateData->elapsedSecs == 5)
            {
                //  read status byte and/or variants to clear out the records again
                uint16_t tempStatus;
                GET_STATUS_VAL( ZXYMT_SI_STATUS_OR_SINCE_PREVIOUS,  tempStatus);
                GET_STATUS_VAL( ZXYMT_SI_STATUS_AND_SINCE_PREVIOUS, tempStatus);

                // clear any test LED status from controller
                GET_STATUS_VAL( ZXYMT_SI_STATUS_LEDS, status_leds );

                // check if the metric used to enter first touch mode has ever been seen
                // above the configured threshold level
                if ((FailAll) || (firstTouchModeOnMetricMaxValue >= firstTouchModeOnThreshold))
                {
                        dispData->setTestPass(QObject::tr("FAIL"));
                        dispData->setTestComment( integrationHint );
                }
                else
                {
                        dispData->setTestPass(QObject::tr("PASS"));
                        dispData->setTestComment( noiseOk );
                }

                dispData->setDebugDetail
                        ( "\r\n\t" + QString("FTM OnMax:%1 OnT:%2")
                            .arg(firstTouchModeOnMetricMaxValue)
                            .arg(firstTouchModeOnThreshold)
                        );

                if (advancedMode)
                {
                    dispData->addDebugDetail
                        ( "\t" + QString("FTMode %1 StatOr:%2")
                            .arg(firstTouchModeSetting)
                            .arg( QString::number(statusOrSincePrevious,16) )
                        );

                    dispData->appendDebugDetail2Comment();
                }
            }

            break;  // Z2IntegTests::FirstTouchMode:

        case Z2IntegTests::DetectedNoise:
            {
                uint16_t firstTouchModeOffThresholdMaxValue = firstTouchModeOffMetricWhite;

                if (firstTouchModeOffMetricBlack > firstTouchModeOffMetricWhite)
                {
                    firstTouchModeOffThresholdMaxValue = firstTouchModeOffMetricBlack;
                }
                if (FailAll) firstTouchModeOffThresholdMaxValue = firstTouchModeOffThreshold+2;

                if ( firstTouchModeOffThresholdMaxValue <= firstTouchModeOffThreshold )
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment( noiseOk );
                }
                else
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(
                        QObject::tr("Increase air gap between sensor and display, improve grounding, ") +
                        QObject::tr("run Basic Setup") );
                }
                dispData->setDebugDetail
                        ( "\r\n\t" + QString("FTM OffMax %1 OffT %2")
                            .arg(firstTouchModeOffThresholdMaxValue)
                            .arg(firstTouchModeOffThreshold)
                        );

                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
            }

            break;


        case Z2IntegTests::NoiseRejection:
            if (stateData->elapsedSecs == 1)
            {
                GET_STATUS_VAL( ZXYMT_SI_NUM_RESAMPLED_CELLS, numResampled);

                // the passFail criterion is at 5% of active cells
                int passFailLimit = (int) ((5 * numActiveCells)/100);

                if ((FailAll) || ( numResampled > passFailLimit ))
                {
                    dispData->setTestPass(QObject::tr("WARNING"));
                    dispData->setTestComment(
                        QObject::tr("Increase air gap between sensor and display, improve grounding, ") +
                        QObject::tr("run Basic Setup, increase Touch Threshold") );
                }
                else
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment( noiseOk );
                }
                dispData->setDebugDetail
                        ( "\r\n\t" + QString("NR #ReSmp %1, Limit %2")
                                .arg(numResampled)
                                .arg(passFailLimit)
                        );

                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
            }

            break;

        case Z2IntegTests::FrameRate:
            if (stateData->elapsedSecs == 1)
            {
                GET_STATUS_VAL( ZXYMT_SI_FRAME_RATE, frameRate);

                if (FailAll) frameRate = 99;

                if ( frameRate >= desiredFrameRate() )
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment (QObject::tr("Frame rate is OK"));
                }
                else
                {
                    dispData->setTestPass(QObject::tr("WARNING"));
                    dispData->setTestComment( QObject::tr("Increase air gap between sensor and display, improve grounding, ") +
                                          QObject::tr("run Basic Setup, increase Touch Threshold") );
                }
                dispData->setDebugDetail
                        ( "\r\n\t" + QString("FR %1").arg(frameRate) );

                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
                integTestLog->Write2Log("Integration Tests Complete");
            }

            break;

        case Z2IntegTests::MT_Finished:        // exit clause
            if (writeLogFile)
            {
                writeLogFile = false;
                Title = QString(QObject::tr("Integration Tests Complete"));
                if (DebugMode)
                {
                    integTestLog->Write2LogF( "%s -- ", Title.toLatin1().data() );
                }
                secondTick->setInterval(50);
                tmpReportFile();
            }

            {
                uint16_t currTouchCount = 0;
                // too verbose for logging:  GET_STATUS_VAL(ZXYMT_SI_NUM_LIVE_TOUCHES, currTouchCount)
                zul_getStatusByID( ZXYMT_SI_NUM_LIVE_TOUCHES, &currTouchCount );
                if (currTouchCount > 0)
                {
                    integTestLog->Write2LogF( "\tStopTick\n");
                    secondTick->stop();
                    zy_msleep(1000);
                    accept();
                }
            }
            exitStr =  QString(QObject::tr("Tests completed, press \"ESC\" key or touch and hold to exit"));
            goto updateScreen;


        // #####################################################################
        // #####################################################################


        case Z100_InitDelay:
            if (stateData->elapsedSecs == 1)
            {
                writeLogFile = true;
                zul_forceEqualisation();
                blackScreen = false;

                ControllerID = QString(zxy100Data->getProcID());

                // take the current event counters, so that a comparison can be made at the
                // end of the test period
                zxy100Data->getNewNoiseReport(Zxy100Data::getBaseline);

                if (DebugMode)
                {
                    char testStr[80] = "--";
                    //HW:0e FPS:0109 {0000 0000 0014 0000  0000 0000 0000 0000} NNR:00004 NEq:00007
                    if (SUCCESS == zxy100Data->getNoiseReportStr(Zxy100Data::getBaseline, testStr, 80))
                    {
                        integTestLog->Write2LogF( "Z100 IT - Baseline: '%s'\n", testStr);
                    }
                }
                zxy100Data->prepRawDataCollection(ZXY100_CI_UPPER_THRESHOLD);
                zxy100DataBlack->prepRawDataCollection(ZXY100_CI_UPPER_THRESHOLD);
            }
            if (secondsLeft > 1)
            {
                dispData->setTestComment(QObject::tr("Equalizing Sensor") +
                                                QString(" ... (%1)").arg(secondsLeft) );
            }
            else
            {
                dispData->setTestComment(QObject::tr("Equalizing Sensor") + QString(" ... "));
            }
            break;


        case Z110_Capture_W:
        case Z100_Capture_W:
            if (stateData->elapsedSecs == 1)
            {
                zxy100Data->enableRawDataCapture(true);
                pollingTimer.start();
            }
            dispData->setTestComment(QObject::tr("Storing raw sensor data from white screen") +
                                            QString(" ... (%1)").arg(secondsLeft) );
            break;

        case Z100_Capture_B:
        case Z110_Capture_B:
            if (stateData->elapsedSecs == 1)
            {
                blackScreen = true;
                zxy100Data->enableRawDataCapture(false);
                zxy100DataBlack->enableRawDataCapture(true);
            }
            dispData->setTestComment(QObject::tr("Storing raw sensor data from black screen") +
                                        QString(" ... (%1)").arg(secondsLeft) );
            break;

        case Z100_Capture_Rslt:
            {
                blackScreen = false;
                pollingTimer.stop();
                zxy100Data->enableRawDataCapture(false);
                QString capRsStr = QString( QObject::tr("%1 seconds raw data retrieved") )
                                    .arg(Z1NoiseCapT * 2);
                dispData->setTestComment(capRsStr);
                dispData->setTestPass(QObject::tr("PASS"));

                dispData->setDebugDetail
                        ( "\r\n\t" + QString("%1 & %2 frames received.")
                            .arg(zxy100Data->getNumFrames())
                            .arg(zxy100DataBlack->getNumFrames())
                        );

                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
            }
            break;

        case Z100_SIG_70PC_THRESHOLD:
        case Z110_RAW_DATA_70pc_HITS:

            {
                dispData->setTestComment(QObject::tr("70% levels check"));
                if (zxy100Data->numFramesOvr70 + zxy100DataBlack->numFramesOvr70 == 0)
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment(QObject::tr("No signal detected above 70% Threshold"));
                }
                else
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(QObject::tr("Signals detected above 70% Threshold"));
                    recommendation = zxy100Assistance;
                }
                QString tempW = "", tempB = "";

                // white stats
                if (zxy100Data->numFramesOvr70 == 0)
                {
                    tempW = QString("Zero frames with touch over 70% after %1 frames.")
                                .arg(zxy100Data->getNumFrames());
                }
                else
                {
                    tempW = QString("%1 of %2 frames over 70% Threshold.")
                                .arg(zxy100Data->numFramesOvr70)
                                .arg(zxy100Data->getNumFrames());
                }

                // black stats
                if (zxy100DataBlack->numFramesOvr70 == 0)
                {
                    tempB = QString("Zero frames with touch over 70% after %1 frames.")
                                .arg(zxy100DataBlack->getNumFrames());
                }
                else
                {
                    tempB = QString("%1 of %2 frames over 70% Threshold.")
                                .arg(zxy100DataBlack->numFramesOvr70)
                                .arg(zxy100DataBlack->getNumFrames());
                }

                dispData->setDebugDetail ( "\r\n\t" + tempW + " " + tempB );
                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }

            }
            break;

        case Z100_SIG_50PC_THRESHOLD:
        case Z110_RAW_DATA_50pc_HITS:
            {
                dispData->setTestComment(QObject::tr("50% levels check"));
                if (zxy100Data->numFramesOvr50 + zxy100DataBlack->numFramesOvr50 == 0)
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment(QObject::tr("No signal detected above 50% Threshold"));
                    failed50pcTest = false;
                }
                else
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(QObject::tr("Signals detected above 50% Threshold"));
                    recommendation = zxy100Assistance;
                    failed50pcTest = true;
                }

                QString tempW = "", tempB = "";

                // white stats
                if (zxy100Data->numFramesOvr50 == 0)
                {
                    tempW = QString("Zero frames with touch over 50% after %1 frames.")
                                .arg(zxy100Data->getNumFrames());
                }
                else
                {
                    tempW = QString("%1 of %2 frames over 50% Threshold.")
                                .arg(zxy100Data->numFramesOvr50)
                                .arg(zxy100Data->getNumFrames());
                }

                // black stats
                if (zxy100DataBlack->numFramesOvr50 == 0)
                {
                    tempB = QString("Zero frames with touch over 50% after %1 frames.")
                                .arg(zxy100DataBlack->getNumFrames());
                }
                else
                {
                    tempB = QString("%1 of %2 frames over 50% Threshold.")
                                .arg(zxy100DataBlack->numFramesOvr50)
                                .arg(zxy100DataBlack->getNumFrames());
                }

                dispData->setDebugDetail ( "\r\n\t" + tempW + " " + tempB );
                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }

            }
            break;

        case Z100_SIG_30PC_THRESHOLD:
            {
                dispData->setTestComment(QObject::tr("30% levels check"));

                if (zxy100Data->numFramesOvr30 + zxy100DataBlack->numFramesOvr70 == 0)
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment(QObject::tr("No signal detected above 30% Threshold"));
                }
                else
                {
                    if (failed50pcTest)
                    {
                        dispData->setTestPass(QObject::tr("FAIL"));
                    }
                    else
                    {
                        dispData->setTestPass(QObject::tr("WARNING"));
                    }
                    dispData->setTestComment(QObject::tr("Signals detected above 30% Threshold"));
                }

                QString tempW = "", tempB = "";

                // white stats
                if (zxy100Data->numFramesOvr30 == 0)
                {
                    tempW = QString("Zero frames with touch over 30% after %1 frames.")
                                .arg(zxy100Data->getNumFrames());
                }
                else
                {
                    tempW = QString("%1 of %2 frames over 30% Threshold.")
                                .arg(zxy100Data->numFramesOvr30)
                                .arg(zxy100Data->getNumFrames());
                }

                // black stats
                if (zxy100DataBlack->numFramesOvr30 == 0)
                {
                    tempB = QString("Zero frames with touch over 30% after %1 frames.")
                                .arg(zxy100DataBlack->getNumFrames());
                }
                else
                {
                    tempB = QString("%1 of %2 frames over 30% Threshold.")
                                .arg(zxy100DataBlack->numFramesOvr30)
                                .arg(zxy100DataBlack->getNumFrames());
                }

                dispData->setDebugDetail ( "\r\n\t" + tempW + " " + tempB );
                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }

            }
            break;

        case Z100_MEAN_VALUES:
        case Z110_RAW_DATA_MEANXY:
            {
                float xMean  = zxy100Data->getXMeanWireAverage();
                float yMean  = zxy100Data->getYMeanWireAverage();
                float xMeanB = zxy100DataBlack->getXMeanWireAverage();
                float yMeanB = zxy100DataBlack->getYMeanWireAverage();

                dispData->setTestComment(QObject::tr("Mean level analysis"));

                if ( ((xMean+xMeanB)/2 > MeanWireValThreshold) || ((yMean+yMeanB)/2 > MeanWireValThreshold) )
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(QObject::tr("Average values are high"));
                    recommendation = zxy100Assistance;
                }
                else
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment(QObject::tr("Sensor is quiet"));
                }

                dispData->setDebugDetail
                        ( "\r\n\t" + QString("Means:      %1 & %2\tMeans: %3 & %4")
                            .arg(xMean,  5, 'f', 2)
                            .arg(yMean,  5, 'f', 2)
                            .arg(xMeanB, 5, 'f', 2)
                            .arg(yMeanB, 5, 'f', 2)
                        );
                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
            }
            break;

        case Z100_STDDEV_VALUES:
        case Z110_RAW_DATA_StdDevXY:
            {
                zxy100Data->calcStdDevs();
                zxy100DataBlack->calcStdDevs();

                float xStdDev  = zxy100Data->getXStdDev();
                float yStdDev  = zxy100Data->getYStdDev();
                float xStdDevB = zxy100DataBlack->getXStdDev();
                float yStdDevB = zxy100DataBlack->getXStdDev();

                if ( (xStdDev  > StdDevWireValThreshold) || (yStdDev  > StdDevWireValThreshold) ||
                     (xStdDevB > StdDevWireValThreshold) || (yStdDevB > StdDevWireValThreshold)
                   )
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(QObject::tr("Signal activity too high"));
                    recommendation = zxy100Assistance;
                }
                else
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment(QObject::tr("Signal activity OK"));
                }

                // dispData->setTestComment(QObject::tr(": ") );

                dispData->setDebugDetail
                        ( "\r\n\t" + QString("Deviations: %1 & %2\tDeviations:  %3 & %4")
                            .arg(yStdDev,  5, 'f', 2)
                            .arg(yStdDev,  5, 'f', 2)
                            .arg(xStdDevB, 5, 'f', 2)
                            .arg(yStdDevB, 5, 'f', 2)
                        );
                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }

            }
            break;


        // Noise Event Tests ...


        case Z100_NOISE_ALGO_COUNTS:
            {
                int numNoiseEvents, noiseEventTotal = 0, i;
                bool rxDataFail = false;
                zxy100Data->getNewNoiseReport(Zxy100Data::getDelta);

                if (DebugMode)
                {
                    char testStr[80] = "--";
                    if (SUCCESS == zxy100Data->getNoiseReportStr(Zxy100Data::getDelta, testStr, 80))
                    {
                        integTestLog->Write2LogF( "Z100 IT - Delta: '%s'\n", testStr);
                    }
                }

                for (i=0; i<ZXY100_SYSRPT_NOISE_ALGOS; i++)
                {
                    if (SUCCESS == zxy100Data->getNoiseReportValue(Zxy100Data::getDelta, i, &numNoiseEvents))
                    {
                        noiseEventTotal += numNoiseEvents;
                        integTestLog->Write2LogF( "\tZ100 IT %d T:%d\n", numNoiseEvents, noiseEventTotal);
                    }
                    else
                    {
                        rxDataFail = true;
                        break;
                    }
                }

                if (rxDataFail)
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(QObject::tr("Failed to retrieve data"));
                }
                else
                {
                    if ( noiseEventTotal > 0 )
                    {
                        dispData->setTestPass(QObject::tr("FAIL"));
                        dispData->setTestComment(QObject::tr("Noise Detected"));
                        recommendation = zxy100Assistance;
                    }
                    else
                    {
                        dispData->setTestPass(QObject::tr("PASS"));
                        dispData->setTestComment(QObject::tr("No noise detection events"));
                    }
                }

                char testStr[80] = "--";
                if (SUCCESS == zxy100Data->getNoiseReportStr(Zxy100Data::getDelta, testStr, 80))
                {
                    dispData->setDebugDetail( "\r\n\tDelta:          " + QString(testStr));
                }
                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }

            }
            break;

        case Z100_EQ_COUNTS:
            {
                int numNoiseEvents;
                //zxy100Data->getNewNoiseReport(Zxy100Data::getDelta);

                if (SUCCESS == zxy100Data->getNumEqualizations(Zxy100Data::getDelta, &numNoiseEvents))
                {
                    if ( numNoiseEvents > 0 )
                    {
                        dispData->setTestPass(QObject::tr("FAIL"));
                        dispData->setTestComment(QObject::tr("Unexpected sensor equalisations have occurred"));
                        recommendation = zxy100Assistance;
                    }
                    else
                    {
                        dispData->setTestPass(QObject::tr("PASS"));
                        dispData->setTestComment(QObject::tr("No unexpected equalisation events"));
                    }

                }
                else
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(QObject::tr("Failed to retrieve data"));
                }

                char testStr[80] = "--";
                if (SUCCESS == zxy100Data->getNoiseReportStr(Zxy100Data::getBaseline, testStr, 80))
                {
                    dispData->setDebugDetail( "\r\n\tBaseline:       " + QString(testStr));
                }
                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }

            }
            break;

        case Z100_NOISE_FIX_EVENTS:
            {
                int numNoiseEvents;
                // zxy100Data->getNewNoiseReport(Zxy100Data::getDelta);

                if (SUCCESS == zxy100Data->getNumNoiseRecoveryEvents(Zxy100Data::getDelta, &numNoiseEvents))
                {
                    if ( numNoiseEvents > 0 )
                    {
                        dispData->setTestPass(QObject::tr("FAIL"));
                        dispData->setTestComment(QObject::tr("Noise recovery events occurring"));
                        recommendation = zxy100Assistance;
                    }
                    else
                    {
                        dispData->setTestPass(QObject::tr("PASS"));
                        dispData->setTestComment(QObject::tr("No noise recovery events"));
                    }

                }
                else
                {
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(QObject::tr("Failed to retrieve data"));
                }

                char testStr[80] = "--";
                if (SUCCESS == zxy100Data->getNoiseReportStr(Zxy100Data::getFirst, testStr, 80))
                {
                    dispData->setDebugDetail( "\r\n\tInitial values: " + QString(testStr));
                }

                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
                integTestLog->Write2Log("Integration Tests Complete");
            }
            break;


        case Z100_Finished:        // exit clause
        case Z110_Finished:        // exit clause
            if (writeLogFile)
            {
                writeLogFile = false;
                // struct touch_data touched;
                Title = QString(QObject::tr("Integration Tests Complete"));
                integTestLog->Write2LogF( "\tIntegration Tests Complete\n");
                secondTick->setInterval(200);
                tmpReportFile();

                /*if (SUCCESS == GetSingleTouchData(&touched))      // ToDo see zul_GetTouchUp() ?
                {
                    if ((touched.flags & 0x07) == 0x07)
                    {
                        integTestLog->Write2LogF( "\tStopTick\n");
                        secondTick->stop();
                        zy_msleep(1000);
                        accept();
                    }
                }    -- ToDo  -- */

                // zy_msleep(1000);
            }
            exitStr =  QString(QObject::tr("Tests completed, press \"ESC\" key or touch and hold to exit"));
            // break;
            goto updateScreen;


        // #####################################################################
        // #####################################################################


        case Z110_InitDelay:
            if (stateData->elapsedSecs == 1)
            {
                char id2[40];
                zul_CpuID(id2, 40);

                id2[39] = '\0';
                integTestLog->Write2LogF("Controller : %s", id2);
                ControllerID = QString(id2);
                writeLogFile = true;
                GET_CONFIG_PARAM( ZXY110_CI_FTPM_TIMER, zxy110initState.ftpmTimeout);
                // zul_logf(2, " ## ZXY110 FTPM Timeout is %d", zxy110initState.ftpmTimeout);
                zxy110StabilityReport = "";

                // SET_CONFIG_PARAM( 15, 1 );      // TBC ... not used by Windows ZyConfig
                zxy100Data->prepRawDataCollection(ZXY110_CI_UPPER_THRESHOLD);
                zxy100DataBlack->prepRawDataCollection(ZXY110_CI_UPPER_THRESHOLD);
                zul_SetSpecialHandler( RAW_DATA, handle_IN_rawdata_110_Clipped );
            }
            break;

        case Z110_STABILIZING_UP:
            dispData->setTestComment(getStateName(currentTest));

            GET_STATUS_VAL( ZXY110_SI_POWER_UP_TIMER_UPPER, ui16Value);
            zxy110initState.uptime = 0x10000 * ui16Value ;
            GET_STATUS_VAL( ZXY110_SI_POWER_UP_TIMER_LOWER, ui16Value);
            zxy110initState.uptime += ui16Value ;
            zul_logf(3, " ## ZXY110 uptime is %d", zxy110initState.uptime );

            // 10 seconds uptime required before net test can run reliably
            if (zxy110initState.uptime >= 10)
            {
                stateData->elapsedSecs = stateData->durationSecs;   // move to next state
            }
            break;

        case Z110_STABILIZING_EQ_1:
        case Z110_STABILIZING_EQ_2:
            GET_STATUS_VAL( ZXY110_SI_SCAN_MODE, ui16Value);
            zul_logf(3, " ## [%d] ZXY110 Scanner Mode is %d", currentTest, ui16Value );

            if ((stateData->elapsedSecs == stateData->durationSecs) || FailAll)
            {
                zxy110StabilityReport += tr("Equalization timeout; ");
                dispData->setTestPass(QObject::tr("FAIL"));
                dispData->setTestComment(zxy110StabilityReport);
            }

            if (ui16Value != 1)     // Controller is NOT in Equalization mode
            {
                stateData->elapsedSecs = stateData->durationSecs;   // move to next state
            }

            break;

        case Z110_STABILIZING_FTM:
            GET_STATUS_VAL( ZXY110_SI_FTM_STATUS, ui16Value);
            zul_logf(3, " ## [%d] ZXY110 FTM Mode is %d   (%ds)",
                        currentTest, ui16Value, stateData->elapsedSecs);

            if ((ui16Value == 1) || FailAll) //Controller is in FirstTouchMode
            {
                if ((stateData->elapsedSecs > zxy110initState.ftpmTimeout + 3) || FailAll)
                {
                    // Controller has been in FirstTouchMode too long
                    zxy110StabilityReport += tr("FTM test timeout; ");
                    dispData->setTestPass(QObject::tr("FAIL"));
                    dispData->setTestComment(zxy110StabilityReport);
                    stateData->elapsedSecs = stateData->durationSecs;   // move to next state
                }
                else
                {
                    stateData->durationSecs ++;      // stall the progression
                }
            }
            else
            {
                stateData->elapsedSecs = stateData->durationSecs;   // move to next state
                if (zxy110StabilityReport.isEmpty())
                {
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment(QObject::tr("Device is stable"));
                }
            }
            break;

        case Z110_EQUALISE:

            GET_STATUS_VAL( ZXY110_SI_NUM_EQUALIZATIONS, zxy110initState.numEqualizations);
            dispData->setTestComment(QObject::tr("Equalizing sensor ..."));
            zul_forceEqualisation();
            break;

        case Z110_EQUALISE_WAIT:

            GET_STATUS_VAL( ZXY110_SI_NUM_EQUALIZATIONS, ui16Value);
            zul_logf(3, " ## [%d] EQ %d > ? %d   (%ds)",
                        currentTest, ui16Value,
                        zxy110initState.numEqualizations,
                        stateData->elapsedSecs);

            if (FailAll) stateData->elapsedSecs = stateData->durationSecs;

            if (stateData->elapsedSecs == stateData->durationSecs)
            {
                dispData->setTestPass(QObject::tr("FAIL"));
                dispData->setTestComment(QObject::tr("Forced EQ - TIMED OUT"));
            }
            else
            {
                if (ui16Value > zxy110initState.numEqualizations)
                {
                    // equalisation has completed
                    stateData->elapsedSecs = stateData->durationSecs;
                    dispData->setTestPass(QObject::tr("PASS"));
                    dispData->setTestComment(QObject::tr("Sensor Equalized"));

                    zxy110initState.numEqualizations++;

                    // capture some status values before raw data monitoring starts
                    GET_STATUS_VAL( ZXY110_SI_NUM_TOUCH_SINCE,     zxy110TestState.numTouchSinceLast);
                    GET_STATUS_VAL( ZXY110_SI_NUM_FTM_ACTIVATIONS, zxy110TestState.numFtmActivations);
                    GET_STATUS_VAL( ZXY110_SI_NUM_FREQ_HOPPED,     zxy110TestState.numFreqHopped);
                }
            }
            break;

        // case Z110_Capture_W:             see case Z100_Capture_W
        // case Z110_Capture_B:             see case Z100_Capture_W

        case Z110_Capture_Rslt:
            {
                blackScreen = false;

                pollingTimer.stop();
                zxy100Data->enableRawDataCapture(false);
                QString capRsStr = QString( QObject::tr("%1 seconds raw data retrieved") )
                                    .arg(Z1NoiseCapT * 2);
                dispData->setTestComment(capRsStr);
                dispData->setTestPass(QObject::tr("PASS"));

                dispData->setDebugDetail
                        ( "\r\n\t" + QString("%1 & %2 frames received.")
                            .arg(zxy100Data->getNumFrames())
                            .arg(zxy100DataBlack->getNumFrames())
                        );

                if (advancedMode)
                {
                    dispData->appendDebugDetail2Comment();
                }
            }
            break;


        //case Z110_RAW_DATA_70pc_HITS      see case Z100_SIG_70PC_THRESHOLD
        //case Z110_RAW_DATA_50pc_HITS:     see case Z100_SIG_50PC_THRESHOLD
        //case Z110_RAW_DATA_MEANXY:        see case Z100_MEAN_VALUES
        //case Z110_RAW_DATA_StdDevXY:      see case Z100_STDDEV_VALUES

        case Z110_CHECK_STATUS_VALUES:
            {
                QString globalResultString  = "PASS";
                QString commentString       = "";
                QString debugString         = "";

                zul_SetupStandardInHandlers(); // stop handle_IN_rawdata_110_Clipped

                GET_STATUS_VAL( ZXY110_SI_NUM_TOUCH_SINCE,      zxy110TestState.numTouchSinceLast);
                GET_STATUS_VAL( ZXY110_SI_NUM_EQUALIZATIONS,    zxy110TestState.numEqualizations);
                GET_STATUS_VAL( ZXY110_SI_NUM_FTM_ACTIVATIONS,  zxy110TestState.numFtmActivations);
                GET_STATUS_VAL( ZXY110_SI_NUM_FREQ_HOPPED,      zxy110TestState.numFreqHopped);
                GET_STATUS_VAL( ZXY110_SI_NUM_NOISY_WIRES,      zxy110TestState.numNoisyWires);
                GET_STATUS_VAL( ZXY110_SI_SCAN_FREQ,            zxy110TestState.scanFreqKHz);
                GET_STATUS_VAL( ZXY110_SI_DIGITAL_POT_VALUE,    zxy110TestState.digitalPotValue);

                if (FailAll)
                {
                    zxy110TestState.numTouchSinceLast   += 1;
                    zxy110TestState.numEqualizations    += 1;
                    zxy110TestState.numFtmActivations   += 1;
                    zxy110TestState.numFreqHopped       += 1;
                    zxy110TestState.numNoisyWires       += 3;
                }

                // --- numEqualizations ---
                if (zxy110TestState.numEqualizations > zxy110initState.numEqualizations)
                {
                    globalResultString = "Fail";
                    debugString += "\tFail ";
                }
                else
                {
                    debugString += "\tPass ";
                }
                debugString += QString("numEqualizations %1;\r\n").arg(zxy110TestState.numEqualizations);

                // --- numTouchSinceLast ---
                if (zxy110TestState.numTouchSinceLast > zxy110initState.numTouchSinceLast)
                {
                    globalResultString = "Fail";
                    debugString += "\tFail ";
                }
                else
                {
                    debugString += "\tPass ";
                }
                debugString += QString("numTouches %1;\r\n").arg(zxy110TestState.numTouchSinceLast);

                // --- numFtmActivations ---
                if (zxy110TestState.numFtmActivations > zxy110initState.numFtmActivations)
                {
                    globalResultString = "Fail";
                    debugString += "\tFail ";
                }
                else
                {
                    debugString += "\tPass ";
                }
                debugString += QString("numFtmActivations %1;\r\n").arg(zxy110TestState.numFtmActivations);

                // --- numFreqHopped ---
                if (zxy110TestState.numFreqHopped > zxy110initState.numFreqHopped)
                {
                    globalResultString = "Fail";
                    debugString += "\tFail ";
                }
                else
                {
                    debugString += "\tPass ";
                }
                debugString += QString("numFreqHopped %1;\r\n").arg(zxy110TestState.numFreqHopped);

                // --- numNoisyWires ---
                if (zxy110TestState.numNoisyWires > 2)
                {
                    globalResultString = "Fail";
                    debugString += "\tFail ";
                }
                else
                {
                    debugString += "\tPass ";
                }
                debugString += QString("numNoisyWires %1;\r\n").arg(zxy110TestState.numNoisyWires);

                // --- Final assessment -----------------------------

                debugString += QString("\r\n\tDP: %1").arg(zxy110TestState.digitalPotValue);

                dispData->setTestPass(globalResultString);
                float mhz = (float)zxy110TestState.scanFreqKHz/1000.0;
                if (globalResultString == "PASS")
                {
                    dispData->setTestComment(
                        QObject::tr("No noise detected. ScanFreq: ") +
                        QString("%1 MHz\r\n").arg(mhz)
                        );
                }
                else
                {

                    dispData->setTestComment( QObject::tr("Noise detected - ")  +
                                                integrationHint                 +
                                                QString("ScanFreq: %1 MHz\r\n").arg(mhz)
                                            );
                }
                dispData->setDebugDetail(debugString);      // use addDebugDetail(s+"\r\n); ToDo
            }
            break;

        default:
            integTestLog->Write2Log( "\tDefault State Handler");
            if (pollingTimer.isActive())
            {
                pollingTimer.stop();
                zxy100Data->enableRawDataCapture(false);
                zul_SetupStandardInHandlers(); // stop handle_IN_rawdata_110_Clipped
            }
            break;
    }

    // check if state change due
    if (stateData != NULL)
    {
        if (stateData->elapsedSecs == stateData->durationSecs)
        {
            // change state
            currentTest = (ITState)(1 + currentTest);
            stateData->elapsedSecs = 0;

            if ( zul_isZXY500AppPID(&devPID) )
            {
                // ZXY500 drops first touch mode as a noise management mode
                if (currentTest == FirstTouchMode)
                {
                    currentTest = TSpause2;
                }
            }
            zul_logf(3, "IT:\tChange to state %d -- '%s'", currentTest, getStateName(currentTest).toLatin1().data());
        }
    }

updateScreen:
    update();
    return;

stopTests_mt:
    // MT tests can not proceed...
    currentTest = Z2IntegTests::MT_Finished;
}

/**
 *  convert the test report to a single string
 */
QString Z2IntegTests::getTestResultStr(void)
{
    QString bar = "======================================================\r\n";
    QString report = QString(bar + QObject::tr("Results of Integration Tests")
            + "\r\n" + bar + "\r\n");

    if (versAppStr.length() > 0)
    {
        report.append(QObject::tr("ZyConfig Version") + ": " + versAppStr + "\r\n");
    }

    char version[100];
    zul_Hardware(version, 60);
    if (!strcmp(version, "100"))
    {
        if (SUCCESS != zul_Hardware(version, 60))
        {
            sprintf(version, "ZXY100-U-OFF-???");  // ToDo
        }
    }
    report.append(QObject::tr("Hardware") + ": " + version +"\r\n");
    zul_Firmware(version, 99);
    report.append(QObject::tr("Firmware") + ": " + version +"\r\n");
    zul_Bootloader(version, 99);
    report.append(QObject::tr("Bootloader") + ": " + version +"\r\n");

    zul_Customization(version, 99);
    if (strcmp(version, "1"))   // if not default, report difference
    {
        report.append(QObject::tr("Customization") + ": " + version +"\r\n");
    }

    report.append(QObject::tr("ControllerID") + ": " + ControllerID+"\r\n\r\n");

    IntegrationTest *pLastResult = NULL;

    QMap<ITState, IT_StateRunData*>::iterator i;
    for (i = testStateMap->begin(); i != testStateMap->end(); ++i)
    {
        if (i.value()->visible == false) continue;
        IntegrationTest *pTstDspData = i.value()->dispData;

        if ( (pTstDspData != NULL) && (pTstDspData != pLastResult) )
        {
            report.append( pTstDspData->getReportText() );
            pLastResult = pTstDspData;
        }
        else
        {
            report.append("\r\n");
        }
    }

    if (recommendation.length() > 0)
    {
        report.append("\r\n\r\n\r\n" + recommendation + "\r\n");
    }

    return report;
}

/**
 * leave a report in /tmp
 */
const char reportFile[] = "/tmp/zyconfig-it-results.txt";
void Z2IntegTests::tmpReportFile(void)
{
    // if possible, write to the /tmp dir
    QString s = getTestResultStr();
    QByteArray byteArray;
    byteArray = s.toUtf8();

    FILE *fp = fopen( reportFile, "w");
    if (fp != NULL)
    {
        fprintf(fp, "%s", byteArray.constData());
        fclose(fp);
    }
    integTestLog->Sync2Disk();
}


/**
 *  Inform user of logfile holding results
 */
void Z2IntegTests::notifyUserOfResultFile(void)
{
    QMessageBox copyBox;
    copyBox.setWindowTitle(QObject::tr("Integration Tests"));
    QString introText = QString
                (QObject::tr("A record of the results has been stored at\n") + reportFile);
    copyBox.setText(introText);
    copyBox.setIcon(QMessageBox::Question);
    copyBox.setStandardButtons(QMessageBox::Ok);
    copyBox.setModal(true);
    //remove the close button from the dialog if there is one
    Qt::WindowFlags wFlags = copyBox.windowFlags();
    if(Qt::WindowCloseButtonHint == (wFlags & Qt::WindowCloseButtonHint))
    {
        wFlags = wFlags ^ Qt::WindowCloseButtonHint;
        copyBox.setWindowFlags(wFlags);
    }
    copyBox.setDefaultButton(QMessageBox::Cancel);

    if (QMessageBox::Ok == copyBox.exec())
    {
        QClipboard *clipboard = QApplication::clipboard();
        clipboard->setText(getTestResultStr());
    }
}




/**
 *  Give the user a chance to save the test report
 */
void Z2IntegTests::offerCopyToClipboard(void)
{
    QMessageBox copyBox;
    copyBox.setWindowTitle(QObject::tr("Integration Tests"));
    QString introText = QString
                (QObject::tr("Would you like to copy the results to the clipboard ?"));
    copyBox.setText(introText);
    copyBox.setIcon(QMessageBox::Question);
    copyBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
    copyBox.setModal(true);
    //remove the close button from the dialog if there is one
    Qt::WindowFlags wFlags = copyBox.windowFlags();
    if(Qt::WindowCloseButtonHint == (wFlags & Qt::WindowCloseButtonHint))
    {
        wFlags = wFlags ^ Qt::WindowCloseButtonHint;
        copyBox.setWindowFlags(wFlags);
    }
    copyBox.setDefaultButton(QMessageBox::Cancel);

    if (QMessageBox::Ok == copyBox.exec())
    {
        QClipboard *clipboard = QApplication::clipboard();
        clipboard->setText(getTestResultStr());
    }
}

/**
 *  Launch point for Dialog
 */
int Z2IntegTests::exec()
{
    int ret = QDialog::Accepted;
    integTestLog->Write2LogF( "Start IT Run ... \n");

    if (pAssignedMonitor == NULL)
    {
        integTestLog->Write2LogF( "Set the monitor before starting.");
        return QDialog::Rejected;
    }

    initData();

    if (DebugMode)
    {
        if (testStateMap->contains(currentTest))
        {
            QString name;
            IT_StateRunData *stateData = testStateMap->value(currentTest);
            if (stateData->dispData)
                name = stateData->dispData->getName() ;
            integTestLog->Write2LogF( "Run: %s - %d\n", name.toLatin1().data(), stateData->elapsedSecs );
        }
    }

    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    showFullScreen();
    // this->setModal(true);
    update();
    this->move(monitorRect.topLeft());
    this->resize(monitorRect.width(), monitorRect.height());
    activateWindow();
    update();

    secondTick->setInterval(1000);      // milliseconds
    secondTick->start();

    QDialog::exec();
    if ((currentTest == Z2IntegTests::MT_Finished)   ||
        (currentTest == Z100_Finished) ||
        (currentTest == Z110_Finished)
       )
    {
        //offerCopyToClipboard();
        notifyUserOfResultFile();
    }

    ret = QDialog::Accepted;

    integTestLog->Write2LogF( "\tStop Tick.\n");
    secondTick->stop();
    pAssignedMonitor = NULL; // force reset for each use
    border = 0;

    return ret;
}

void Z2IntegTests::collectNewRawData()
{
    if (zxy100Data != NULL)
    {
        if (blackScreen)
        {
            zul_log(4, "BLACK-");
            zxy100DataBlack->collectNewRawData();
        }
        else
        {
            zul_log(4, "WHITE-");
            zxy100Data->collectNewRawData();
        }
    }
}

void Z2IntegTests::setAppVersionStrs(QString &versionText)
{
    versAppStr = versionText;
}
