/*
 *      Calibration Widget. Displays a number of points on the screen in order
 *      to calculate calibration data and then write it to the controller
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


/*
  CalibrationDialog
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <QtWidgets>
#include <QScreen>
#include "CalibrationDialog.h"

#include "ZytMath.h"
#include "debug.h"
#include "dbg2console.h"
#include "zytypes.h"
//#include "comms.h"
#include "services.h"
#include "configfile.h"


/* Calibration point locations (2)
 *  +---------+
 *  : 1     2 :
 *  :         :
 *  : 3     4 :
 *  +---------+
 */

// todo enum ??
#define CALP_TOP_LEFT           (0)
#define CALP_TOP_RIGHT          (1)
#define CALP_BOTTOM_LEFT        (2)
#define CALP_BOTTOM_RIGHT       (3)

#define NUM_POINTS              (CALP_BOTTOM_RIGHT + 1)

#define TIMER_MS                (100)
#define TIMEOUT                 (30 * 1000 / TIMER_MS)      // 30 seconds

#define DEFAULT_TARGET_MARGIN   (8) // border width as percentage of screen width

const QString CalibrationDialog::dualScreenOptions =
    QString("DUALLEFT,DUALRIGHT,DUALTOP,DUALBOTTOM");

const QString CalibrationDialog::screenModeStr =
    QString("SINGLESCREEN,DUALLEFT,DUALRIGHT,DUALTOP,DUALBOTTOM,MULTIMONITOR");

CalibrationDialog::CalibrationDialog(QWidget *parent) :
    QDialog(parent)
{
    showInfo = true;
    askConfirm = false;

    currentPointIndex = 0;
    screenMode = SingleScreen;

    targetMarginTop    = DEFAULT_TARGET_MARGIN;
    targetMarginBottom = DEFAULT_TARGET_MARGIN;
    targetMarginLeft   = DEFAULT_TARGET_MARGIN;
    targetMarginRight  = DEFAULT_TARGET_MARGIN;

    activeTimeOut = TIMEOUT;
    touchAvailable = false;
    monitorName = "";

    qtScaleFactor = 1.0F;
    QByteArray qtScaling = qgetenv("QT_SCALE_FACTOR");
    if (qtScaling.length() > 0)
    {
        QString fStr = qtScaling;
        bool ok;
        qtScaleFactor = fStr.toFloat(&ok);
        if (!ok) qtScaleFactor = 1.0F;
    }
}

QString CalibrationDialog::getMonitorForDevice(void)
{
    QString retVal = NULL;
    // check for previous controller-monitor binding in config file
    char cpuIdStr[30];
    if (zul_CpuID(cpuIdStr, 29))
    {
        if (TOUCH_DEBUG) fprintf(stderr, "Found CPU %s\n", cpuIdStr);
        ZyConfFile *zcf = new ZyConfFile(NULL);
        zcf->ReadFile();
        // fetch the monitor by controller
        char monName[12];
        if (zcf->GetString(cpuIdStr, monName, 12))
        {
            if (TOUCH_DEBUG) fprintf(stderr, "Found associated display: %s\n", monName);
            retVal = QString(monName);
        }
        delete zcf;
    }
    return retVal;
}

void CalibrationDialog::setMonitorForDevice (const char *monName)
{
    // store the controller-monitor binding
    char cpuIdStr[30];
    if (zul_CpuID(cpuIdStr, 29))
    {
        ZyConfFile *zcf = new ZyConfFile(NULL);
        zcf->ReadFile();
        // record the controller - monitor binding
        zcf->SetString(cpuIdStr, monName);
        // record this monitor's parameters - just FYI not used. (CFM - 27-9-'18)
        zcf->SetString(monName, selectedMonitor.getParams() );
        zcf->WriteFile();
        delete zcf;
    }
}

void CalibrationDialog::setMonitor(Monitor *mon)
{
    // copy the provided monitor data to local data
    screenMode = MultiScreen;
    selectedMonitor = *mon;
    selectedMonitor.getRect(&monitorRect);

    if (TOUCH_DEBUG)
    {
        fprintf(stderr, "MonitorSetting %s\n", selectedMonitor.getName(false));
        Size2d ms = selectedMonitor.getSize();
        fprintf(stderr, "MonitorSize %d,%d\n", ms.x, ms.y);
    }
}

void CalibrationDialog::setCustomMargins(int topMargin, int bottomMargin, int leftMargin, int rightMargin)
{
    targetMarginTop    = topMargin;
    targetMarginBottom = bottomMargin;
    targetMarginLeft   = leftMargin;
    targetMarginRight  = rightMargin;
}

void CalibrationDialog::setDefaultMargins()
{
    targetMarginTop    = DEFAULT_TARGET_MARGIN;
    targetMarginBottom = DEFAULT_TARGET_MARGIN;
    targetMarginLeft   = DEFAULT_TARGET_MARGIN;
    targetMarginRight  = DEFAULT_TARGET_MARGIN;
}

void CalibrationDialog::getScreenLoc(int index, QPoint *p)
{
    Size2d sz = selectedMonitor.getSize();
    int width  = sz.x;
    int height = sz.y;

    switch(index)
    {
        case CALP_TOP_LEFT:
            p->setX(width  * targetMarginLeft / 100);
            p->setY(height * targetMarginTop / 100);
            break;
        case CALP_TOP_RIGHT:
            p->setX(width  * (100 - targetMarginRight) / 100);
            p->setY(height * targetMarginTop / 100);
            break;
        case CALP_BOTTOM_LEFT:
            p->setX(width  * targetMarginLeft / 100);
            p->setY(height * (100 - targetMarginBottom) / 100);
            break;
        case CALP_BOTTOM_RIGHT:
            p->setX(width  * (100 - targetMarginRight) / 100);
            p->setY(height * (100 - targetMarginBottom) / 100);
            break;
    }
}

void CalibrationDialog::enableInfo(bool info)
{
    showInfo = info;
}

void CalibrationDialog::setTimeOut(int timeout)
{
    activeTimeOut = timeout * 1000 / TIMER_MS;
}

void CalibrationDialog::enableConfirm(bool yn)
{
    askConfirm = yn;
}

// returns zero on success, else a negative error code
int CalibrationDialog::setScreenMode(QString modeNameStr)
{
    if (TOUCH_DEBUG) fprintf(stderr, "Mode Name : '%s'\n",
                                    modeNameStr.toUtf8().data());
    if (screenModeStr.contains(modeNameStr))
    {
        screenMode = SingleScreen;    // failsafe

        QStringList list1 = screenModeStr.split(",");

        int numModeNames = list1.length();
        for (int index = 0; index < numModeNames; index ++)
        {
            // if we match the names, take the index
            if (0 == list1[index].compare(modeNameStr, Qt::CaseInsensitive))
            {
                screenMode = (CalibrationDialog::ScreenMode)index;
                if (TOUCH_DEBUG) fprintf(stderr, "ModeIndex: %d\n", index);
            }
        }

        if (screenMode == SingleScreen) return 0;

        // There should be only 2 displays
        QDesktopWidget *appDesktop = QApplication::desktop();
        int numDisplays = appDesktop->screenCount();
        if (numDisplays != 2) return -2;

        QRect disp0 = appDesktop->screenGeometry(0);
        QRect disp1 = appDesktop->screenGeometry(1);

        // both displays should have same WIDTH and HEIGHT
        if (disp0.width() != disp1.width()) return -3;
        if (disp0.height() != disp1.height()) return -3;

        // verify calibration request is valid for actual displays
        switch (screenMode)
        {
            case DualLeft:
                // both displays should have same TOP
                if (disp0.top() != disp1.top()) return -4;
                // locate targets on screen with smaller LEFT value
                if (disp0.left() < disp1.left())
                {
                    selectedMonitor.setRect(&disp0, "LEFT");
                }
                else
                {
                    selectedMonitor.setRect(&disp1, "LEFT");
                }
                break;
            case DualRight:
                // both displays should have same TOP
                if (disp0.top() != disp1.top()) return -4;
                // locate targets on screen with larger LEFT value
                if (disp0.left() < disp1.left())
                {
                    selectedMonitor.setRect(&disp1, "RIGHT");
                }
                else
                {
                    selectedMonitor.setRect(&disp0, "RIGHT");
                }
                break;
            case DualTop:
                // both displays should have same LEFT
                if (disp0.left() != disp1.left()) return -4;
                // locate targets on screen with smaller TOP value
                if (disp0.top() < disp1.top())
                {
                    selectedMonitor.setRect(&disp0, "TOP");
                }
                else
                {
                    selectedMonitor.setRect(&disp1, "TOP");
                }
                break;
            case DualBottom:
                // both displays should have same LEFT
                if (disp0.left() != disp1.left()) return -4;
                // locate targets on screen with larger TOP value
                if (disp0.top() < disp1.top())
                {
                    selectedMonitor.setRect(&disp1, "BOTTOM");
                }
                else
                {
                    selectedMonitor.setRect(&disp0, "BOTTOM");
                }
                break;
            default:        // remove SingleScreen unhandled warning
                break;
        }
        selectedMonitor.getRect(&monitorRect);
        if (TOUCH_DEBUG)
            fprintf(stderr, "%s TOPLEFT Location %d,%d\n",
                     __FUNCTION__, monitorRect.x(), monitorRect.y() );

        return 0;
    }

    if (TOUCH_DEBUG) fprintf(stderr, "No mode match\n");
    return -1;
}

void CalibrationDialog::paintEvent(QPaintEvent*)
{
    QString userText;
    QPainter painter(this);
    int width = monitorRect.width();
    int height = monitorRect.height();
    int dimension = (width < height) ? width : height;
    bool drawLines = false;
    int fontPointSize = (dimension * 8) / (600 * qtScaleFactor);

    border = max(width, height) / 40;

    painter.fillRect(rect(), Qt::white);
    painter.setRenderHint(QPainter::Antialiasing);
    QFont font=painter.font();
    font.setPointSize ( fontPointSize );
    painter.setFont(font);

    if (TOUCH_DEBUG>1) fprintf(stderr, "%s, pointNum:%d\n",
                                    __FUNCTION__, currentPointIndex);

    //set size and position of text box
    if (currentPointIndex < NUM_POINTS)
    {
        userText = QString( tr("On-board Controller Calibration\n") +
                            "~~~\n" +
                            tr("calibration data is saved to the touch controller\n") +
                            "~~~\n" +
                            tr("ESC - restore default calibration\n") +
                            "~~~\n" +
                            tr("touch and hold at the center of the target\n\n"));
        if (activeTimeOut > 0)
        {
            userText +=
                QString( tr("(Timeout in %1 seconds)")).arg((int)(timeRemain/10 + 1));
        }
        drawLines = true;
    }
    else
    {
         userText = QString(tr("Writing data to system file.\n"));
    }

    QPoint topLeft;
    QPoint bottomRight;

    if ((showInfo) || (currentPointIndex >= NUM_POINTS))
    {
        int cBorder = 300;
        int ww = width / qtScaleFactor;
        int hh = height / qtScaleFactor;

        topLeft        = QPoint((ww/2) - cBorder, (hh/2) - cBorder);
        bottomRight    = QPoint((ww/2) + cBorder, (hh/2) + cBorder);

        textBox.setTopLeft(topLeft);
        textBox.setBottomRight(bottomRight);

        //draw user text box
        painter.setPen(Qt::darkGreen);
        //painter.drawRect(textBox);
        painter.drawText(textBox, (Qt::AlignCenter | Qt::TextWordWrap), userText);
    }

    if(currentPointIndex >= NUM_POINTS) return;

    int targetRadius = border / 3;

    //find point for current calibration target
    setCalibrationPoint(currentPointIndex);

    //draw calibration target
    drawTarget(currentPoint, targetRadius, &painter);

    if (drawLines)
    {
        QPoint *pTL, *pBR;
        pTL = &screenPoints[CALP_TOP_LEFT];
        pBR = &screenPoints[CALP_BOTTOM_RIGHT];

        painter.setPen(Qt::black);
        painter.drawLine(0, pTL->y(),   width, pTL->y());
        painter.drawLine(0, pBR->y(),   width, pBR->y());
        painter.drawLine(pTL->x(), 0,   pTL->x(), height);
        painter.drawLine(pBR->x(), 0,   pBR->x(), height);
    }
}

int CalibrationDialog::exec()
{
    int         ret     = QDialog::Rejected;
    int16_t     PID;

    if (TOUCH_DEBUG) fprintf( stderr, "Current scaling is set to '%f'\n", qtScaleFactor );

    zul_getDevicePID(&PID);
    devPID = PID;

    Size2d dTSize = getScreenSize(0);
    desktopSize.setWidth ( dTSize.x );
    desktopSize.setHeight( dTSize.y );
    if (TOUCH_DEBUG) fprintf (stderr, "Desktop W:%d H:%d\n", desktopSize.width(), desktopSize.height() );

    touchMonitorTick = new QTimer(this);
    touchMonitorTick->setInterval(TIMER_MS);
    touchMonitorTick->setSingleShot(false);
    QObject::connect(touchMonitorTick,SIGNAL(timeout()), this,SLOT(tick()));

    mZxy100Data = (devPID == ZXY100_PRODUCT_ID);
    // To Do - should the above include ZXY110 ??

    screenPoints.clear();
    for (int index = CALP_TOP_LEFT; index <= CALP_BOTTOM_RIGHT; index++)
    {
        QPoint targetLocation;
        getScreenLoc(index, &targetLocation);
        screenPoints.append(targetLocation /= qtScaleFactor );
        if (TOUCH_DEBUG) fprintf (stderr, "[%d] %d,%d\t", index, targetLocation.x(), targetLocation.y() );
    }
    if (TOUCH_DEBUG) fprintf (stderr, "\n");

    // "showFullScreen" may not work on system without a window manager
    //    Therefore - some odd duplication here ... ToDo: find universal solution.
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    showFullScreen();
    update();

    this->move(monitorRect.topLeft());
    this->resize(monitorRect.width(), monitorRect.height());
    activateWindow();
    if (TOUCH_DEBUG)
    {
        fprintf(stderr, "MonitorParams: %s\n", selectedMonitor.getParams() );
    }
    update();
    this->move(monitorRect.topLeft());
    this->resize(monitorRect.width(), monitorRect.height());
    update();

    currentPointIndex = 0;
    timeRemain = activeTimeOut;
    this->setModal(true);

    {
        zul_inhibitFlashWrites(true);

#if defined(Q_OS_DARWIN)
        zul_SetPrivateTouchMode(1);
#endif

        // remove existing on-board calibration
        zul_clearOnBoardCal();
        set_axis_options(false, false, false);

        zul_inhibitFlashWrites(false);
    }

    touchMonitorTick->start();

    zul_useKernelIFace(true);
    ret = QDialog::exec();
    zul_useKernelIFace(false);

    if (QDialog::Accepted == ret)
    {
        // calibration complete
        emit APIResult(ZytAPIResult::Success);

        // store the controller-monitor binding
        setMonitorForDevice (selectedMonitor.getName(false));

        if(screenMode == MultiScreen)
        {
            const char scriptPath1[]="../multi-display/setup.sh";
            const char scriptPath2[]="../../multi-display/setup.sh";
            const char *cmd = scriptPath1;

            {
                struct stat statBuf;
                // check the location of the multi-display folder relative supplied binaries
                if (stat(cmd, &statBuf) == -1)
                {
                    // check the location of the multi-display folder relative to Source/bin
                    cmd = scriptPath2;
                }
            }

            // add output redirects if we want to keep the output quiet
            // const char *cmd = "../multi-display/setup.sh >/dev/null 2>/dev/null";
            // run the multi-monitor setup script
            int exitCode = system(cmd);
            if ( exitCode != 0)
            {
                // show error
                fprintf(stderr, ">>> Multi-Display Setup Error (setup.sh) : exit code %d\n", exitCode);
                QMessageBox errorBox;
                errorBox.setWindowTitle(tr("Missing File"));
                QString errorText = QString(tr("The script setup.sh count not be found in either of the following locations\n"));
                errorText += "\n\t";
                errorText += scriptPath1;
                errorText += "\n\t";
                errorText += scriptPath2;
                errorText += "\n";
                errorBox.setText(errorText);
                errorBox.setIcon(QMessageBox::Critical);
                errorBox.setStandardButtons(QMessageBox::Ok);
                errorBox.setModal(true);
                errorBox.exec();
            }
        }
    }

    touchMonitorTick->stop();
    delete touchMonitorTick;

#if defined(Q_OS_DARWIN)        // __APPLE__ also
    zul_SetPrivateTouchMode(0);
#endif

    return ret;
}

void CalibrationDialog::touchRelease(QPoint *actual)
{
    // protect against double taps ...
    // FIXME ...

    if(currentPointIndex > 0)
    {
        QPoint lastPoint = actualPoints[currentPointIndex - 1];
        //check the new point is far enough away from the last one
        if  ( ! ( (actual->x() > (lastPoint.x() - border)) &&
                  (actual->x() < (lastPoint.x() + border)) &&
                  (actual->y() > (lastPoint.y() - border)) &&
                  (actual->y() < (lastPoint.y() + border))
                )
            )
        {
            storeCalibrationPoint(*actual);
        }
        else
        {
            fprintf(stderr, "TOO CLOSE -- %s: CPI %d >= NUM_PTS %d \n",
                                __FUNCTION__, currentPointIndex, NUM_POINTS);
        }
    }
    else
    {
        storeCalibrationPoint(*actual);
    }

    if (TOUCH_DEBUG) fprintf(stderr, "%s: CPI %d >= NUM_PTS %d \n",
                                __FUNCTION__, currentPointIndex, NUM_POINTS);

    if(currentPointIndex >= NUM_POINTS)
    {
        if (TOUCH_DEBUG) fprintf(stderr, "%s: %d => DONE\n", __FUNCTION__, currentPointIndex);
        update();
        QApplication::processEvents();

        calibrate();
        accept();
    }
    else
    {
        timeRemain = activeTimeOut;
        update();
    }
}

void CalibrationDialog::storeCalibrationPoint(QPoint actual)
{
    if(currentPointIndex == idealPoints.size())
    {
        idealPoints.append(currentSensorIdeal);
    }
    else if(currentPointIndex < idealPoints.size())
    {
        idealPoints[currentPointIndex] = currentSensorIdeal;
    }
    else
    {
        //should never reach here, if we do we have a problem!
        fprintf(stderr, "%s Error 1 @ %d\n", __FUNCTION__, currentPointIndex);
        exit(1);
    }

    if(currentPointIndex == actualPoints.size())
    {
        actualPoints.append(actual);
    }
    else if(currentPointIndex < actualPoints.size())
    {
        actualPoints[currentPointIndex] = actual;
    }
    else
    {
        //should never reach here, if we do we have a problem!
        fprintf(stderr, "%s Error 2 @ %d\n", __FUNCTION__, currentPointIndex);
        exit(1);
    }

    currentPointIndex++;
    if (TOUCH_DEBUG) fprintf(stderr, "%s Increased Current Point to %d\n",
                                __FUNCTION__, currentPointIndex);
}

void CalibrationDialog::drawTarget(QPoint centre, int radius, QPainter *painter)
{
    //Store previous painter settings
    painter->save();

    int x = centre.x();
    int y = centre.y();
    int boxSize = (radius * 2);
    int boxXPos = (x - radius);
    int boxYPos = (y - radius);

    if (TOUCH_DEBUG>1) fprintf(stderr, "%s: %d %d\n", __FUNCTION__, x, y);

    if(currentPointIndex < NUM_POINTS)
    {
        //draw full Rectangle as per the new style in Windows and Android.
        QColor col = (touchAvailable) ? Qt::green : Qt::red;
        painter->fillRect(boxXPos, boxYPos, boxSize, boxSize, col);
    }

    //restore painter settings
    painter->restore();
}

void CalibrationDialog::setCalibrationPoint(int index)
{
    int xi, yi;

    currentPoint = screenPoints[0];
    if (currentPointIndex < screenPoints.size())
    {
        currentPoint = screenPoints[currentPointIndex];
    }

    switch(index)
    {
        case CALP_TOP_LEFT:
            xi = 4095 * targetMarginLeft / 100;
            yi = 4095 * targetMarginTop / 100;
            currentSensorIdeal = QPoint(xi,yi);
            break;

        case CALP_TOP_RIGHT:
            xi = 4095 * (100 - targetMarginRight) / 100;
            yi = 4095 * targetMarginTop / 100;
            currentSensorIdeal = QPoint(xi,yi);
            break;

        case CALP_BOTTOM_LEFT:
            xi = 4095 * targetMarginLeft / 100;
            yi = 4095 * (100 - targetMarginBottom) / 100;
            currentSensorIdeal = QPoint(xi,yi);
            break;

        case CALP_BOTTOM_RIGHT:
            xi = 4095 * (100 - targetMarginRight) / 100;
            yi = 4095 * (100 - targetMarginBottom) / 100;
            currentSensorIdeal = QPoint(xi,yi);
            break;
    }
}

void CalibrationDialog::calibrate()
{
    switch (screenMode)
    {
        case MultiScreen:
            // this is the same as the case for a single screen calibration Window
            // as we use the xinput --map-to-output command to deal with multiple
            // displays

            // handleMultiScreenSetup(); // does nothing
            break;
        case SingleScreen:
            // do nothing
            break;
        default:
            // This option should be handled by the multi-screen
            // case above - this is being deprecated.
            handleDualScreenSetup();
            break;
    }

    zul_inhibitFlashWrites(true);

    auto_fix_axes();

    // the TOP_LEFT reference screen points (0..4095 ranged)
    calibrationResult.val[0] = idealPoints[CALP_TOP_LEFT].x();
    calibrationResult.val[1] = idealPoints[CALP_TOP_LEFT].y();

    // the TOP_LEFT actual touch values (0..4095 ranged)
    calibrationResult.val[2] = actualPoints[CALP_TOP_LEFT].x();
    calibrationResult.val[3] = actualPoints[CALP_TOP_LEFT].y();

    // the Bottom Right reference screen points (0..4095 ranged)
    calibrationResult.val[4] = idealPoints[CALP_BOTTOM_RIGHT].x();
    calibrationResult.val[5] = idealPoints[CALP_BOTTOM_RIGHT].y();

    // the Bottom Right actual touch values (0..4095 ranged)
    calibrationResult.val[6] = actualPoints[CALP_BOTTOM_RIGHT].x();
    calibrationResult.val[7] = actualPoints[CALP_BOTTOM_RIGHT].y();


    // on board cal uses 8 config params on all ZXY100, 110, 150, 200, 300 & 500s
    if (TOUCH_DEBUG)
    {
        for (int x=0; x<ZXY100_CN_ONBOARD_CAL_COUNT; x++) {
            fprintf(stderr, "%s %d: %d\n", __FUNCTION__, x, calibrationResult.val[x]);
        }
    }

    zul_setOnBoardCal(&calibrationResult);

    zul_inhibitFlashWrites(false);

    emit APIResult(ZytAPIResult::Success);

    this->hide();
}


void CalibrationDialog::handleMultiScreenSetup(void)
{
}

void CalibrationDialog::handleDualScreenSetup(void)
{
    int xInc=0, yInc=0, xDiv=1, yDiv=1;

    switch (screenMode)
    {
        case DualLeft:
            xDiv = 2;
            break;

        case DualRight:
            xInc = 4096;
            xDiv = 2;
            break;

        case DualTop:
            yDiv = 2;
            break;

        case DualBottom:
            yInc = 4096;
            yDiv = 2;
            break;

        case SingleScreen:
        default:
            return;
    }

    // apply the required translation:
    QPoint temp = QPoint(xInc, yInc);
    idealPoints[CALP_TOP_LEFT]     += temp;
    idealPoints[CALP_BOTTOM_RIGHT] += temp;

    // apply the required scaling
    idealPoints[CALP_TOP_LEFT]    .setX( idealPoints[CALP_TOP_LEFT]    .x() / xDiv );
    idealPoints[CALP_BOTTOM_RIGHT].setX( idealPoints[CALP_BOTTOM_RIGHT].x() / xDiv );

    idealPoints[CALP_TOP_LEFT]    .setY( idealPoints[CALP_TOP_LEFT]    .y() / yDiv );
    idealPoints[CALP_BOTTOM_RIGHT].setY( idealPoints[CALP_BOTTOM_RIGHT].y() / yDiv );
}

void CalibrationDialog::tick()
{
    Contact calPoint;

    if (TOUCH_DEBUG>1)    fprintf (stderr, "Tick ###\n");

    // wait for touch to appear
    if (!touchAvailable)
    {
        touchAvailable = zul_TouchAvailable(&calPoint);
    }
    else
    {
        // then wait for touch to disappear

        if (zul_GetTouchUp(70, &calPoint))
        {
            touchAvailable = false;

            touchRelease(new QPoint(calPoint.x,calPoint.y));

            if (TOUCH_DEBUG)
            {
                fprintf(stderr, "\t\t # --UP--- #  %04d, %04d\n", calPoint.x, calPoint.y );
            }
        }
        else
        {
            if (TOUCH_DEBUG)
            {
                fprintf(stderr, "\t\t # -TRACK- #  %04d, %04d\n", calPoint.x, calPoint.y );
            }
        }
    }

    update();
    QApplication::processEvents();

    if ( (timeRemain-- <= 0) && (activeTimeOut > 0) )
    {
        reject();
    }
}

/**
 * Point Transforms - used for getting calibration transforms correct
 * while setting appropriate axis flips. (see auto_fix_axes)
 */
void CalibrationDialog::switchXYPoint(QPoint *in)
{
    int a = in->x(), b = in->y();

    if (mZxy100Data)
    {
        in->setX(4095 - b);
        in->setY(a);
    }
    else
    {
        in->setX(b);
        in->setY(a);
    }
}
void CalibrationDialog::flipXPoint(QPoint *in)
{
    in->setX(4095 - in->x());
}
void CalibrationDialog::flipYPoint(QPoint *in)
{
    in->setY(4095 - in->y());
}


/**
 * Correct the axes settings based on what we've detected from the 4 touches.
 */
void CalibrationDialog::auto_fix_axes(void)
{
    // based on the calibration data, fix the axis swap and flip settings


    /* we have reference touch locations based on an ANDROID displayed pattern:
        +------------+
        |  0     1   |
        |            |   ANDROID pattern
        |  2     3   |
        |            |
        +------------+

     *  we want to re-use the Linux flip determination code, so we make some linux (Basic Setup)
        styled touch values, from the Android touch data.

        +------------+
        |  2     5   |
        |     1      |   LINUX Pattern, from basic setup.
        |  3     4   |
        |            |
        +------------+
    */
    bool swapAxes, invertXaxis, invertYaxis;

    // generate linux style values from android touches, so that we can re-use the
    // linux axes corrections

    int linuxX2 = (actualPoints[0].x() & 0x0FFF);
    int linuxY2 = (actualPoints[0].y() & 0x0FFF);

    int linuxX3 = (actualPoints[2].x() & 0x0FFF);
    int linuxY3 = (actualPoints[2].y() & 0x0FFF);

    int linuxX5 = (actualPoints[1].x() & 0x0FFF);
    int linuxY5 = (actualPoints[1].y() & 0x0FFF);

    // synthesize a centre point which is missing from the available touch data.
    int linuxX1 = (linuxX3 + linuxX5) / 2;
    int linuxY1 = (linuxY3 + linuxY5) / 2;

    if (TOUCH_DEBUG)
    {
        fprintf(stderr, "TouchPoint 0: %d,%d\n", linuxX2, linuxY2);
        fprintf(stderr, "TouchPoint 1: %d,%d\n", linuxX5, linuxY5);
        fprintf(stderr, "TouchPoint 2: %d,%d\n", linuxX3, linuxY3);
        fprintf(stderr, "TouchPoint-C: %d,%d\n", linuxX1, linuxY1);
    }

    // determine the axis settings needed based on these touched-locations
    char axisType;
    if (linuxX2 < linuxX1)
    {
        if (linuxY2 < linuxY1)
        {
            if (linuxY3 > linuxY1)
            {
                // here we deal with the touches  |  2     5
                //                                |     1
                //                                |  3     4
                swapAxes = false; invertXaxis = false; invertYaxis = false;
                axisType = 'A';
            }
            else
            {
                // here we deal with the touches  |  2     3
                //                                |     1
                //                                |  5     4
                swapAxes = true; invertXaxis = false; invertYaxis = false;

                if (mZxy100Data) invertXaxis = !invertXaxis;
                axisType = 'B';
            }
        }
        else  // (linuxY2 > linuxY1)
        {
            if (linuxY3 < linuxY1)
            {
                // here we deal with the touches  |  3     4
                //                                |     1
                //                                |  2     5
                swapAxes = false; invertXaxis = false; invertYaxis = true;
                axisType = 'C';
            }
            else //(linuxY3 > linuxY1)
            {
                // here we deal with the touches  |  5     4
                //                                |     1
                //                                |  2     3
                swapAxes = true; invertXaxis = true; invertYaxis = false;

                if (mZxy100Data) invertXaxis = !invertXaxis;
                axisType = 'D';
            }
        }
    }
    else // (linuxX2 > linuxX1)
    {
        if (linuxY2 < linuxY1)
        {
            if (linuxY3 > linuxY1)
            {
                // here we deal with the touches  |  5     2
                //                                |     1
                //                                |  4     3
                swapAxes = false; invertXaxis = true; invertYaxis = false;
                axisType = 'E';
            }
            else // (linuxY3 < linuxY1)
            {
                // here we deal with the touches  |  3     2
                //                                |     1
                //                                |  4     5
                swapAxes = true; invertXaxis = false; invertYaxis = true;

                if (mZxy100Data) invertXaxis = !invertXaxis;
                axisType = 'F';
            }
        }
        else  // (linuxY2 > linuxY1)
        {
            if (linuxY3 > linuxY1)
            {
                // here we deal with the touches  |  4     5
                //                                |     1
                //                                |  3     2
                swapAxes = true; invertXaxis = true; invertYaxis = true;

                if (mZxy100Data) invertXaxis = !invertXaxis;
                axisType = 'G';
            }
            else //(linuxY3 < linuxY1)
            {
                // here we deal with the touches  |  4     3
                //                                |     1
                //                                |  5     2
                swapAxes = false; invertXaxis = true; invertYaxis = true;
                axisType = 'H';
            }
        }
    }

    // UsbConnManager.selectedAxisOptionStr = getString(R.string.axisStyle) + axisType;

    /* move the mTouchPoints[] values so that their point-0 values (x & y) are close to the
       0,0 location, and the point-3 values (x & y) are furthest from 0,0
     */
    for (int j = 0; j<4; j++) {

        // the swap must be handled first !
        if (swapAxes)
        {
           switchXYPoint(&actualPoints[j]);
        }
        if (invertXaxis)
        {
           flipXPoint(&actualPoints[j]);
        }
        if (invertYaxis)
        {
           flipYPoint(&actualPoints[j]);
        }
    }

    // make the required axis flip changes on the device
    set_axis_options (swapAxes, invertXaxis, invertYaxis);

    linuxX2 = (actualPoints[0].x() & 0x0FFF);
    linuxY2 = (actualPoints[0].y() & 0x0FFF);

    linuxX3 = (actualPoints[2].x() & 0x0FFF);
    linuxY3 = (actualPoints[2].y() & 0x0FFF);

    linuxX5 = (actualPoints[1].x() & 0x0FFF);
    linuxY5 = (actualPoints[1].y() & 0x0FFF);

    // synthesize a centre point which is missing from the available touch data.
    linuxX1 = (linuxX3 + linuxX5) / 2;
    linuxY1 = (linuxY3 + linuxY5) / 2;

    if (TOUCH_DEBUG)
    {
        fprintf(stderr,"After Transforms ... [%c]\n", axisType);
        fprintf(stderr,"TouchPoint 0: %d,%d\n", linuxX2, linuxY2);
        fprintf(stderr,"TouchPoint 1: %d,%d\n", linuxX5, linuxY5);
        fprintf(stderr,"TouchPoint 2: %d,%d\n", linuxX3, linuxY3);
        fprintf(stderr,"TouchPoint-C: %d,%d\n", linuxX1, linuxY1);
    }
}

void CalibrationDialog::set_axis_options(bool xy, bool x, bool y)
{
    uint16_t    setting;
    uint8_t     mXYSwapIndex, mXFlipIndex, mYFlipIndex;

    if (TOUCH_DEBUG) fprintf(stderr, "Setting axis options: xy,xi,yi :: %d,%d,%d\n", xy, x, y);

    setting = (short) (xy ? 1 : 0);

    switch (devPID)
    {
        case ZXY100_PRODUCT_ID:
            mXYSwapIndex = ZXY100_CI_FLEXI_POSITION;
            mXFlipIndex  = ZXY100_CI_FLIP_X;
            mYFlipIndex  = ZXY100_CI_FLIP_Y;

            setting += 1;           // flexitail position is DIFFERENT

            break;

        case ZXY110_PRODUCT_ID:
            mXYSwapIndex = ZXY110_CI_SWAP_XY;
            mXFlipIndex  = ZXY110_CI_INVERT_X;
            mYFlipIndex  = ZXY110_CI_INVERT_Y;
            break;

        default:    // multitouch controllers 150..*
            mXYSwapIndex = ZXYMT_CI_SWAP_XY;
            mXFlipIndex  = ZXYMT_CI_INVERT_X;
            mYFlipIndex  = ZXYMT_CI_INVERT_Y;
            break;
    }

    zul_setConfigParamByID(mXYSwapIndex, setting);

    setting = (uint16_t) (x ? 1 : 0);
    zul_setConfigParamByID(mXFlipIndex, setting);

    setting = (uint16_t) (y ? 1 : 0);
    zul_setConfigParamByID(mYFlipIndex, setting);
}
