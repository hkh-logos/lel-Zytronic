/*
 *      Widget to display a text string of the wirelevels from the controller as collected
 *      when the controller is in raw mode.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include <QtWidgets>
#include "WireLevelXLabels.h"
#include "ZytMath.h"
#include "WireLevelDisplay.h"

//defines used for scaling the widget
#define SCALE (10)      // pretty huge as it all gets scaled and the smaller fonts look awful if this is small
#define MAX_VAL     (258 * SCALE)
#define BIG_NUMBER  (20*SCALE)   // used to draw an enclosing box around text, for it to be centered in, without clipping its edges

WireLevelXLabels::WireLevelXLabels(QWidget *parent) : QFrame(parent)
{
    m_parent = parent;
    //setFrameShape(QFrame::StyledPanel);
    //setBackgroundRole(QPalette::Button);

    //Set a reasonable minimum size
    setMinimumWidth(WLD_MIN_WIDTH);
    setMinimumHeight(30);
}

void WireLevelXLabels::drawTextCentered(QPainter *painter, int x, int y, const QString &text)
{
  painter->save();
  painter->translate(x, y);
  painter->rotate(270);
  painter->drawText(0 - BIG_NUMBER, 0 - BIG_NUMBER, 2*BIG_NUMBER, 2*BIG_NUMBER, Qt::AlignCenter, text);
  painter->restore();
}

void WireLevelXLabels::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QPen indexPen = QPen(Qt::black);
    QPen valuePen = QPen(QColor(255, 128, 0));      // orange
    int width = size().width();
    int height = size().height();
    int minor_axis = height * SCALE;

    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::white);
    painter.drawRect(0, 0, width, height);

    painter.setBrush(Qt::NoBrush);

    // set font size
    QFont myFont = painter.font();
    if( xWires.size() < 20 )
    {
        myFont.setPointSize(6 *SCALE);
    }
    else if( xWires.size() < 40 )
    {
        myFont.setPointSize(5 *SCALE);
    }
    else
    {
        // for really large numbers of wires, tiny text is easist to read as there are gaps between numbers
        myFont.setPointSize(3 *SCALE);
        minor_axis = minor_axis / 2;    // make text display fatter - easier to read at small sizes
    }
    painter.setFont(myFont);

    //scale widget so we can use values provided from controller without
    //having to manipulate them
    painter.scale((float)width / MAX_VAL, (float)height / minor_axis);

    float xWireSpacing = findSpacing(xWires);

    int inc = 4;
    if (xWires.size() < 18)
    {
        inc = 1;
    }
    for(int i = 0; i < xWires.size(); i++)
    {
        int linePos = findLinePosition(i, xWireSpacing);

	if ((i+1) % inc == 0)
	{
            painter.setPen(indexPen);
            drawTextCentered(&painter, linePos, minor_axis*0.2, QString::number( i+1 ));
	}

        painter.setPen(valuePen);
        drawTextCentered(&painter, linePos, minor_axis*0.7, QString::number( xWires[i] ));
    }

    QFrame::paintEvent(event);
}

int WireLevelXLabels::findLinePosition(const int index, const float spacing)
{
    return round(((index + 1) * 2 * spacing) - (spacing / 2));
}

float WireLevelXLabels::findSpacing(const QVector<int> wires)
{
    return ((float)MAX_VAL / ((wires.size() * 2) + 1));
}

void WireLevelXLabels::setWireLevels(const QVector<int> xWireLevels)
{
    xWires = xWireLevels;
    update();
}

