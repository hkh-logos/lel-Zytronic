/*
 *      Threshold Setting Widget. Displays a number of points on the screen in
 *      order to evaluate touch sensitivity data and then write it to the
 *      controller.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef SETUPSENSDIALOG_110_H
#define SETUPSENSDIALOG_110_H

#include "SetupSensDialog_BASE.h"

#include "services.h"
#include "Zxy100Data.h"

// ===  CLASS DEFINITION ============================================

class SetupSensDialog_110 : public SetupSensDialog_BASE
{
Q_OBJECT

public:
        SetupSensDialog_110(QWidget *parent = 0);
        void        setZXY100Data(Zxy100Data *dd);

public slots:
        //int exec();                       see super class

protected:
        //void paintEvent(QPaintEvent*);    see super class
        bool initData2(void);
        void applySettings(void);

private slots:
        //void tick();                      see super class
        void zxy110RestoreDefault();

private:

        void            updateSetProposal   (void);
        int             getPseudoTouchSignal(void);
        //void            changeState(StateChange transition);  pulled to BASE
        void            changeStateWhenRestoreDone (void);      // ZXY110 ONLY!
        int             getSignalLevel(void);
        void            getSignalLocation(uint16_t *tp_x, uint16_t *tp_y);

        int             storeStateData(void);
        void            getNextState(void);
        int             getStateTO(void);
        void            prepNewState(void);

        void            partialRestoreFactorySettings();
        bool            errorEventsOccurred(void);
        void            haltRawData();

        // special initial device state for SelfCap controllers
        Zxy110SysState  zxy110initState;
        Zxy100Data      *   zxy100Data;

        QTimer          *   zxy110RestoreDefaultTimer;
        bool                zxy110IsRestoringToDefaults;

        // variables to supervise time controller spend with (controllerFirstTouchModeStatus == 1)
        uint16_t        firstTouchModeTimeout, firstTouchModeTimer;
        uint16_t        controllerFirstTouchModeStatus;
};

#endif // SETUPSENSDIALOG_110_H
