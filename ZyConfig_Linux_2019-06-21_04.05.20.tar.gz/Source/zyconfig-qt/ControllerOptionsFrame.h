/*
 *      Content of the Touch Options tab in the Configuration tab.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef CONTROLLEROPTIONSFRAME_H
#define CONTROLLEROPTIONSFRAME_H

#include <QtWidgets>

#include "ZytContentFrame.h"
#include "CalibrationDialog.h"
#include "ConfigSaveDialog.h"
#include "ConfigLoadDialog.h"
#include "BigLabeledSlider.h"
#include "AxisOptionsFrame.h"
#include "MonitorSelect.h"
#include "MarginSelect.h"

class ControllerOptionsFrame : public ZytContentFrame
{
    Q_OBJECT

public:
    explicit    ControllerOptionsFrame(QWidget *parent = 0);

    void        reReadValues();
    void        showOverlay();
    void        hideOverlay();
    static      QTime getbuttonPressHoldoff(void);

signals:
    void        reReadRequired();
    void        reReadAxesReq();

private slots:
    void        restoreDefaults();
    void        forceEqualization();
    void        deleteCalibration();
    void        customCalibration();
    void        startSaveConfig();
    void        startLoadConfig();
    void        changeMouseMode();
    void        changePointClick();
    void        changeNumTouches();

private:
    void        createWidgets();
    void        readFromController();
    void        createConnections();
    QLayout *   createLayout();

    bool                zxy100Interface;

    QGroupBox           *f0, *f1, *f2, *f3;

    QPushButton         *deleteCalButton;
    QPushButton         *customCalButton;
    QPushButton         *restoreButton;
    QPushButton         *forceEqButton;

    QPushButton         *saveButton;
    QPushButton         *loadButton;

    QShortcut           *shortcut;   // remove ?

    QLabel              *restOverlay;
    QLabel              *calOverlay;
    QLabel              *forceEqOverlay;

    QLabel              *calTitle;
    QLabel              *controllerTitle;
    QLabel              *settingTitle;

    BigLabeledSlider    *numTouchSlider;
    QCheckBox           *mouseModeChkBox;
    QCheckBox           *pointClickChkBox;

    QLabel              *discOverlay;   // remove ?

    static QTime        buttonPressHoldoff;

    CalibrationDialog   caliDialog;
    ConfigSaveDialog    configSaveDialog;
    ConfigLoadDialog    configLoadDialog;
    MonitorSelect       monitorSelector;
    MarginSelect        marginSelector;

    int16_t             devPID;
    uint8_t             PointClickParam;
};

#endif // CONTROLLEROPTIONSFRAME_h
