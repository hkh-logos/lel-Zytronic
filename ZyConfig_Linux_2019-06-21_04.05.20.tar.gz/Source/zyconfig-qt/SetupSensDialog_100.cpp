/*
 *      Basic Setup Process. Displays a number of points on the screen in order
 *      to evaluate touch sensitivity data and then write it to the controller.
 *      Also set the axes for the given sensor-display integration.
 *      Also, On multi-touch controllers, set the noise handling parameters.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *366

 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


/*
  SetupSensDialog_100

    16/1/2019 : covers ZXY100

    This class is designed to guide a user through a process which determines
    a reasonable set of values for the following
    - the sensitivity setting
    - the sensor orientation:
            - axes swapped, or normal
            - axis flipped, or normal

    - there are no ZXY100 Palm Detection services

    - there is no ZXY100 First Touch Mode

    Users need not learn about these settings, only follow the on-screen guidance

    The whole process is driven by the periodic tick() operation, located in the base class

    NB: This does not complete a calibration!

    --------------------

    Basic Call Tree (see BASE class):

        exec()
            initData()
            start fastTick to call tick() -- see 'TICKS_PER_SECOND'
            QDialog::exec()

        tick()
            conditionally sample data
            if (state.timeout passed) changeState()

        changeState()
            save data from controller at end of state period
            determine next state, and period (terminate on error, or completion)
            move to new state, and send prep commands to controller

    --------------------

    NB: Also, separate the 'view' from the 'controller'!
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

#include "services.h"
#include "services_sc.h"
#include "debug.h"
#include "logfile.h"

#include "Zxy100Data.h"
#include "SetupSensDialog_100.h"


/**********************************************************
 *          Constructor
 *********************************************************/

SetupSensDialog_100::SetupSensDialog_100(QWidget *parent) : SetupSensDialog_BASE(parent)
{
    zxy100Data = NULL;
    basicSetupLog->Write2Log("Basic Setup Created");
}


/**
 * remember provided with Zxy100Data (self-cap) object
 */
void SetupSensDialog_100::setZXY100Data(Zxy100Data *dd)
{
    zxy100Data = dd;
}

/**
 * module global initialisation
 */
bool SetupSensDialog_100::initData2(void)
{
    basicSetupLog->Write2Log( "Basic Setup - ZXY110 - RESTART" );
    return true;
}

/*
 * update the setProposal values, based on all data collected.
 * called from BASE class processData()
 */
void SetupSensDialog_100::updateSetProposal(void)
{
    setProposal.pseudoUpperThr = state.touchMinimum - zxy100Data->BS_FinalThresholdAdjustment;
    if (setProposal.pseudoUpperThr < 12)
    {
        setProposal.pseudoUpperThr = 12;       // MAGIC
    }
}

/**
 * return the minimum of the X and Y max accumulated signal
 *
 */
int SetupSensDialog_100::getPseudoTouchSignal(void)
{
    int a = touchData.minAtX[touchData.xLoc];
    int b = touchData.minAtY[touchData.yLoc];
    return (a < b) ? a : b;
}


/**
 * following processData() the controller is configured here
 */
void SetupSensDialog_100::applySettings(void)
{
    basicSetupLog->Write2LogF("Write UThres:%03d PalmT:%03d - SwapAxis:%d FlipX:%d FlipY:%d",
                        setProposal.pseudoUpperThr, setProposal.palmThresh,
                        setProposal.swapAxes, setProposal.invertXaxis, setProposal.invertYaxis);

    FILE *fp = fopen("/tmp/ZyConfig-BasicSettings.txt", "w");
    if (fp != NULL)
    {
        fprintf(fp, "Glass Thickness: %1d  Upper Threshold:%03d Palm Rejection Threshold:%03d\r\n",
                    setProposal.glassThickness,
                    setProposal.pseudoUpperThr,
                    setProposal.palmThresh);
        fprintf(fp, "SwapAxis:%d FlipX:%d FlipY:%d\r\n",
                    setProposal.swapAxes,
                    setProposal.invertXaxis,
                    setProposal.invertYaxis);

        fclose(fp);
    }


    zul_inhibitFlashWrites(true);
    //FTM handled when leaving state FirstTouchMeasureB

    if (setProposal.pseudoUpperThr < 99)
    {
        int axesOption = ZXY100_FLEXI_LEFT;

        SET_CONFIG_PARAM(ZXY100_CI_LOWER_THRESHOLD, setProposal.pseudoUpperThr - zxy100Data->DeBounce);
        SET_CONFIG_PARAM(ZXY100_CI_UPPER_THRESHOLD, setProposal.pseudoUpperThr);

        if (setProposal.swapAxes)
        {
            axesOption ++;
        }
        SET_CONFIG_PARAM(ZXY100_CI_FLEXI_POSITION, axesOption);

        SET_CONFIG_PARAM( ZXY100_CI_FLIP_X, setProposal.invertXaxis );
        SET_CONFIG_PARAM( ZXY100_CI_FLIP_Y, setProposal.invertYaxis );
    }
    else
    {
        basicSetupLog->Write2LogF("%s ERROR", __FUNCTION__ );
    }

    zul_inhibitFlashWrites(false);

    ZytAPIResult::ResultState r = ZytAPIResult::Success;

    emit APIResult(r);
}


/**
 */
void SetupSensDialog_100::getNextState(void)
{
    if (DebugText>1) basicSetupLog->Write2LogF(__FUNCTION__);


    if (state.panelState == NotifyChgSens100)
    {
        state.panelState = EqualizeSensor;
        return;
    }

    if (state.panelState == ReleaseTouch)
    {
        if (state.touchSeqLoc < NUM_TSEQ_POINTS)
        {
            state.panelState = GetTouch;
        }
        else
        {
            haltRawData();
            processData();
            state.panelState = Finished;
        }
    }
    else
    {
        if (state.panelState != RestoreSettings)
        {
            // Normal progression
            state.panelState = (PanelState)(1+state.panelState);
        }
    }


    if (state.panelState == GetNoiseProfile)
    {
        // fake the noise reading
        noiseMax = 10;

        // prepare the touch pseudo level
        setProposal.pseudoUpperThr = zxy100Data->BS_InitialThreshold;
        basicSetupLog->Write2LogF("NoiseSample Max: %d => PseudoThreshold = %d",
                                                    noiseMax, setProposal.pseudoUpperThr);

        // move on
        state.panelState = (PanelState)(1+state.panelState);
    }

    if (state.panelState == FirstTouchMeasureW)
        state.panelState = EqualizeSensor;
}

/**
 */
int SetupSensDialog_100::getStateTO(void)
{
    int retVal = 1;
    switch (state.panelState)
    {
        case EqualizeSensor:
        case RestoreDefaults:
            retVal = 2 * TICKS_PER_SECOND;
            break;

        case Confirm:
        case NotifyChgSens100:
            retVal = 1 * TICKS_PER_SECOND;
            break;

        case GetTouch:
            retVal = TICKS_PER_SECOND / 2;
            break;

        case Failed_NoTouch:
            retVal = TOUCH_ON_WAIT * TICKS_PER_SECOND;
            break;

        case ReleaseTouch:
        case Failed_NoRelease:
            retVal = TOUCH_OFF_WAIT * TICKS_PER_SECOND;
            break;

        case Finished:
            retVal = DONE_WAIT * TICKS_PER_SECOND;
            break;

        case ChangeSens100:
        default:
            retVal = 3 * TICKS_PER_SECOND;
    }
    return retVal;
}

/**
 * when a state's period is completed, just before the transition into a new
 * state, data may need to be taken from the touch controller. These fuctions
 * know what data to take at these moments for the connected controller.
 *
 * If the return value is 1, then the changeState function that called here
 * should return with no further processing !
 */
int SetupSensDialog_100::storeStateData(void)
{
    switch (state.panelState)
    {
        case Finished:
            zxy100Data->enableRawDataCapture(false);
            return 1;
            break;  // redundant

        case GetTouch:

            // with 20 ticks per seconds, touchStateCount increases twice a second
            state.touchStateCount++;

            basicSetupLog->Write2LogF(" --- %s [%d]\t\t-- Z1_TSC:%d",
                    getStateCStr(), state.panelState, state.touchStateCount);

            {
                int minOfMaxs = zxy100Data->getRawDataMinOfMaxs();
                state.timeout = getStateTO();

                if (minOfMaxs < zxy100Data->MIN_LOWER_THR_SETTING)
                {
                    // After 7 seconds, give up on this glass thickness (or coarse sensitivity)
                    // User may not have touched sensor within time-limit
                    if (state.touchStateCount/2 >= 7 )
                    {
                        setProposal.glassThickness++;
                        if (setProposal.glassThickness > ZXY100_GLASS_EXTRA_THICK)
                        {
                            state.panelState = Failed_NoTouch;
                            state.timeout = 3 * TICKS_PER_SECOND;
                        }
                        else
                        {
                            state.panelState = ChangeSens100;  //Restart with a new glass thickness.
                        }
                    }
                }
                else
                {
                    if (state.touchStateCount/2 >= 3)   // after 3 seconds
                    {
                        //if ((touchData.wasPseudoTouched == true) && (touchData.isPseudoTouched == true))
                        //{
                        //    // threshold is valid for this touch
                        //    eState = States.RELEASE_TOUCH;
                        //    state.touchStateCount = 0;
                        //}

                        if ((touchData.wasPseudoTouched != true))
                        {
                            // accelerator for large separation
                            if ( ( (setProposal.pseudoUpperThr - zxy100Data->DeBounce) > minOfMaxs) &&
                                 ( minOfMaxs > zxy100Data->MIN_LOWER_THR_SETTING )
                               )
                            {
                                setProposal.pseudoUpperThr = minOfMaxs; // - THRESHOLD_ADJUSTMENT);
                                state.touchStateCount = 1;
                                touchData.numBelowThresh = 0;
                                basicSetupLog->Write2LogF(" NEW PROPOSED UT %d", setProposal.pseudoUpperThr);
                            }
                        }
                    }

                    if (state.touchStateCount/2 >= 1)   // after 1 second
                    {
                        if ((touchData.wasPseudoTouched == true) && (touchData.isPseudoTouched == false))
                        {
                            setProposal.pseudoUpperThr -= zxy100Data->BS_ThresholdAdjustment;
                            touchData.numBelowThresh = 0;
                            if ( ( setProposal.pseudoUpperThr - zxy100Data->DeBounce ) < zxy100Data->MIN_LOWER_THR_SETTING)
                            {
                                setProposal.glassThickness++;

                                if (setProposal.glassThickness > ZXY100_GLASS_EXTRA_THICK)
                                {
                                    state.panelState = Failed_NoTouch;
                                    state.timeout = 3 * TICKS_PER_SECOND;
                                }
                                else
                                {
                                    state.panelState = ChangeSens100;  //Restart with a new glass thickness.
                                }
                            }
                        }
                    }
                }
            }

            // Ok - we have data for a good touch - store the touch parameters for this target.
            if (touchData.wasTouchedCounter > REQD_ON_SAMPLES)
            {
                processPseudoTouch();
            } else {
                return 1;
            }

            break;

        case ReleaseTouch:
            state.touchStateCount = 0;

            if (touchData.numBelowThresh < REQD_OFF_SAMPLES)
            {
                state.panelState = Failed_NoRelease;
                state.timeout = 3 * TICKS_PER_SECOND;
                update();
                return 1;   // try again, or fail
            }

            break;

        case RestoreSettings:
        case LastState:
            reject();
            break;

        // valid states which have no data collection duties

        case SaveSettings:
        case RestoreDefaults:
        case EqualizeSensor:
        case Confirm:
        //case Failed_NoTouch:
        //case Failed_NoRelease:
        //case Failed_CommsError:
        //case Failed_Noise:
        case ChangeSens100:
        case NotifyChgSens100:
            break;

        default:
            basicSetupLog->Write2LogF(  "%s UNEXPECTED STATE [%d] %s ##### \n",
                                        __FUNCTION__, state.panelState, getStateCStr() );
    }
    return 0;
}

/**
 * when a state's period is starting, just after the transition into a new
 * state, actions may be taken on the local data stores, and the device.
 * These fuctions determine the actions required for the set of valid states.
 *
 * If the return value is 1, then the changeState function operation may be
 * altered. Value is TBD; this facility echos the return value provided (and
 * required) by pf_storeStateData();
 */
void SetupSensDialog_100::prepNewState(void)
{
    switch (state.panelState)
    {
        case RestoreDefaults:
            GET_CONFIG_PARAM( ZXY100_CI_DEVICE_MODE, zxy110initState.zxy100DevMode );
            setProposal.touchCountLimit = 1;
            if (zxy110initState.zxy100DevMode > 1)
            {
                setProposal.touchCountLimit = zxy110initState.zxy100DevMode;
            }

            partialRestoreFactorySettings();

            SET_CONFIG_PARAM( ZXY100_CI_COARSE_SENSITIVITY, setProposal.glassThickness );
            touchData.numAboveThresh = 0;
            touchData.numBelowThresh = 0;
            break;
            // [[gnu::fallthrough]];


        case NotifyChgSens100:
            state.touchSeqLoc = 0;
            state.currentPointIndex = TouchSequence[state.touchSeqLoc];
            break;

        case EqualizeSensor:
            // turn off touch events for this process
            setProposal.pseudoUpperThr = zxy100Data->BS_InitialThreshold;

            zul_inhibitFlashWrites(true);
            SET_CONFIG_PARAM(ZXY100_CI_COARSE_SENSITIVITY, setProposal.glassThickness);
            SET_CONFIG_PARAM(ZXY100_CI_UPPER_THRESHOLD, 100);
            SET_CONFIG_PARAM(ZXY100_CI_LOWER_THRESHOLD, 99);
            zul_inhibitFlashWrites(false);

            // turn OFF the dynamic equalizer
            SET_CONFIG_PARAM(ZXY100_CI_TEMP_COMPENSATION_STATE, 0);  //DYNAMIC_EQ off

            touchData.numAboveThresh = 0;
            touchData.numBelowThresh = 0;
            zul_forceEqualisation();
            wipeTouchSamples();
            state.touchStateCount = 0;
            break;

        case GetTouch:
            state.touchSeqLoc++;
            wipeTouchSamples();
            zxy100Data->enableRawDataCapture(true);
            break;

        case ReleaseTouch:
            wipeTouchSamples();
            touchData.numAboveThresh = 0;
            touchData.numBelowThresh = 0;
            break;

        case Confirm:
            // NOT USED !!
            break;

        case Finished:
            applySettings();
            zul_forceEqualisation();
            break;

        case Failed_NoTouch:
        case Failed_NoRelease:
        case Failed_CommsError:
        case Failed_Noise:
        case LastState:
            // halt state progression
            basicSetupLog->Write2LogF("BS TickStop");
            fastTick->stop();
            break;

        default:
            basicSetupLog->Write2LogF(  "%s UNEXPECTED STATE [%d] %s ##### \n",
                                        __FUNCTION__, state.panelState, getStateCStr() );
    }
    update();
}



/**
 * The ZXY110 is one odd controller:
 */
void SetupSensDialog_100::changeStateWhenRestoreDone(void)
{
    // nothing to do for any zxy100 device
    // restore defaults is almost immediate
}


/**
 *
 */
int SetupSensDialog_100::getSignalLevel(void)
{
    zxy100Data->getNewRawData();

    return zxy100Data->getRawDataMinOfMaxs();
}
void SetupSensDialog_100::getSignalLocation(uint16_t *tp_x, uint16_t *tp_y)
{
    *tp_x = zxy100Data->getXIndexforRawMax();
    *tp_y = zxy100Data->getYIndexforRawMax();
}

/**
 */
void SetupSensDialog_100::haltRawData()
{
    if (zxy100Data) zxy100Data->enableRawDataCapture(false);
}

/**
 * long running process fired by timer -- ZXY110 specific
 * this activity is processed in a isolated thread - so GUI continues as it should
 *
void SetupSensDialog_100::zxy110RestoreDefault()
{
    // do nothing
} */

/**
 * protect a MaxTouches setting when users run "Basic Config"
 */
void SetupSensDialog_100::partialRestoreFactorySettings()
{
    basicSetupLog->Write2Log( __FUNCTION__ );

    zul_restoreDefaults();
    basicSetupLog->Write2LogF( "FactoryReset: ZXY100 DeviceMode preserved at %d",
                   zxy110initState.zxy100DevMode );
    SET_CONFIG_PARAM( ZXY100_CI_DEVICE_MODE, zxy110initState.zxy100DevMode );
}

bool SetupSensDialog_100::errorEventsOccurred(void) { return false; }
