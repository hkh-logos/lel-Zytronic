/*
 *      Basic Setup Process. Displays a number of points on the screen in order
 *      to evaluate touch sensitivity data and then write it to the controller.
 *      Also set the axes for the given sensor-display integration.
 *      Also, set the noise handling parameters.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


/*
  SetupSensDialog_MT

    16/1/2019 : ZXY150, ZXY200, ZXY300, ZXY500.

    This class is designed to guide a user through a process which determines
    a reasonable set of values for the following
    - the sensitivity setting
    - the sensor orientation:
            - axes swapped, or normal
            - axis flipped, or normal

    - the Palm Detection Threshold setting

    - the First Touch Mode settings

    Users need not learn about these settings, only follow the on-screen guidance

    The whole process is driven by the periodic tick() operation, located in the base class

    NB: This does not complete a calibration!

    --------------------

    Basic Call Tree (see BASE class):

        exec()
            initData()
            start fastTick to call tick() -- see 'TICKS_PER_SECOND'
            QDialog::exec()

        tick()
            conditionally sample data
            if (state.timeout passed) changeState()

        changeState()
            save data from controller at end of state period
            determine next state, and period (terminate on error, or completion)
            move to new state, and send prep commands to controller


    --------------------

    NB: separate the 'view' from the 'controller'!
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

#include "debug.h"
#include "logfile.h"
#include "Zxy100Data.h"
#include "SetupSensDialog_MT.h"

/**
 *  Cells only exist in the MT products {ZXY150, ZXY200, ZXY300..}
 */
const char * SetupSensDialog_MT::getCellTypeName(SetupSensDialog_MT::CellType c)
{
    static const char *names[] =
    {
        "Unset",  "7inch",  "10inch", "12inch", "15inch",
        "19inch", "22inch", "32inch", "46inch", "55inch",
        "65inch", "72inch", "84inch", "Error",  "Error",
    };

    if ((c > CT_ERROR) || (c<0))
    {
        c = CT_ERROR;
    }
    return names[c];
}



/**********************************************************
 *          Constructor
 *********************************************************/

SetupSensDialog_MT::SetupSensDialog_MT(QWidget *parent) : SetupSensDialog_BASE(parent)
{
    basicSetupLog->Write2Log("Basic Setup Created");
}


/**
 * module global initialisation
 */
bool SetupSensDialog_MT::initData2(void)
{
    mtValues.cellType = CT_NONE;
    basicSetupLog->Write2Log( "Basic Setup - ZXY-MT - RESTART" );

    // unit tests for panel
    if (DebugText>5) orientationTestFunc();

    return true;
}


/*
 * update the setProposal values, based on all data collected.
 * called from BASE class processData()
 */
void SetupSensDialog_MT::updateSetProposal(void)
{
    // set the global Touch Threshold Recommendation
    setProposal.pseudoUpperThr = getThreshEstimate_MT();
    basicSetupLog->Write2LogF("Estimated Upper Threshold : %d", setProposal.pseudoUpperThr );

    // set the global Palm Threshold Recommendation
    setProposal.palmThresh = getPalmThreshEstimate_MT(setProposal.pseudoUpperThr);

    int touchCountMaxForPalmRejection = 10;
    if ( zul_isZXY500AppPID(&devPID) )
    {
        int numWires = szSensor.xWires + szSensor.yWires;

        switch (numWires)
        {
            case 128:
                touchCountMaxForPalmRejection = 20;
                break;
            case 256:
                touchCountMaxForPalmRejection = 40;
                break;
        }
    }

    if (setProposal.touchCountLimit > touchCountMaxForPalmRejection)
    {
        setProposal.palmThresh = 0;
    }

    //decide on the Default Curve value
    setProposal.interpolatorBias = getInterpolatorBiasEstimate(setProposal.pseudoUpperThr);
}

/**
 * return the average of the X and Y max accumulated signal employed by
 * processPseudoTouch()
 */
int SetupSensDialog_MT::getPseudoTouchSignal(void)
{
    int retval =    touchData.xPressMax/touchData.numAtX[touchData.xLoc] +
                    touchData.yPressMax/touchData.numAtY[touchData.yLoc];
    return retval / 2;
}


/**
 * following processData() the controller is configured here
 */
void SetupSensDialog_MT::applySettings(void)
{
    basicSetupLog->Write2LogF("Write UThres:%03d PalmT:%03d - SwapAxis:%d FlipX:%d FlipY:%d",
                        setProposal.pseudoUpperThr, setProposal.palmThresh,
                        setProposal.swapAxes, setProposal.invertXaxis, setProposal.invertYaxis);

    FILE *fp = fopen("/tmp/ZyConfig-BasicSettings.txt", "w");
    if (fp != NULL)
    {
        fprintf(fp, "Glass Thickness: %1d  Upper Threshold:%03d Palm Rejection Threshold:%03d\r\n",
                    setProposal.glassThickness,
                    setProposal.pseudoUpperThr,
                    setProposal.palmThresh);
        fprintf(fp, "SwapAxis:%d FlipX:%d FlipY:%d\r\n",
                    setProposal.swapAxes,
                    setProposal.invertXaxis,
                    setProposal.invertYaxis);

        basicSetupLog->Write2LogF("MT : Write FTM OFF/ON: %d/%d.  IB:%d - CellType:%s",
                    setProposal.ftm_OffThreshold,
                    setProposal.ftm_OnThreshold,
                    setProposal.interpolatorBias,
                    getCellTypeName(mtValues.cellType) );

        fprintf(fp, "IB: %d  CellType:%s\r\n",
                    setProposal.interpolatorBias,
                    getCellTypeName(mtValues.cellType));
        fprintf(fp, "FTM OFF/ON: %d/%d\n",
                    setProposal.ftm_OffThreshold,
                    setProposal.ftm_OnThreshold );
        fclose(fp);
    }


    zul_inhibitFlashWrites(true);
    //FTM handled when leaving state FirstTouchMeasureB

    if ( zul_isZXY500AppPID(&devPID) )
    {
        SET_CONFIG_PARAM( ZXYMT_CI_RESAMPLE_THRESHOLD_MAX, 200 );
    }

    SET_CONFIG_PARAM( ZXYMT_CI_UPPER_THRESHOLD, setProposal.pseudoUpperThr );

    if (devPID == ZXY150_PRODUCT_ID)
    {
        if (mtValues.cellType == CT_15 || mtValues.cellType == CT_19 || mtValues.cellType == CT_22)
        {
            SET_CONFIG_PARAM( ZXYMT_CI_PALM_REJECT_FLOOD_RADIUS, 0 );
        }
    }

    // see touchCountMaxForPalmRejection above in processData() for ZXY500
    SET_CONFIG_PARAM( ZXYMT_CI_PALM_REJECT_WEIGHT_LIMIT, setProposal.palmThresh );
    SET_CONFIG_PARAM( ZXYMT_CI_INTERPOLATOR_BIAS, setProposal.interpolatorBias );
    SET_CONFIG_PARAM( ZXYMT_CI_SWAP_XY, setProposal.swapAxes );
    SET_CONFIG_PARAM( ZXYMT_CI_INVERT_X, setProposal.invertXaxis );
    SET_CONFIG_PARAM( ZXYMT_CI_INVERT_Y, setProposal.invertYaxis );

    zul_inhibitFlashWrites(false);

    emit APIResult(ZytAPIResult::Success);
}


/**
 */
void SetupSensDialog_MT::getNextState(void)
{
    if (DebugText>1) basicSetupLog->Write2LogF(__FUNCTION__);

    if (state.panelState == ReleaseTouch)
    {
        if (state.touchSeqLoc < NUM_TSEQ_POINTS)
        {
            state.panelState = GetTouch;
        }
        else
        {
            processData();
            state.panelState = Finished;
        }
    }
    else
    {
        if (state.panelState != RestoreSettings)
        {
            // Normal progression
            state.panelState = (PanelState)(1+state.panelState);
        }
    }

    // skip Noise Profiling - not currently used
    if (state.panelState == GetNoiseProfile)
    {
        // fake the noise reading and upper threshold
        noiseMax = 50;

        // prepare the touch pseudo level and report
        setProposal.pseudoUpperThr = noiseMax + 70;         // #### MAGIC !!!!
        setProposal.palmThresh = 0;
        basicSetupLog->Write2LogF("NoiseSample Max: %d => PseudoThreshold = %d",
                                        noiseMax, setProposal.pseudoUpperThr);

        mtValues.newThreshRetryCount = 0;

        // move on
        state.panelState = (PanelState)(1+state.panelState);
    }
}


/**
 */
int SetupSensDialog_MT::getStateTO(void)
{
    switch (state.panelState)
    {
        case EqualizeSensor:
            return TICKS_PER_SECOND;
            break;

        case RestoreDefaults:
            // The restore defaults service on the ZXY200 and ZXY300s devices
            // automatically  triggers an equalize ... so wait for that to complete ...
            switch (devPID)
            {
                default:
                    return 2 * TICKS_PER_SECOND;
                case ZXY300_PRODUCT_ID:
                    return 12 * TICKS_PER_SECOND;
                case ZXY500_PRODUCT_ID:
                case ZXY500_PRODUCT_ID_ALT1:
                    return 5 * TICKS_PER_SECOND;
            }
            break;

        case FirstTouchMeasureW:
        case FirstTouchMeasureB:
            return NOISE_WAIT * TICKS_PER_SECOND;
            break;

        case Confirm:
            return 1 * TICKS_PER_SECOND;
            break;

        case GetTouch:
        case Failed_NoTouch:
            return TOUCH_ON_WAIT * TICKS_PER_SECOND;
            break;

        case ReleaseTouch:
        case Failed_NoRelease:
            return TOUCH_OFF_WAIT * TICKS_PER_SECOND;
            break;

        case Finished:
            return DONE_WAIT * TICKS_PER_SECOND;
            break;

        default:
            return 3 * TICKS_PER_SECOND;
    }
}

/**
 * when a state's period is completed, just before the transition into a new
 * state, data may need to be taken from the touch controller. These fuctions
 * know what data to take at these moments for the connected controller.
 *
 * If the return value is 1, then the changeState function that called here
 * should return with no further processing !
 */
int SetupSensDialog_MT::storeStateData(void)
{
    switch (state.panelState)
    {
        case Finished:
            return 1;
            break;      // redundant

        case GetTouch:

            if (touchData.numAboveThresh < 10)     // setProposal.pseudoUpperThr too high
            {
                setProposal.pseudoUpperThr -= 10;     // #### MAGIC !!!!
                wipeTouchSamples();
                mtValues.newThreshRetryCount++;
                state.timeout = TOUCH_ON_WAIT * TICKS_PER_SECOND;

                // if at the end of the possibilities, break out
                if ((mtValues.newThreshRetryCount >= 10) || (setProposal.pseudoUpperThr <= noiseMax))
                {
                    state.panelState = Failed_NoTouch;
                    state.timeout = 3 * TICKS_PER_SECOND;
                }
                // do not processPseudoTouch this sample set
                return 1;     // try again, or fail
            }

            // Ok - we have data for a good touch - store the touch parameters for this target.
            processPseudoTouch();

            break;


        case ReleaseTouch:
            if (touchData.numBelowThresh < REQD_OFF_SAMPLES)
            {
                state.panelState = Failed_NoRelease;
                state.timeout = 3 * TICKS_PER_SECOND;
                update();
                return 1;     // try again, or fail
            }
            break;

        case FirstTouchMeasureW:

            // Get status values and default flash param values to decide if we need to increase
            // the first touch mode enter/exit threshold values
            mtValues.ftm_OffMetric = 0;
            GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, mtValues.ftm_OffMetric);
            if (mtValues.ftm_OffMetric > 300)      // kloodge for odd ZXY300 behaviour on the 84" TR11
            {
                zy_msleep(50);
                GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, mtValues.ftm_OffMetric);
                basicSetupLog->Write2LogF("\tWhite>>>>FTMOffMetric=%d", mtValues.ftm_OffMetric);
            }
            if (mtValues.ftm_OffMetric > 300)      // kloodge for odd ZXY300 behaviour on the 84" TR11
            {
                zy_msleep(50);
                GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, mtValues.ftm_OffMetric);
                basicSetupLog->Write2LogF("\tWhite>>>>FTMOffMetric=%d", mtValues.ftm_OffMetric);
            }
            if (mtValues.ftm_OffMetric > 300)      // kloodge for odd ZXY300 behaviour on the 84" TR11
            {
                zy_msleep(50);
                GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, mtValues.ftm_OffMetric);
                basicSetupLog->Write2LogF("\tWhite>>>>FTMOffMetric=%d", mtValues.ftm_OffMetric);
            }

            zy_msleep(50);      // debug delay
            GET_CONFIG_PARAM(ZXYMT_CI_FTM_ON_THRESHOLD, mtValues.ftm_OnThreshold);
            GET_CONFIG_PARAM(ZXYMT_CI_FTM_OFF_THRESHOLD, mtValues.ftm_OffThreshold);

            basicSetupLog->Write2LogF(
                    "\tWhite>>>>\tFTMOnThreshold = %d\t OffTh = %d\tFTMOffMetric=%d",
                    mtValues.ftm_OnThreshold, mtValues.ftm_OffThreshold,mtValues.ftm_OffMetric  );

            break;

        case FirstTouchMeasureB:

            // Get status values and default flash param values to decide if we need to increase
            // the first touch mode enter/exit threshold values
            mtValues.ftm_OffMetric2 = 0;
            GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, mtValues.ftm_OffMetric2);

            if (mtValues.ftm_OffMetric2 > 300)      // kloodge for odd ZXY300 behaviour on the 84" TR11
            {
                zy_msleep(50);
                GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, mtValues.ftm_OffMetric2);
                basicSetupLog->Write2LogF("\tWhite>>>>FTMOffMetric=%d", mtValues.ftm_OffMetric2);
            }
            if (mtValues.ftm_OffMetric2 > 300)      // kloodge for odd ZXY300 behaviour on the 84" TR11
            {
                zy_msleep(50);
                GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, mtValues.ftm_OffMetric2);
                basicSetupLog->Write2LogF("\tWhite>>>>FTMOffMetric=%d", mtValues.ftm_OffMetric2);
            }
            if (mtValues.ftm_OffMetric2 > 300)      // kloodge for odd ZXY300 behaviour on the 84" TR11
            {
                zy_msleep(50);
                GET_STATUS_VAL(ZXYMT_SI_MEAN_ABS_DIFF_SAMPLE_REPEATS, mtValues.ftm_OffMetric2);
                basicSetupLog->Write2LogF("\tWhite>>>>FTMOffMetric=%d", mtValues.ftm_OffMetric2);
            }


            basicSetupLog->Write2LogF(
                    "\tBlack>>>>\tFTMOnThreshold = %d\t OffTh = %d\tFTMOffMetric=%d",
                    mtValues.ftm_OnThreshold, mtValues.ftm_OffThreshold, mtValues.ftm_OffMetric2 );


            if (mtValues.ftm_OffMetric2 > mtValues.ftm_OffMetric)
                mtValues.ftm_OffMetric = mtValues.ftm_OffMetric2;

            // also read max value of firstTouchModeOn metric
            GET_STATUS_VAL(ZXYMT_SI_NUM_ZEROS_WARNING_MAX, mtValues.ftm_OnMetricMaxValue);

            basicSetupLog->Write2LogF("\tBlack>>>>\tFTMOnMetrixMaxVal = %d",
                                            mtValues.ftm_OnMetricMaxValue );

            // put FTM mode back to its original setting
            SET_CONFIG_PARAM(ZXYMT_CI_FTM_SELECTION, mtValues.ftm_Mode);

            // Compute a safe value for FIRST_TOUCH_MODE_ON_THRESHOLD
            setProposal.ftm_OnThreshold = (uint16_t) ( mtValues.ftm_OnMetricMaxValue + ftm_OnThresholdSafetyMargin );

            //if the newly computed value is safer than the default value (less likely to cause trouble) then use it
            if (setProposal.ftm_OnThreshold > mtValues.ftm_OnThreshold)
            {
                SET_CONFIG_PARAM(ZXYMT_CI_FTM_ON_THRESHOLD, setProposal.ftm_OnThreshold);
            }
            else
            {
                setProposal.ftm_OnThreshold = mtValues.ftm_OnThreshold;
            }

            if ( !zul_optionAvailable (ZXYMT_OPT_BIT_FTM_ON_PERSIST) )
            {
                //Compute a safe value for FIRST_TOUCH_MODE_OFF_THRESHOLD
                setProposal.ftm_OffThreshold = (uint16_t)((float)mtValues.ftm_OffMetric * ftm_OffThresholdSafetyMargin);

                // if the newly computed value is safer than the default value (less likely to
                // cause trouble) then use it
                if (setProposal.ftm_OffThreshold > mtValues.ftm_OffThreshold)
                {
                    SET_CONFIG_PARAM(ZXYMT_CI_FTM_OFF_THRESHOLD, setProposal.ftm_OffThreshold);
                }
                else
                {
                    setProposal.ftm_OffThreshold = mtValues.ftm_OffThreshold;
                }
            }
            else
            {
                basicSetupLog->Write2LogF("ZXYMT_OPT_BIT_FTM_ON_PERSIST" );
            }
            if ( zul_isZXY500AppPID(&devPID) )
            {
                SET_CONFIG_PARAM(ZXYMT_CI_RESAMPLE_THRESHOLD_MAX, 50 );
            }

            basicSetupLog->Write2LogF(
                    "FTMOffThreshold = %d,  FTMOffMetric = %d\tNewThresholdOff:%d",
                        mtValues.ftm_OffThreshold,mtValues.ftm_OffMetric,setProposal.ftm_OffThreshold    );
            basicSetupLog->Write2LogF(
                    "FTMOnThreshold = %d,  FTMOnMetricMaxVal = %d\tNewThresholdOn:%d",
                        mtValues.ftm_OnThreshold,mtValues.ftm_OnMetricMaxValue,setProposal.ftm_OnThreshold  );

            // when leaving the equalization state, clear the MAX/MIN values
            // internal to the controller by a read
            uint16_t tp1;
            GET_STATUS_VAL( ZXYMT_SI_CURR_SIG_MAX, tp1);
            GET_STATUS_VAL( ZXYMT_SI_CURR_SIG_MIN, tp1);

            // ... and make the cellSize/mtValues.cellType assessment
            getCellType();

            break;

        case RestoreSettings:
        case LastState:
            reject();
            break;

        // valid states which have no data collection duties

        case SaveSettings:
        case RestoreDefaults:
        case EqualizeSensor:
        case Confirm:
        //case Failed_NoTouch:
        //case Failed_NoRelease:
        //case Failed_CommsError:
        //case Failed_Noise:
        //case ChangeSens100:
        //case NotifyChgSens100:
            break;


        default:
            basicSetupLog->Write2LogF(  "%s UNEXPECTED STATE [%d] %s ##### \n",
                                        __FUNCTION__, state.panelState, getStateCStr() );
    }
    return 0;
}

/**
 * when a state's period is starting, just after the transition into a new
 * state, actions may be taken on the local data stores, and the device.
 * These fuctions determine the actions required for the set of valid states.
 *
 * If the return value is 1, then the changeState function operation may be
 * altered. Value is TBD; this facility echos the return value provided (and
 * required) by storeStateData();
 */
void SetupSensDialog_MT::prepNewState(void)
{
    switch (state.panelState)
    {
        case RestoreDefaults:
            GET_CONFIG_PARAM(ZXYMT_CI_MAX_TOUCHES, setProposal.touchCountLimit);
            setProposal.ftm_OnThreshold = 0;
            setProposal.ftm_OffThreshold = 0;
            partialRestoreFactorySettings();

            GET_CONFIG_PARAM(ZXYMT_CI_FTM_SELECTION, mtValues.ftm_Mode);   // remember the users setting

            /* set the controller into First Touch Mode for a moment to give it a chance
             * to measure STATUS_ID_MEAN_ABS_DIFF_SAMPLE_REPEATS
             * (this is only measured when in First Touch Mode) */

            //DisableFlashWrite();
            SET_CONFIG_PARAM(ZXYMT_CI_FTM_SELECTION, 1);   // 1 = ON
            //EnableFlashWrite();

            // wait a moment for it to go into first touch mode
            break;

        case FirstTouchMeasureW:
            SET_CONFIG_PARAM( ZXYMT_CI_UPPER_THRESHOLD, 999 );
            break;

        case EqualizeSensor:
            // turn off touch events for this process
            SET_CONFIG_PARAM( ZXYMT_CI_UPPER_THRESHOLD, 999 );

            wipeTouchSamples();
            state.touchStateCount = 0;
            // zul_forceEqualization(); -- MT devices do this as part of restore factory defaults
            break;

        case GetTouch:
            state.touchSeqLoc++;
            wipeTouchSamples();
            break;

        case ReleaseTouch:
            wipeTouchSamples();
            touchData.numAboveThresh = 0;
            touchData.numBelowThresh = 0;
            break;

        case Confirm:
            processData();
            break;

        case Finished:
            applySettings();
            break;

        case Failed_NoTouch:
        case Failed_NoRelease:
        case Failed_CommsError:
        case Failed_Noise:
        case LastState:
            // halt state progression
            basicSetupLog->Write2LogF("BS TickStop");
            fastTick->stop();
            break;

        default:
            basicSetupLog->Write2LogF(  "%s UNEXPECTED STATE [%d] %s ##### \n",
                                        __FUNCTION__, state.panelState, getStateCStr() );
    }
}


/**
 * this is ONLY needed for ZXY110 !!
 */
void SetupSensDialog_MT::changeStateWhenRestoreDone(void)
{
    // nothing to do for any MT device
    // restore defaults is almost immediate
}

/**
 *
 */
int SetupSensDialog_MT::getSignalLevel(void)
{
    uint16_t tpMin;
    zul_getStatusByID( ZXYMT_SI_CURR_SIG_MIN, &tpMin); // too verbose for logging macro
    return tpMin;
}
void SetupSensDialog_MT::getSignalLocation(uint16_t *tp_x, uint16_t *tp_y)
{
    uint16_t x, y;

    zul_getStatusByID( ZXYMT_SI_CURR_SIG_X, &x); // too verbose for logging macro
    zul_getStatusByID( ZXYMT_SI_CURR_SIG_Y, &y);

    // move from co-ordinate space to cell index
    *tp_x = x / (4096/szSensor.xWires);
    *tp_y = y / (4096/szSensor.yWires);
}

/**
 */
void SetupSensDialog_MT::haltRawData()
{
    // MT devices do not use rawdata mode
}


/**
 * protect several CONFIG items when users run "Basic Config"
 */
void SetupSensDialog_MT::partialRestoreFactorySettings()
{
    basicSetupLog->Write2Log( __FUNCTION__ );

    zul_restoreDefaults();

    if (setProposal.touchCountLimit > 0)
    {
        basicSetupLog->Write2LogF( "FactoryReset: MaxTouches preserved at %d",
                       setProposal.touchCountLimit );
        SET_CONFIG_PARAM(ZXYMT_CI_MAX_TOUCHES, setProposal.touchCountLimit);
    }

    if (setProposal.ftm_OnThreshold>0)
    {
        SET_CONFIG_PARAM(ZXYMT_CI_FTM_ON_THRESHOLD, setProposal.ftm_OnThreshold);
    }

    if (setProposal.ftm_OffThreshold>0)
    {
        SET_CONFIG_PARAM(ZXYMT_CI_FTM_OFF_THRESHOLD, setProposal.ftm_OffThreshold);
    }
}


/**
 */
SetupSensDialog_MT::CellType SetupSensDialog_MT::getCellType150(void)
{
    uint16_t first, last;
    uint16_t numWires_X, numWires_Y;

    GET_STATUS_VAL(ZXYMT_SI_CONNECTED_WIRE_X_FIRST, first);
    GET_STATUS_VAL(ZXYMT_SI_CONNECTED_WIRE_X_LAST, last);
    numWires_X = last - first + 1;

    GET_STATUS_VAL(ZXYMT_SI_CONNECTED_WIRE_Y_FIRST, first);
    GET_STATUS_VAL(ZXYMT_SI_CONNECTED_WIRE_Y_LAST, last);
    numWires_Y = last - first + 1;

    CellType cellSize;

    if ( numWires_Y < 24 )
    {
        // 2015-10-28 SMO,PAR: Decided that any sensor with less than 24 Rx
        //    wires should use the 7" settings as best logic we have for now.
        cellSize = CT_7;
    }
    else
    {
        switch ( numWires_X )
        {
            case 32:
                cellSize = CT_12;
                break;

            case 30:
                cellSize = CT_19;
                break;

            case 39:
                cellSize = CT_22;
                break;

            default:
                cellSize = CT_19;
                break;
        }
    }

    uint16_t shieldWirePosition;
    GET_STATUS_VAL(ZXYMT_SI_SHIELD_WIRE, shieldWirePosition);
    if ( shieldWirePosition == 0 )
    {
        cellSize = CT_19;
    }
    return cellSize;
}

/**
 */
SetupSensDialog_MT::CellType SetupSensDialog_MT::getCellType200(void)
{
    uint16_t reading;
    GET_STATUS_VAL( ZXYMT_SI_AVG_SIG_LEVEL, reading);
    if ( reading > 1740 )
    {
        return CT_55;
    }
    if ( reading > 1590 )
    {
        return CT_46;
    }
    if ( reading > 1270 )
    {
        return CT_32;
    }

    return CT_22;
}

/**
 */
SetupSensDialog_MT::CellType SetupSensDialog_MT::getCellType300(void)
{
    uint16_t reading;
    GET_STATUS_VAL( ZXYMT_SI_AVG_SIG_LEVEL, reading);

    if ( reading > 1170 )
    {
        return CT_84;
    }
    if ( reading > 1080 )
    {
        return CT_72;
    }
    if ( reading > 1010 )
    {
        return CT_65;
    }

    return CT_55;
}

/**
 */
SetupSensDialog_MT::CellType SetupSensDialog_MT::getCellType(void)
{
    switch (devPID)
    {
        case ZXY150_PRODUCT_ID:
            mtValues.cellType = getCellType150();
            break;
        case ZXY200_PRODUCT_ID:
            mtValues.cellType = getCellType200();
            break;
        case ZXY300_PRODUCT_ID:
            mtValues.cellType = getCellType300();
            break;
        case ZXY500_PRODUCT_ID:
        case ZXY500_PRODUCT_ID_ALT1:
            // This value is not used in the ZXY500 basic-setup palm threshold computation.
            // Intended fall-through
        default:
            mtValues.cellType = CT_NONE;
    }
    basicSetupLog->Write2LogF("CELLTYPE: %d  <---------- ", mtValues.cellType );
    return mtValues.cellType;
}


/**
 * PAR conducted usability tests to generate a Preferred Upper Touch Threshold
 * table. CFM characterised the operation of this measurement process and the
 * formula below converts from the measurement to the preferred value
 */
int SetupSensDialog_MT::getThreshEstimate_MT(void)
{
    int estimate = state.touchMinimum * 62 / 100;

    // clip following PAR's measurements
    if (estimate > 300) estimate = 300;

    if (mtValues.cellType == CT_22)
    {
        if (estimate < 50) estimate = 50;
    }
    else
    {
        if (estimate < 75) estimate = 75;
    }

    return estimate;
}

/**
 */
uint16_t SetupSensDialog_MT::getZXY150InterpolatorBiasEstimate(int touchUpperThreshold)
{
    uint16_t result = 50;

    //If touchUpperThreshold > 120 then we ASSUME that glass is 3mm thick
    if ( touchUpperThreshold > 120 )
    {
        switch (mtValues.cellType)
        {
            case CT_10:
            case CT_12:
            case CT_15:
                result = 45;
                break;

            case CT_19:
            case CT_22:
            case CT_32:
                result = 40;
                break;

            default:
                break;
        }
    }

    return ( result );
}

/**
 */
uint16_t SetupSensDialog_MT::getInterpolatorBiasEstimate(int touchUpperThreshold)
{
    uint16_t result;
    GET_CONFIG_PARAM(ZXYMT_CI_INTERPOLATOR_BIAS, result);

    switch (devPID)
    {
        case ZXY150_PRODUCT_ID:
            result = getZXY150InterpolatorBiasEstimate(touchUpperThreshold);
            break;

        default:
            break;
    }

    return ( result );
}

/**
 */
int SetupSensDialog_MT::getZXY150PalmThreshEstimate(int touchUpperThreshold)
{
    //   Thresholds          50-75, 75-100, 100-125, 125-150, 150-175, 175-200, 200-225, 225-250, 250-275, 275-300};
    uint16_t  PA_7inch[] = {     0,    300,     270,     240,     210,     210,     180,     180,     170,     170};
    uint16_t PA_10inch[] = {     0,    290,     220,     200,     180,     180,     170,     170,     160,     160};
    uint16_t PA_12inch[] = {     0,    280,     200,     180,     170,     170,     160,     160,     150,     150};
    uint16_t PA_15inch[] = {     0,      0,     200,     200,     175,     175,     125,     125,      85,      85};
    uint16_t PA_19inch[] = {     0,      0,     150,     150,     125,     125,      75,      75,      50,      50};
    uint16_t PA_22inch[] = {     0,      0,     150,     150,     125,     125,      75,      75,      50,      50};
    uint16_t PA_32inch[] = {   160,    130,     110,     100,     100,     100,      90,      90,      90,      90};

    uint16_t result = 0;

    int index = touchUpperThreshold/25-2;
    if (index<0)
    {
        index = 0;
    }
    if (index>9)
    {
        index = 9;
    }

    switch (mtValues.cellType)
    {
        case CT_7:
            result = PA_7inch[index];
            break;

        case CT_10:
            result = PA_10inch[index];
            break;

        case CT_12:
            result = PA_12inch[index];
            break;

        case CT_15:
            result = PA_15inch[index];
            break;

        case CT_19:
            result = PA_19inch[index];
            break;

        case CT_22:
            result = PA_22inch[index];
            break;

        case CT_32:
            result = PA_32inch[index];
            break;

        default:
            break;
    }

    return ( result );
}

/**
 * PAR conducted usability tests to generate a Preferred Palm Threshold table
 * contained below.  The formula in the function reads the table (based on
 * measured cell size/type and UpperTouchThreshold) to determine the preferred
 * Palm detection threshold.
 */
int SetupSensDialog_MT::getZXY200PalmThreshEstimate(int touchUpperThreshold)
{
    int PA22inch []   = {375,285,255,205,180,180,135,135,130,130};
    int PA32inch []   = {315,280,245,225,190,190,155,155,125,125};
    int PA46inch []   = {225,210,185,155,150,150,130,130,125,125};
    int PA55inch []   = {200,160,150,120,100,100, 90, 90, 85, 85};

    int estimate = touchUpperThreshold/25-2;
    if (estimate<0) estimate = 0;
    if (estimate>9) estimate = 9;

    switch (mtValues.cellType)
    {
        case CT_22:     return PA22inch[estimate];
        case CT_32:     return PA32inch[estimate];
        case CT_46:     return PA46inch[estimate];
        case CT_55:     return PA55inch[estimate];
        case CT_NONE:
        default:        return 300;   // fail safe
    }
}

/**
 */
int SetupSensDialog_MT::getZXY300PalmThreshEstimate(int touchUpperThreshold)
{
    int PA55inch []   = { 460, 410, 310, 280, 220, 220, 180, 180, 145, 145 };
    int PA65inch []   = { 315, 280, 245, 225, 190, 190, 155, 155, 125, 125 };
    int PA72inch []   = { 300, 240, 210, 155, 145, 145, 105, 105, 95,  95 };
    int PA84inch []   = { 240, 195, 180, 155, 145, 145, 105, 105, 90,  90 };

    int estimate = touchUpperThreshold/25-2;
    if (estimate<0) estimate = 0;
    if (estimate>9) estimate = 9;

    switch (mtValues.cellType)
    {
        case CT_55:     return PA55inch[estimate];
        case CT_65:     return PA65inch[estimate];
        case CT_72:     return PA72inch[estimate];
        case CT_84:     return PA84inch[estimate];
        case CT_NONE:
        default:        return 300;   // fail safe
    }
}

/**
 */
#define NUM_PRWL_DATA (8)
int SetupSensDialog_MT::get_prwlSmallCells500(int wires, int utVal)
{
    uint16_t UT        [NUM_PRWL_DATA] = {  50,  75, 100, 125, 150, 200, 250, 300 };
    // -----------------------------------------------------------------------------
    uint16_t PA_10inch [NUM_PRWL_DATA] = { 325, 250, 250, 225, 125, 125, 100, 100 };
    uint16_t PA_22inch [NUM_PRWL_DATA] = { 400, 350, 250, 175, 175, 150, 125, 125 };
    uint16_t PA_55inch [NUM_PRWL_DATA] = { 250, 150, 150, 150, 125,  75,  50,  50 };
    uint16_t *cellData;

    switch (wires)
    {
        default:
        case 64:
            cellData = PA_10inch;
            break;
        case 128:
            cellData = PA_22inch;
            break;
        case 256:
            cellData = PA_55inch;
            break;
    }

    int i = NUM_PRWL_DATA - 1;
    while (i > 0)
    {
        if (UT[i] > utVal)
        {
            i--;
        }
        else
        {
            return cellData[i];
        }
    }

    return cellData[0];
}

/**
 */
int SetupSensDialog_MT::get_prwlLargeCells500(int wires, int utVal)
{
    uint16_t UT       [] = {  50,  75, 100, 125, 150, 200, 250, 300 };
    // ---------------------------------------------------------------
    uint16_t PA_22inch[] = { 225, 175, 150, 125,  75,  50,  25,  25 };
    uint16_t PA_55inch[] = { 150, 125, 125,  75,  75,  50,  25,  25 };
    uint16_t PA_84inch[] = { 125, 125, 100, 100,  75,  50,  25,  25 };
    uint16_t *cellData;

    switch (wires)
    {
        default:
        case 64:
            cellData = PA_22inch;
            break;
        case 128:
            cellData = PA_55inch;
            break;
        case 256:
            cellData = PA_84inch;
            break;
    }

    int i = NUM_PRWL_DATA - 1;
    while (i > 0)
    {
        if (UT[i] > utVal)
        {
            i--;
        }
        else
        {
            return cellData[i];
        }
    }

    return cellData[0];
}


/**
 */
int SetupSensDialog_MT::getZXY500PalmThreshEstimate(int touchUpperThreshold)
{
    uint16_t asl;
    int asl_small, asl_large;
    int Wires = szSensor.xWires + szSensor.yWires;

    switch (Wires)
    {
        default:
        case 64:
            asl_small = 234;
            asl_large = 360;
            break;
        case 128:
            asl_small = 216;
            asl_large = 325;
            break;
        case 256:
            asl_small = 193;
            asl_large = 264;
            break;
    }

    GET_STATUS_VAL(ZXYMT_SI_AVG_SIG_LEVEL, asl);
    float sizeRatio = ((float)asl - asl_small) / (asl_large - asl_small);

    int prwlSmall = get_prwlSmallCells500(Wires, touchUpperThreshold);
    int prwlLarge = get_prwlLargeCells500(Wires, touchUpperThreshold);

    return (uint16_t) (prwlSmall + (float)(prwlLarge - prwlSmall) * sizeRatio);
}


/**
 */
int SetupSensDialog_MT::getPalmThreshEstimate_MT(int touchUpperThreshold)
{
    int pte;
    switch (devPID)
    {
        case ZXY150_PRODUCT_ID:
            pte = getZXY150PalmThreshEstimate(touchUpperThreshold);
            break;
        case ZXY200_PRODUCT_ID:
            pte = getZXY200PalmThreshEstimate(touchUpperThreshold);
            break;
        case ZXY300_PRODUCT_ID:
            pte = getZXY300PalmThreshEstimate(touchUpperThreshold);
            break;
        case ZXY500_PRODUCT_ID:
        case ZXY500_PRODUCT_ID_ALT1:
            pte = getZXY500PalmThreshEstimate(touchUpperThreshold);
            break;
        default:
            pte = 0;    // failsafe (palm detection is off)
    }

    return pte;
}

bool SetupSensDialog_MT::errorEventsOccurred(void) { return false; }
