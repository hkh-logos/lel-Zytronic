/*
 *      Widget to display a text string of the wirelevels from the controller as collected
 *      when the controller is in raw mode.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef WIRELEVELXLABELS_H
#define WIRELEVELXLABELS_H

#include <QWidget>
#include <QtWidgets>

#define MAX_WIRELEVEL	(255)
#define MIN_WIRELEVEL	(0)

class WireLevelXLabels : public QFrame
{
    Q_OBJECT

public:
    WireLevelXLabels(QWidget *parent = 0);
    void setWireLevels(const QVector<int> xWires);

protected:
    void paintEvent(QPaintEvent *event);

private:
    QWidget *m_parent;
    int findLinePosition(const int index, const float spacing);
    float findSpacing(const QVector<int> wires);
    void drawTextCentered(QPainter *painter, int x, int y, const QString &text);

    QVector<int> xWires;
};

#endif
