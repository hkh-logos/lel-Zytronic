/*
 *      Margin Selection Widget. Select the margins for custom calibration.
 */

/*
 * Copyright 2019 Zytronic Displays Limited, UK.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation and/or
 * other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 * may be used to endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


#include <QtWidgets>
#include <QScreen>
#include "MarginSelect.h"

#include "services.h"
#include "sysdata.h"

MarginSelect::MarginSelect(QWidget *parent) : QDialog(parent)
{
    topMargin    = 8;
    bottomMargin = 8;
    leftMargin   = 8;
    rightMargin  = 8;
    
    vLayout = new QVBoxLayout( this );
    topHLayout = new QHBoxLayout;
    midHLayout = new QHBoxLayout;
    botHLayout = new QHBoxLayout;
    
    primaryMsg = new QLabel("For best results the calibration points should be "
                            "as close to the edge of the display as possible.\n\n"
                            "Select Top/Bottom margins as a percentage of screen "
                            "height.\n"
                            "Select left/right margins as a percentage of screen "
                            "width." );

    tLabel = new QLabel("Top");
    bLabel = new QLabel("Bottom");
    lLabel = new QLabel("Left");
    rLabel = new QLabel("Right");
    
    tMarginInput = new QSpinBox;
    tMarginInput->setRange(5, 95);

    bMarginInput = new QSpinBox;
    bMarginInput->setRange(5, 95);

    lMarginInput = new QSpinBox;
    lMarginInput->setRange(5, 95);
    
    rMarginInput = new QSpinBox;
    rMarginInput->setRange(5, 95);

    buttonLayout = new QHBoxLayout;
    selectButton = new QPushButton("&OK");
    cancelButton = new QPushButton("&Cancel");

    topHLayout->addWidget(tLabel, 1, Qt::AlignRight);
    topHLayout->addWidget(tMarginInput);
    topHLayout->addStretch(1);
    
    midHLayout->addWidget(lMarginInput);
    midHLayout->addWidget(lLabel);
    midHLayout->addStretch(1);
    midHLayout->addWidget(rLabel);
    midHLayout->addWidget(rMarginInput);

    botHLayout->addWidget(bLabel, 1, Qt::AlignRight);
    botHLayout->addWidget(bMarginInput);
    botHLayout->addStretch(1);

    tMarginInput->setValue(topMargin);
    lMarginInput->setValue(leftMargin);
    rMarginInput->setValue(rightMargin);
    bMarginInput->setValue(bottomMargin);
    
    selectButton->setAutoDefault(true);
    selectButton->setDefault(true);
    cancelButton->setAutoDefault(false);
    cancelButton->setDefault(false);
    
    buttonLayout->addStretch(1);
    buttonLayout->addWidget(selectButton);
    buttonLayout->addWidget(cancelButton);

    vLayout->addWidget(primaryMsg);
    vLayout->addLayout(topHLayout);
    vLayout->addLayout(midHLayout);
    vLayout->addLayout(botHLayout);
    vLayout->addLayout(buttonLayout);
    // setMinimumSize(400, 200);
    setModal(true);

    this->connect( selectButton, SIGNAL( clicked() ), this, SLOT( accept() ) );
    this->connect( cancelButton, SIGNAL( clicked() ), this, SLOT( reject() ) );
    
    this->connect( tMarginInput, SIGNAL( valueChanged(int) ),
            this, SLOT( updateMargins() ) );
    this->connect( bMarginInput, SIGNAL( valueChanged(int) ),
            this, SLOT( updateMargins() ) );
    this->connect( lMarginInput, SIGNAL( valueChanged(int) ),
            this, SLOT( updateMargins() ) );
    this->connect( rMarginInput, SIGNAL( valueChanged(int) ),
            this, SLOT( updateMargins() ) );
}

// --- Result Access ---------------------------------------

void MarginSelect::getMargins(int *t, int *b, int *l, int *r)
{
    if (t != NULL)
    {
        // copy out the data
        *t = topMargin;
    }
    if (b != NULL)
    {
        // copy out the data
        *b = bottomMargin;
    }
    if (l != NULL)
    {
        // copy out the data
        *l = leftMargin;
    }
    if (r != NULL)
    {
        // copy out the data
        *r = rightMargin;
    }
}

// ---------------------------------------------------------

int MarginSelect::exec()
{
    int ret = QDialog::Rejected;
    char portStr[10];
    setWindowTitle(tr("Select Calibration Margins for Touchscreeen"));
    if ( SUCCESS == zul_getAddrStr(portStr))
    {
        setWindowTitle(tr("Select Calibration Margins for Touchscreeen at USB address ") + QString(portStr));
    }

    activateWindow();
    //cancelButton->setFocus();
    selectButton->setFocus();
    update();

    ret = QDialog::exec();

    // see 'selected' monitor for users choice
    return ret;
}

void MarginSelect::updateMargins()
{
    topMargin    = tMarginInput->value();
    bottomMargin = bMarginInput->value();
    leftMargin   = lMarginInput->value();
    rightMargin  = rMarginInput->value();
}