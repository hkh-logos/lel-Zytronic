/*
 *      Widget to show information about the controller connected and
 *      the platform the application is running on. This is expected to
 *      be at the bottom of the application window.
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#ifndef SYSINFODISPLAY_H
#define SYSINFODISPLAY_H

#include <QtWidgets>

#include <zytypes.h>

class SysInfoDisplay : public QWidget
{
    Q_OBJECT

public:
    SysInfoDisplay(QWidget *parent = 0);
    void refreshTouchInfo();
    void clearControllerInfo();

    QString getSysInfo();
    QString getTouchInfo();

public slots:

signals:

private:
    void createWidgets();
    QLayout * createLayout();

    QLabel *touchInfo;
    QLabel *systemInfo;
};

#endif // SYSINFODISPLAY_H
