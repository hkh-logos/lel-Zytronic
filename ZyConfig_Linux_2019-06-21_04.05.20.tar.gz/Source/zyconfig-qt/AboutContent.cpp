/*
 *      Content of the About Tab in the config app
 */

/*
 * Copyright 2011 - 2019 Zytronic Displays Limited, UK.
 *
 * This file is part of the ZyConfig application.
 *
 * ZyConfig is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ZyConfig is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with ZyConfig.
 *
 * If not, see <https://www.gnu.org/licenses/>.
 */


#include "AboutContent.h"
#include <string.h>

#define INDENT_SIZE (0)
#define LEFT_SPACE  (20)
#define ADDR_WDTH   (400-LEFT_SPACE/2)


#if defined(Q_OS_LINUX)

#define FONT_SIZE   (12)

#else

#define FONT_SIZE   (16)

#endif

const int constLeftSpace = 30;      // this aligns the text under the logo
const int constRghtSpace = 80;      // this aligns the text under the logo

AboutContent::AboutContent(QWidget *parent, QString *versionText ) :
    ZytContentFrame(parent)
{
    textContent = new QString("ABOUT TEXT:\n");
    createWidgets(versionText);

    setLayout(createLayout());
}

void AboutContent::createWidgets( QString *versionText )
{
    contactHead = new QLabel("<b>" + tr("Contact Details") + ":<b>",this);
    QFont hdrFont = contactHead->font();
    hdrFont.setPointSize(FONT_SIZE);
    contactHead->setFont(hdrFont);

    suppContHead = new QLabel("<b>" + tr("Supported Controllers") + ":</b>",this);
    suppContHead->setFont(hdrFont);

    versHead = new QLabel("<b>"+tr("ZyConfig Version") + ":</b>",this);
    versHead->setFont(hdrFont);

    addressLabel = new QLabel(
            tr( "Zytronic Displays Limited\n"
                "Whiteley Road\nBlaydon on Tyne\n"
                "Tyne and Wear\nNE21 5NJ\n"
                "United Kingdom" )
        ,this);

    QFont detailFont = addressLabel->font();
    detailFont.setPointSize(FONT_SIZE*7/8);
    addressLabel->setFont(detailFont);

    contactInfo = new QLabel(
            tr( "Tel: +44 (0) 191 414 5511\n"
                "Fax: +44 (0) 191 414 0545\n\n"
                "http://www.zytronic.co.uk/support\n"
                "Email:  support@zytronic.co.uk"
                )
            ,this);
    contactInfo->setFont(detailFont);
    contactInfo->setTextInteractionFlags(Qt::LinksAccessibleByMouse);
    contactInfo->setOpenExternalLinks(true);

    QLabel *controller;

    controller = new QLabel("ZXY100-U-OFF-32-A|B|C \n"
                            "ZXY100-U-OFF-64-A|B|C \n"
                            "ZXY100-U-OFF-128-A|B|C", this);
    controller->setFont(detailFont);
    suppContCont.append(controller);

    controller = new QLabel("ZXY110-U-OFF-32-A \n"
                            "ZXY110-U-OFF-64-A", this);
    controller->setFont(detailFont);
    suppContCont.append(controller);

    controller = new QLabel("ZXY150-U-OFF-64-A", this);
    controller->setFont(detailFont);
    suppContCont.append(controller);

    controller = new QLabel("ZXY200-U-OFF-128-A|B", this);
    controller->setFont(detailFont);
    suppContCont.append(controller);

    controller = new QLabel("ZXY300-U-OFF-256-A", this);
    controller->setFont(detailFont);
    suppContCont.append(controller);

    controller = new QLabel("ZXY500-U-OFF-64-A\n"
                            "ZXY500-U-OFF-128-A\n"
                            "ZXY500-U-OFF-256-A", this);
    controller->setFont(detailFont);
    suppContCont.append(controller);

    {
        QString vApp = *versionText;

        versCont = new QLabel(tr("Application") + ": " + vApp.toLatin1(), this);
        versCont->setFont(detailFont);
    }

    // automate the copyright date to build date year
    char date[] = __DATE__;
    char buildYear[60];
    bzero(buildYear, 60);
    snprintf ( buildYear, 8, " %s ", date+strlen(date)-4 );

    // \u00A9 = (c)
    copyrightLabel = new QLabel( tr("Copyright \u00A9") +
                    tr("Zytronic Displays Limited. All rights reserved."), this);

    copyrightLabel->setFont(detailFont);
    copyrightLabel->setContentsMargins(constLeftSpace,0,0,0);

    connectHint = new QLabel("No Zytronic touchscreen controllers detected. Connect a controller and restart application");
    connectHint->setFont(detailFont);
    connectHint->setContentsMargins(constLeftSpace,0,0,0);
    connectHint->setStyleSheet("QLabel { background-color : white; color : red; }");

    // ToDo automate this so that the GUI is correct if a device
    // is connected or not
    if (true)
    {
        connectHint->setVisible(false);
    }
}

QLayout * AboutContent::createLayout()
{
    QVBoxLayout *frameLayoutV = new QVBoxLayout;

    QHBoxLayout *mainLayoutH = new QHBoxLayout;

    QVBoxLayout *contactLayoutV = new QVBoxLayout;
    QVBoxLayout *devicesLayoutV = new QVBoxLayout;
    QVBoxLayout *versionLayoutV = new QVBoxLayout;

    frameLayoutV->addLayout(mainLayoutH);
    frameLayoutV->addWidget(copyrightLabel);
    textContent->append(copyrightLabel->text()+"\n");

    frameLayoutV->addWidget(connectHint);
    textContent->append(connectHint->text()+"\n");

    mainLayoutH->addSpacing(constLeftSpace);
    mainLayoutH->addLayout(contactLayoutV);
    mainLayoutH->addStretch();
    mainLayoutH->addLayout(devicesLayoutV);
    mainLayoutH->addStretch();
    mainLayoutH->addLayout(versionLayoutV);
    mainLayoutH->addSpacing(constRghtSpace);

    contactLayoutV->addWidget(contactHead);
    textContent->append(contactHead->text()+"\n");
    contactLayoutV->addWidget(addressLabel);
    textContent->append(addressLabel->text()+"\n");
    contactLayoutV->addStretch();
    contactLayoutV->addWidget(contactInfo);
    textContent->append(contactInfo->text()+"\n");
    contactLayoutV->addStretch();

    devicesLayoutV->addWidget(suppContHead);
    textContent->append(suppContHead->text()+"\n");
    for(int i = 0; i < suppContCont.size(); i++)
    {
        devicesLayoutV->addWidget(suppContCont[i]);
        textContent->append(suppContCont[i]->text()+"\n");
    }
    devicesLayoutV->addStretch();

    versionLayoutV->addWidget(versHead);
    textContent->append(versHead->text()+"\n");
    versionLayoutV->addWidget(versCont);
    textContent->append(versCont->text()+"\n");
    versionLayoutV->addStretch();

    return frameLayoutV;
}

void AboutContent::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.fillRect(rect(), QColor(240,240,240));

    QFrame::paintEvent(event);
}

QString * AboutContent::getTextContent(void)
{
    return textContent;
}
