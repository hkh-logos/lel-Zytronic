#!/bin/bash
if [ -e ./CheckTools.sh ]; then
    ./checkTools
    if [ $? != 0 ]; then
        exit
    fi
fi

txtLine=" - - - - - - - - - - - - - - - - - - - - - - - - \n"
echo Building ZyConfig tools from source
echo "Running" `pwd`   $0 $1
echo -e $txtLine

mkdir -p ./bin

cd ./zylib/
./build.sh
cd -
echo -e $txtLine

# Options to add to build:
for sDir in apps/firmwareUpdate apps/saveZys apps/loadZys ZyConfigCLI
do
    echo Building $sDir
    make -wC $sDir
    echo -e $txtLine
done

cd ./touchtest-qt
./build.sh
cd -

cd ./zyconfig-qt
./build.sh
cd -
