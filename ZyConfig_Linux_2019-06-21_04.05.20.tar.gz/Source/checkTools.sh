#!/bin/bash
# =====================================
# Check Tool Setup
# =====================================

export QT_SELECT=5

echo -e $textLine
echo Check Tool Setup
echo -e $textLine

exitCode=0
for tool in make gcc g++
do
    which $tool > /dev/null
    if [ $? -ne 0 ] ; then
        echo Missing dependency: $tool
        exitCode=1
    fi
done

tool=qmake
which $tool 2> /dev/null
if [ $? -eq 1 ] ; then
	tool=qmake-qt5
	which $tool 2> /dev/null
fi
if [ $? -eq 0 ] ; then
#    qmakeVer=`$tool -v | grep QMake | cut -d' ' -f3`
    qmakeVer=`$tool -v | head -n 2`
    echo \'$tool\': $qmakeVer
else
    echo The \'qmake/qmake-qt5\' tool is missing
    echo "  Please ensure that the full QT5 development environment is installed."
    echo "  e.g. [Debian/Ubuntu] $ sudo apt-get install qtdeclarative5-dev"
    echo "       [CentOS/Fedora] $ sudo yum -y install qt5-qtbase-devel"
    exitCode=1
fi
echo

if  [ ! -e /usr/include/libusb-1.0/libusb.h ] &&
    [ ! -e /usr/local/include/libusb-1.0/libusb.h ]; then
    echo Missing dependency: libusb.h
    echo "  Please install the libusb development package."
    echo "  e.g. [Debian/Ubuntu] $ sudo apt-get install libusb-1.0-0-dev"
    echo "  e.g. [CentOS/Fedora] $ sudo yum install libusbx-devel.x86_64"
    exitCode=1
else
    file=/usr/include/libusb-1.0/libusb.h
    [ -e $file ] && grep "define LIBUSB_API_VERSION" $file
    file=/usr/local/include/libusb-1.0/libusb.h
    [ -e $file ] && grep "define LIBUSB_API_VERSION" $file
fi
echo

if  [ ! -e /usr/include/X11/Xlib.h ]; then
    echo Missing dependency: X11/Xlib.h
    echo "  Please install the X11 development package."
    echo "  e.g. [Debian/Ubuntu] $ sudo apt-get install libx11-dev"
    echo
    exitCode=1
fi

if [ $exitCode != 1 ]; then
    echo Tools availability checks passed ...
fi

exit $exitCode

