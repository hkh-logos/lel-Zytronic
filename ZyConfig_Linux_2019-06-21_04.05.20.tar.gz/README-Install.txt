Zytronic Displays Limited
=========================

Date :                  Fri 21 Jun 10:39:40 BST 2019

Application Version:    04.05.20


This release of the ZyConfig tool depends on the use of the Linux command line.
On most Linux installations, there is a "Terminal" program that provides the
'bash' shell environment. Some familiarity with the command line is required to
use this software.

Change the current working directory to the location of the released tar.gz
archive.  This archive can be uncompressed with the command:

    $ tar -xzf Zyconfig-USD.tar.gz

This will provide the 'Source' directory, which holds sub-directories for the
TouchTest application sources, the ZyConfig application sources and the ZyConfig
supporting (library) code. There may also be pre-built binaries, held in
directories such as 'armv7l', 'i686' and 'x86_64'. If you find the pre-built
binaries to match your processor, there is no need to build them from the
sources.

However, if your architecture is not available as binary, the source code can be
used to generate appropriate binaries for your system.

    $ cd Source

Use the './checkTools.sh' script to confirm that the dependencies are installed:

    $ ./checkTools.sh

The source code can then be rebuilt to executables with the './buildAll.sh' script:

    $ ./buildAll.sh

The new binaries are found in the 'Source/bin' folder.

These binaries should be run as indicated in the user-guide:

    README-HowTo.txt
